#ifndef GAME_GAME_ENTITIES_PIECEHANDLER_H_
#define GAME_GAME_ENTITIES_PIECEHANDLER_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <array>
#include <memory>

//Other libraries headers

//Own components headers
#include "game/defines/ChessDefines.h"
#include "game/game_entities/pieces/PieceHandlerPopulator.h"

//Forward declarations
class FBO;
class InputEvent;
class GameBoardInterface;
class GameInterface;

class PieceHandler {
public:
  int32_t init(GameBoardInterface *gameBoardInterface,
               GameInterface *gameInterface,
               int32_t whitePiecesRsrcId, int32_t blackPiecesRsrcId,
               int32_t notReadyFontRsrcId);

  void deinit();

  void draw(FBO &boardFbo);

  void handleEvent(const InputEvent &e);

  void setActivePlayerId(int32_t activePlayerId);

  void promotePiece(PieceType pieceType);

  void setWidgetFlipType(WidgetFlip flipType);

private:
  void handlePieceGrabbedEvent(const InputEvent &e);
  void handleNoPieceGrabbedEvent(const InputEvent &e);

  void doMovePiece(const BoardPos &gameFbo);

  std::array<ChessPiece::PlayerPieces, Defines::PLAYERS_COUNT> _pieces;

  GameBoardInterface *_gameBoardInterface = nullptr;
  GameInterface *_gameInterface = nullptr;

  int32_t _selectedPieceId = 0;
  int32_t _activePlayerId = 0;
  bool _isPieceGrabbed = false;
};

#endif /* GAME_GAME_ENTITIES_PIECEHANDLER_H_ */
