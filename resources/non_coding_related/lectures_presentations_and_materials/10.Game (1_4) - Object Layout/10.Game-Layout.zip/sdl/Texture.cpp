//Corresponding header
#include "sdl/Texture.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include <SDL_image.h>
#include <SDL_render.h>
#include <SDL_ttf.h>

//Own components headers
#include "utils/drawing/Color.h"

namespace {
SDL_Renderer *gSdlRenderer = nullptr;
}

int32_t Texture::loadSurfaceFromFile(const char *path,
                                     SDL_Surface *&outSurface) {
  if (outSurface) { //sanity check
    std::cerr << "Warning, non-empty SDL_Surface passed to "
              "Texture::LoadSurfaceFromFile(). Caller image path: "
              << path << std::endl;
    freeSurface(outSurface);
  }

  //Load image at specified path
  outSurface = IMG_Load(path);
  if (nullptr == outSurface) {
    std::cerr << "Unable to load image " << path << ". SDL_image Error: "
              << IMG_GetError() << std::endl;

    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

int32_t Texture::loadTextureFromText(const char *text, TTF_Font *font,
                                     const Color &color,
                                     SDL_Texture *&outTexture,
                                     int32_t &outTextWidth,
                                     int32_t &outTextHeight) {

  SDL_Surface *loadedSurface = TTF_RenderText_Blended(font, text,
      * (reinterpret_cast<const SDL_Color*>(&color.rgba)));

  if (loadedSurface == nullptr) {
    std::cerr << "Unable to load image! SDL_image Error: " << IMG_GetError()
              << std::endl;
    return EXIT_FAILURE;
  }

  outTextWidth = loadedSurface->w;
  outTextHeight = loadedSurface->h;

  //create hardware accelerated texture
  if (EXIT_SUCCESS != Texture::loadTextureFromSurface(loadedSurface,
          outTexture)) {
    std::cerr << "Unable to create text texture" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

int32_t Texture::loadTextureFromSurface(SDL_Surface *&surface,
                                        SDL_Texture *&outTexture) {
  //Create texture from surface pixels
  outTexture = SDL_CreateTextureFromSurface(gSdlRenderer, surface);

  if (nullptr == outTexture) {
    std::cerr << "Unable to create texture! SDL Error: " << SDL_GetError()
              << std::endl;
    return EXIT_FAILURE;
  }

  SDL_FreeSurface(surface);
  surface = nullptr;

  return EXIT_SUCCESS;
}

void Texture::freeSurface(SDL_Surface *&surface) {
  if (surface) { //sanity check
    SDL_FreeSurface(surface);
    surface = nullptr;
  }
}

void Texture::freeTexture(SDL_Texture *&texture) {
  if (texture) { //sanity check
    SDL_DestroyTexture(texture);
    texture = nullptr;
  }
}

int32_t Texture::setAlpha(SDL_Texture *texture, int32_t alpha) {
  if (0 > alpha || 255 < alpha) {
    std::cerr << "Error, unsupported opacity: " << alpha
              << ". Alpha works in the boundaries [0-255]" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != SDL_SetTextureAlphaMod(texture,
          static_cast<uint8_t>(alpha))) {
    std::cerr << "Warning, .setAlpha() method will not take effect. Reason: "
              "invalid texture or alpha modulation is not supported. "
              "SDL_SetTextureAlphaMod() failed. SDL Error: "
              << SDL_GetError() << std::endl;
    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}

int32_t Texture::setBlendMode(SDL_Texture *texture, BlendMode blendMode) {
  if (EXIT_SUCCESS != SDL_SetTextureBlendMode(texture,
          static_cast<SDL_BlendMode>(blendMode))) {
    std::cerr
        << "Warning, .setBlendMode() method will not take effect. Reason: "
        "invalid texture or blend mode is not supported. "
        "SDL_SetTextureBlendMode() failed. SDL Error: "
        << SDL_GetError() << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void Texture::setRenderer(SDL_Renderer *renderer) {
  gSdlRenderer = renderer;
}
