#ifndef GAME_GAME_ENTITIES_PIECES_ROOK_H_
#define GAME_GAME_ENTITIES_PIECES_ROOK_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/game_entities/pieces/ChessPiece.h"

//Forward declarations
class InputEvent;

class Rook: public ChessPiece {
public:
  Rook(int32_t pieceRsrcId, const BoardPos &boardPos, PieceType pieceType,
       int32_t playerId);

  std::vector<TileData> getMoveTiles(
      const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const final;

private:
  std::vector<MoveDirection> getBoardMoves() const;
};

#endif /* GAME_GAME_ENTITIES_PIECES_ROOK_H_ */
