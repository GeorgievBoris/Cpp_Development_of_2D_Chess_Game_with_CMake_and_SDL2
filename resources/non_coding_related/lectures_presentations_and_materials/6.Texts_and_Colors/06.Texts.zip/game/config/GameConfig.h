#ifndef GAME_CONFIG_GAMECONFIG_H_
#define GAME_CONFIG_GAMECONFIG_H_

//C system headers

//C++ system headers
//Other libraries headers

//Own components headers

//Forward declarations
class ImageContainer;
class TextContainer;

struct GameConfig {
  const ImageContainer *imageContainer = nullptr;
  TextContainer *textContainer = nullptr;
};

#endif /* GAME_CONFIG_GAMECONFIG_H_ */
