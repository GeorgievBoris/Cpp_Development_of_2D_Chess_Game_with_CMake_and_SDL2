//Corresponding header
#include "game/game_entities/utils/BoardUtils.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "utils/drawing/Rectangle.h"

namespace {
constexpr auto BOARD_SIZE = 8;

constexpr auto FIRST_TILE_X_POS = 58;
constexpr auto FIRST_TILE_Y_POS = 60;

constexpr auto TILE_SIZE = 98;
}

BoardPos BoardUtils::getBoardPos(const Point &absPos) {
  return Point( (absPos.y - FIRST_TILE_X_POS) / TILE_SIZE,
      (absPos.x - FIRST_TILE_Y_POS) / TILE_SIZE);
}

Point BoardUtils::getAbsPos(const BoardPos &boardPos) {
  return Point(FIRST_TILE_X_POS + boardPos.col * TILE_SIZE,
      FIRST_TILE_Y_POS + boardPos.row * TILE_SIZE);
}

bool BoardUtils::isInsideBoard(const BoardPos &boardPos) {
  if (0 > boardPos.row || BOARD_SIZE <= boardPos.row) {
    return false;
  }

  if (0 > boardPos.col || BOARD_SIZE <= boardPos.col) {
    return false;
  }

  return true;
}

bool BoardUtils::isInsideBoard(const Point &absPos) {
  const Rectangle boundary(FIRST_TILE_X_POS, FIRST_TILE_Y_POS,
      BOARD_SIZE * TILE_SIZE, BOARD_SIZE * TILE_SIZE);

  return boundary.isPointInRect(absPos);
}

