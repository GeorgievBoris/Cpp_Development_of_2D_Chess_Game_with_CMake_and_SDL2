//Corresponding header
#include "game/game_entities/panels/buttons/PiecePromotionButton.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"

int32_t PiecePromotionButton::init(const PiecePromotionButtonConfig &cfg) {
  if (nullptr == cfg.onBtnClicked) {
    std::cerr << "Error, nullptr provided for onBtnClicked interface"
              << std::endl;
    return EXIT_FAILURE;
  }
  _cfg = cfg;
  _bgrImg.create(cfg.buttonBgrRsrcId, cfg.bgrPos);

  return EXIT_SUCCESS;
}

void PiecePromotionButton::draw() {
  _bgrImg.draw();
  ButtonBase::draw();
}

void PiecePromotionButton::handleEvent(const InputEvent &e) {
  if (TouchEvent::TOUCH_PRESS == e.type) {
    _bgrImg.setFrame(CLICKED);
  } else if (TouchEvent::TOUCH_RELEASE == e.type) {
    _bgrImg.setFrame(UNCLICKED);
    _cfg.onBtnClicked(_cfg.pieceType);
  }
}

void PiecePromotionButton::activate(int32_t activePlayerId) {
  const int32_t pieceRsrcId =
      (Defines::WHITE_PLAYER == activePlayerId) ?
          _cfg.buttonWhitePieceRsrcId : _cfg.buttonBlackPieceRsrcId;

  ButtonBase::destroy();
  const int32_t X_Y_DELTA = (_bgrImg.getWidth() - _cfg.width) / 2;
  const Point btnPos = Point(_bgrImg.getX() + X_Y_DELTA,
      _bgrImg.getY() + X_Y_DELTA);

  ButtonBase::create(pieceRsrcId, btnPos);
  ButtonBase::setFrame(static_cast<int32_t>(_cfg.pieceType));

  _bgrImg.setFrame(UNCLICKED);
}

