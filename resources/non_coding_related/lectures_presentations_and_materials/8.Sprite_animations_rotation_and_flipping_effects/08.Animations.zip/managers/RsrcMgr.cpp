//Corresponding header
#include "managers/RsrcMgr.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/config/RsrcMgrConfig.h"

RsrcMgr *gRsrcMgr = nullptr;


int32_t RsrcMgr::init(const RsrcMgrConfig &cfg) {
  if (EXIT_SUCCESS != ImageContainer::init(cfg.imageContainerCfg)) {
    std::cerr << "Error in ImageContainer::init()" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != TextContainer::init(cfg.textContainerCfg)) {
    std::cerr << "Error in TextContainer::init()" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void RsrcMgr::deinit() {
  TextContainer::deinit();
  ImageContainer::deinit();
}

void RsrcMgr::process() {

}



