//Corresponding header
#include "sdl/containers/FboContainer.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include <SDL_ttf.h>

//Own components headers
#include "sdl/Texture.h"

int32_t FboContainer::init() {
  return EXIT_SUCCESS;
}

void FboContainer::deinit() {
  for (SDL_Texture *texture : _textures) {
    Texture::freeTexture(texture);
  }
}

void FboContainer::createFbo(int32_t fboWidth, int32_t fboHeight,
                             int32_t &outFboId) {
  occupyFreeSlotIndex(outFboId);

  //create hardware accelerated texture
  if (EXIT_SUCCESS != Texture::createEmptyTexture(fboWidth, fboHeight,
          _textures[outFboId])) {
    std::cerr << "Unable to create FBO: with Id: " << outFboId << std::endl;
    freeSlotIndex(outFboId);
  }
}

void FboContainer::unloadFbo(int32_t fboId) {
  if (fboId >= static_cast<int32_t>(_textures.size())) {
    std::cerr << "Warning, unloading a non-existing FBO index for textId: "
              << fboId << std::endl;
    return;
  }
  freeSlotIndex(fboId);
}

SDL_Texture* FboContainer::getFboTexture(int32_t fboId) const {
  return _textures[fboId];
}

void FboContainer::occupyFreeSlotIndex(int32_t &occupiedFboId) {
  bool foundIdx = false;

  const int32_t size = static_cast<int32_t>(_textures.size());
  for (int32_t idx = 0; idx < size; ++idx) {
    if (nullptr == _textures[idx]) {
      occupiedFboId = idx;
      foundIdx = true;
      break;
    }
  }

  //create additional space
  if (!foundIdx) {
    _textures.push_back(nullptr);
    occupiedFboId = size;
  }
}

void FboContainer::freeSlotIndex(int32_t fboId) {
  Texture::freeTexture(_textures[fboId]);
}
