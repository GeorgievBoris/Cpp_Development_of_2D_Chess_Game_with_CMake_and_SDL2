//Corresponding header
#include "utils/drawing/Image.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/RsrcMgr.h"

Image::~Image() {
  //attempt to destroy Image only if it's was first created and not destroyed
  if (true == _isCreated && false == _isDestroyed) {
    destroy();
  }
}

void Image::create(int32_t textureId, const Point &pos) {
  if (_isCreated) {
    std::cerr << "Error, Text with textureId: " << textureId
              << " is already created" << std::endl;
    return;
  }

  _drawParams.rsrcId = textureId;
  const Frames& frames = gRsrcMgr->getImageFrames(_drawParams.rsrcId);
  _maxFrames = static_cast<int32_t>(frames.size());
  _drawParams.frameRect = frames[_currFrame];
  _isCreated = true;
  _isDestroyed = false;
  _drawParams.pos = pos;
  _drawParams.width = _drawParams.frameRect.w;
  _drawParams.height = _drawParams.frameRect.h;
  _drawParams.widgetType = WidgetType::IMAGE;
}

void Image::destroy() {
  if (_isDestroyed) {
    std::cerr
        << "Warning, trying to destroy already destroyed Image with rsrcId: "
        << _drawParams.rsrcId << std::endl;
    return;
  }
  _isDestroyed = true;
  Widget::reset();
}

void Image::setFrame(int32_t frameIdx) {
  if (0 > frameIdx || frameIdx >= _maxFrames) {
    std::cerr << "Error, trying to set frameIdx: " << frameIdx
              << ", where maxFrames are: " << _maxFrames << " for rsrcId: "
              << _drawParams.rsrcId << std::endl;
    return;
  }

  _currFrame = frameIdx;
  const Frames& frames = gRsrcMgr->getImageFrames(_drawParams.rsrcId);
  _drawParams.frameRect = frames[_currFrame];
}

void Image::setNextFrame() {
  ++_currFrame;
  if (_maxFrames == _currFrame) {
    _currFrame = 0;
  }

  const Frames& frames = gRsrcMgr->getImageFrames(_drawParams.rsrcId);
  _drawParams.frameRect = frames[_currFrame];
}

void Image::setPrevFrame() {
  --_currFrame;
  if (-1 == _currFrame) {
    _currFrame = _maxFrames - 1;
  }

  const Frames& frames = gRsrcMgr->getImageFrames(_drawParams.rsrcId);
  _drawParams.frameRect = frames[_currFrame];
}

int32_t Image::getFrame() const {
  return _currFrame;
}

