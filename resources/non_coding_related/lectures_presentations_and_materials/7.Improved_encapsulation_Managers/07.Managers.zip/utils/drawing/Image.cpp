//Corresponding header
#include "utils/drawing/Image.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/RsrcMgr.h"

Image::~Image() {
  //attempt to destroy Image only if it's was first created and not destroyed
  if (true == _isCreated && false == _isDestroyed) {
    destroy();
  }
}

void Image::create(int32_t textureId, const Point &pos) {
  if (_isCreated) {
    std::cerr << "Error, Text with textureId: " << textureId
              << " is already created" << std::endl;
    return;
  }

  const Rectangle frame = gRsrcMgr->getImageFrame(textureId);
  _isCreated = true;
  _isDestroyed = false;
  _drawParams.rsrcId = textureId;
  _drawParams.pos = pos;
  _drawParams.width = frame.w;
  _drawParams.height = frame.h;
  _drawParams.widgetType = WidgetType::IMAGE;
}

void Image::destroy() {
  if (_isDestroyed) {
    std::cerr
        << "Warning, trying to destroy already destroyed Image with rsrcId: "
        << _drawParams.rsrcId << std::endl;
    return;
  }
  _isDestroyed = true;
  Widget::reset();
}

