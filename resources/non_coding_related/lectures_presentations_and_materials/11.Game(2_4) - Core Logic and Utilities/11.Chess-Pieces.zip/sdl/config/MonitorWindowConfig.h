#ifndef SDL_CONFIG_MONITORWINDOWCONFIG_H_
#define SDL_CONFIG_MONITORWINDOWCONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <string>

//Other libraries headers

//Own components headers
#include "utils/drawing/Point.h"

//Forward declarations

struct MonitorWindowConfig {
  //Window modes:
  //SDL_WINDOW_SHOWN - for windowed version
  //SDL_WINDOW_FULLSCREEN_DESKTOP - for fullscreen
  int32_t displayMode { 0 };
  int32_t windowWidth { 0 };
  int32_t windowHeight { 0 };
  Point windowPos = Point::UNDEFINED;
  std::string windowName;
};

#endif /* SDL_CONFIG_MONITORWINDOWCONFIG_H_ */
