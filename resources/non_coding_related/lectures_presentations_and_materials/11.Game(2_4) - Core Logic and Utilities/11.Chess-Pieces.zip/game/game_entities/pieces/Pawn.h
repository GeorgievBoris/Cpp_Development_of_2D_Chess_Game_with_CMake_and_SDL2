#ifndef GAME_GAME_ENTITIES_PIECES_PAWN_H_
#define GAME_GAME_ENTITIES_PIECES_PAWN_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <unordered_map>

//Other libraries headers

//Own components headers
#include "game/game_entities/pieces/ChessPiece.h"

//Forward declarations
class InputEvent;

class Pawn: public ChessPiece {
public:
  Pawn(int32_t pieceRsrcId, const BoardPos &boardPos, PieceType pieceType,
       int32_t playerId);

  std::vector<TileData> getMoveTiles(
      const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const final;

private:
  std::vector<TileData> getWhiteMoveTiles(
      const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const;
  std::vector<TileData> getBlackMoveTiles(
      const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const;

  std::unordered_map<Defines::Direction, MoveDirection> getWhiteBoardMoves() const;
  std::unordered_map<Defines::Direction, MoveDirection> getBlackBoardMoves() const;
};

#endif /* GAME_GAME_ENTITIES_PIECES_PAWN_H_ */
