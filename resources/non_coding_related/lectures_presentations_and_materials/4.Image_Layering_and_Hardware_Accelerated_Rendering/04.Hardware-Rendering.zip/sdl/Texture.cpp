//Corresponding header
#include "sdl/Texture.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include <SDL_image.h>
#include <SDL_render.h>

//Own components headers

namespace {
SDL_Renderer *gSdlRenderer = nullptr;
}

int32_t Texture::loadSurfaceFromFile(const char *path,
                                     SDL_Surface *&outSurface) {
  if (outSurface) { //sanity check
    std::cerr << "Warning, non-empty SDL_Surface passed to "
              "Texture::LoadSurfaceFromFile(). Caller image path: "
              << path << std::endl;
    freeSurface(outSurface);
  }

  //Load image at specified path
  outSurface = IMG_Load(path);
  if (nullptr == outSurface) {
    std::cerr << "Unable to load image " << path << ". SDL_image Error: "
              << IMG_GetError() << std::endl;

    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

int32_t Texture::loadTextureFromSurface(SDL_Surface *&surface,
                                        SDL_Texture *&outTexture) {
  //Create texture from surface pixels
  outTexture = SDL_CreateTextureFromSurface(gSdlRenderer, surface);

  if (nullptr == outTexture) {
    std::cerr << "Unable to create texture! SDL Error: " << SDL_GetError()
              << std::endl;
    return EXIT_FAILURE;
  }

  SDL_FreeSurface(surface);
  surface = nullptr;

  return EXIT_SUCCESS;
}

void Texture::freeSurface(SDL_Surface *&surface) {
  if (surface) { //sanity check
    SDL_FreeSurface(surface);
    surface = nullptr;
  }
}

void Texture::freeTexture(SDL_Texture *&texture) {
  if (texture) { //sanity check
    SDL_DestroyTexture(texture);
    texture = nullptr;
  }
}

void Texture::setRenderer(SDL_Renderer *renderer) {
  gSdlRenderer = renderer;
}
