#ifndef GAME_PROXIES_GAMEINTERFACE_H_
#define GAME_PROXIES_GAMEINTERFACE_H_

#include "game/defines/ChessDefines.h"
#include "utils/drawing/DrawParams.h"

class GameInterface {
public:
  GameInterface() = default;
  virtual ~GameInterface() = default;

  virtual void finishTurn() = 0;

  virtual void activatePawnPromotion() = 0;

  virtual void promotePiece(PieceType pieceType) = 0;

  virtual void setWidgetFlipType(WidgetFlip flipType) = 0;

  virtual void onEndTurnAnimFinished() = 0;
};

#endif /* GAME_PROXIES_GAMEINTERFACE_H_ */
