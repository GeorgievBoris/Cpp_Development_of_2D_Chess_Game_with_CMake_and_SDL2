#ifndef ENGINE_ENGINECONFIG_H_
#define ENGINE_ENGINECONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "sdl/config/MonitorWindowConfig.h"
#include "sdl/config/ImageContainerConfig.h"
#include "sdl/config/TextContainerConfig.h"
#include "game/config/GameConfig.h"

//Forward declarations

struct EngineConfig {
  MonitorWindowConfig windowCfg;
  ImageContainerConfig imageContainerCfg;
  TextContainerConfig textContainerCfg;
  GameConfig gameCfg;
};

#endif /* ENGINE_ENGINECONFIG_H_ */
