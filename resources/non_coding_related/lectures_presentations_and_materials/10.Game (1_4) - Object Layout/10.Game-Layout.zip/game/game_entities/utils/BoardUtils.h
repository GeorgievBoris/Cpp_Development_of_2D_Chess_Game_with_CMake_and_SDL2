#ifndef GAME_GAME_ENTITIES_UTILS_BOARDUTILS_H_
#define GAME_GAME_ENTITIES_UTILS_BOARDUTILS_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/game_entities/utils/BoardPos.h"

//Forward declarations

class BoardUtils {
public:
  BoardUtils() = delete;

  static BoardPos getBoardPos(const Point &absPos);

  static Point getAbsPos(const BoardPos& boardPos);

  static bool isInsideBoard(const BoardPos& boardPos);

  static bool isInsideBoard(const Point& absPos);
};

#endif /* GAME_GAME_ENTITIES_UTILS_BOARDUTILS_H_ */
