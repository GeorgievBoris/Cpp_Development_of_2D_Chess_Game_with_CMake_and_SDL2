//Corresponding header
#include "game/game_entities/board/GameBoardAnimator.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "game/proxies/GameInterface.h"
#include "game/defines/ChessDefines.h"

namespace {
constexpr auto ROT_STEP = 180;
}

int32_t GameBoardAnimator::init(GameInterface *gameInterface, Image *boardImg) {
  if (gameInterface == nullptr) {
    std::cerr << "Error, nullptr GameInterface provided" << std::endl;
    return EXIT_FAILURE;
  }
  _gameInterface = gameInterface;

  if (boardImg == nullptr) {
    std::cerr << "Error, nullptr boardImg provided" << std::endl;
    return EXIT_FAILURE;
  }
  _boardImg = boardImg;
  _boardImg->setRotationCenter(
      Point(_boardImg->getWidth() / 2, _boardImg->getHeight() / 2));

  return EXIT_SUCCESS;
}

void GameBoardAnimator::startAnim(int32_t playerId) {
  if (Defines::WHITE_PLAYER == playerId) {
    _currRotation = ROT_STEP;
    _targetFlipType = WidgetFlip::HORIZONTAL_AND_VERTICAL;
  } else {
    _currRotation = 0;
    _targetFlipType = WidgetFlip::NONE;
  }

  onAnimEnd();
}

void GameBoardAnimator::onAnimEnd() {
  _boardImg->setRotation(_currRotation);
  _gameInterface->setWidgetFlipType(_targetFlipType);
}

