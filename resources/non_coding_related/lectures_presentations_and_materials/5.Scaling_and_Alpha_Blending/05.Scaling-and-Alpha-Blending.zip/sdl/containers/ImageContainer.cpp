//Corresponding header
#include "sdl/containers/ImageContainer.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/Texture.h"
#include "sdl/config/ImageContainerConfig.h"
#include "common/CommonDefines.h"

//TODO (Remove me) temporary set alpha blending for all textures.
#include "utils/drawing/DrawParams.h"

int32_t ImageContainer::init(const ImageContainerConfig &cfg) {
  for (const auto &elem : cfg.imageConfigs) {
    const ImageConfig &currImgCfg = elem.second;

    if (loadSingleTexture(currImgCfg.location.c_str(), elem.first)) {
      std::cerr << "loadSingleTexture() failed " << std::endl;
      return EXIT_FAILURE;
    }

    Rectangle &currFrame = _textureFrames[elem.first];
    currFrame.x = 0;
    currFrame.y = 0;
    currFrame.w = currImgCfg.width;
    currFrame.h = currImgCfg.height;
  }

  return EXIT_SUCCESS;
}

void ImageContainer::deinit() {
  for (auto &elem : _textures) {
    Texture::freeTexture(elem.second);
  }
}

SDL_Texture* ImageContainer::getImageTexture(int32_t rsrcId) const {
  const auto it = _textures.find(rsrcId);
  if (it != _textures.end()) {
    return it->second;
  }

  std::cerr << "No Image Frame found for rsrcId: " << rsrcId
            << ". getImageTexture() returning nullptr" << std::endl;
  return nullptr;
}

Rectangle ImageContainer::getImageFrame(int32_t rsrcId) const {
  const auto it = _textureFrames.find(rsrcId);
  if (it != _textureFrames.end()) {
    return it->second;
  }

  std::cerr << "No Frame found for rsrcId: " << rsrcId
            << "Returning Rectangle::ZERO" << std::endl;
  return Rectangle::ZERO;
}

int32_t ImageContainer::loadSingleTexture(const char *filePath,
                                          int32_t textureId) {
  SDL_Surface *surface = nullptr;
  if (EXIT_SUCCESS != Texture::loadSurfaceFromFile(filePath, surface)) {
    std::cerr << "Unable to load image: " << filePath << std::endl;
    return EXIT_FAILURE;
  }

  //create hardware accelerated texture
  if (EXIT_SUCCESS != Texture::loadTextureFromSurface(surface,
          _textures[textureId])) {
    std::cerr << "Unable to create texture with Id: " << textureId << std::endl;
    return EXIT_FAILURE;
  }

  //TODO (Remove me) temporary set alpha blending for all textures.
  if (EXIT_SUCCESS != Texture::setBlendMode(_textures[textureId],
          BlendMode::BLEND)) {
    std::cerr << "setBlendMode() failed with Id: " << textureId << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

