//Corresponding header
#include "utils/drawing/FBO.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/RsrcMgr.h"
#include "managers/DrawMgr.h"

FBO::~FBO() {
  //attempt to destroy text only if it's was first created and not destroyed
  if (true == _isCreated && false == _isDestroyed) {
    FBO::destroy();
  }
}

void FBO::create(int32_t width, int32_t height, const Point &pos,
                 const Color &clearColor) {
  if (_isCreated) {
    std::cerr << "Error, FBO with fboId: " << _drawParams.fboId
              << " is already created" << std::endl;
    return;
  }
  _drawParams.widgetType = WidgetType::FBO;
  _clearColor = clearColor;

  gRsrcMgr->createFbo(width, height, _drawParams.fboId);

  _isCreated = true;
  _isDestroyed = false;
  _drawParams.pos = pos;
  _drawParams.width = width;
  _drawParams.height = height;
  _drawParams.frameRect.w = _drawParams.width;
  _drawParams.frameRect.h = _drawParams.height;
}

void FBO::destroy() {
  if (_isDestroyed) {
    std::cerr << "Warning, trying to destroy already destroyed FBO with fboId: "
              << _drawParams.fboId << std::endl;
    return;
  }

  if (!_isCreated) {
    std::cerr << "Warning, trying to destroy a not-created FBO with fboId: "
              << _drawParams.fboId << std::endl;
    return;
  }

  //sanity check, because manager could already been destroyed
  if (nullptr != gRsrcMgr) {
    //unload text from graphical text vector
    gRsrcMgr->unloadFbo(_drawParams.fboId);
  }

  _isDestroyed = true;
  Widget::reset();
}

void FBO::unlock() {
  if (!_isLocked) {
    std::cerr << "Error, trying to unlock a FBO that is already unlocked"
              << std::endl;
    return;
  }

  _isLocked = false;

  if (EXIT_SUCCESS != gDrawMgr->unlockRenderer()) {
    std::cerr << "Error, gDrawMgr->unlockRenderer() failed" << std::endl;
    return;
  }

  gDrawMgr->changeRendererTarget(_drawParams.fboId);
}

void FBO::lock() {
  if (_isLocked) {
    std::cerr << "Error, trying to lock a FBO that is already locked"
              << std::endl;
    return;
  }

  _isLocked = true;
  if (EXIT_SUCCESS != gDrawMgr->lockRenderer()) {
    std::cerr << "gDrawMgr->lockRenderer() failed" << std::endl;
    return;
  }

  gDrawMgr->resetRendererTarget();
}

void FBO::reset() {
  if (_isLocked) {
    std::cerr << "Error, FBO::reset() failed, because FBO is still locked. "
              "Consider using the sequence ::unlock(), ::reset(), ::lock()"
              << std::endl;
    return;
  }

  _storedItems.clear();
  gDrawMgr->clearCurrentRendererTarget(_clearColor);
}

void FBO::addWidget(const Widget &widget) {
  if (!widget.isCreated()) {
    std::cerr
        << "Widget is not created, therefore -> it could not be added to FBO"
        << std::endl;
    return;
  }
  _storedItems.emplace_back(widget.getDrawParams());
}

void FBO::update() {
  if (_isLocked) {
    std::cerr << "Error, FBO::update() failed, because FBO is still locked. "
              "Consider using the sequence " "::unlock(), ::update(), ::lock()"
              << std::endl;
    return;
  }

  gDrawMgr->updateCurrRendererTarget(_storedItems.data(), _storedItems.size());
}

