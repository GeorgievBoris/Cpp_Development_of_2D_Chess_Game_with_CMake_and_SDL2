//Corresponding header
#include "game/game_entities/board/GameBoard.h"

//C system headers

//C++ system headers
#include <cstdlib>

//Other libraries headers

//Own components headers
#include "game/game_entities/utils/BoardUtils.h"

int32_t GameBoard::init(int32_t boardRsrcId, int32_t targetRsrcId) {
  _boardImg.create(boardRsrcId);
  _targetImg.create(targetRsrcId);
  _targetImg.hide();

  return EXIT_SUCCESS;
}

void GameBoard::deinit() {
}

void GameBoard::draw() {
  _boardImg.draw();
  _targetImg.draw();
}

void GameBoard::onPieceGrabbed(const BoardPos &boardPos) {
  _targetImg.setPosition(BoardUtils::getAbsPos(boardPos));
  _targetImg.show();
}

void GameBoard::onPieceUngrabbed() {
  _targetImg.hide();
}
