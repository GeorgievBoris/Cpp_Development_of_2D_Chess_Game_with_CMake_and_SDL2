#ifndef UTILS_COMMON_DEBUGCONSOLE_H_
#define UTILS_COMMON_DEBUGCONSOLE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Text.h"

//Forward declarations
class InputEvent;

class DebugConsole {
public:
  int32_t init(uint32_t maxFrames);

  /** @ brief used to toggle active/inactive status of the debug console
   * */
  void handleEvent(const InputEvent &e);

  void update(int64_t elapsedMicroseconds);

  void draw();

  bool isActive() const;

private:
  Text _fpsText;

  uint32_t _maxFrames = 0;

  int32_t _updateCounter = 0;

  bool _isActive = false;
};

#endif /* UTILS_COMMON_DEBUGCONSOLE_H_ */

