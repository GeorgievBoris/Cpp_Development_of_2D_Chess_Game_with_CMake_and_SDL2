#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"
#include "utils/drawing/DrawParams.h"

//Forward declarations
class InputEvent;
class ImageContainer;

class Game {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw(std::vector<DrawParams> &outDrawParams);

  void handleEvent(const InputEvent &e);

private:
  DrawParams _gameImg;

  //TODO remove me
  const ImageContainer *_imageContainer = nullptr;
};

#endif /* GAME_GAME_H_ */
