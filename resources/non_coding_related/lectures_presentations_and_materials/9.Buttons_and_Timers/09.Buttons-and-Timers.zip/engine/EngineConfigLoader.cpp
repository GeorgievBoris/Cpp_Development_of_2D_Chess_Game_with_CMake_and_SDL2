//Corresponding header
#include "engine/EngineConfigLoader.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "common/CommonDefines.h"
#include "common/Timers.h"

//constants
namespace {
//Screen dimension constants
constexpr auto DISPLAY_MODE = 4; //SDL_WINDOW_SHOWN from <SDL_video.h>
constexpr auto SCREEN_WIDTH = 1024;
constexpr auto SCREEN_HEIGHT = 800;
constexpr auto WINDOW_NAME = "C++_App_Dev";

constexpr auto MAX_FRAMES = 60;

constexpr auto RUNNING_GIRL_FRAMES = 6;
constexpr auto RUNNING_GIRL_FRAME_WIDTH = 256;
constexpr auto RUNNING_GIRL_FRAME_HEIGHT = 220;

constexpr auto WHEEL_WIDTH_HEIGHT_DIMENSIONS = 695;

constexpr auto RUNNING_FRAMES = 3;
constexpr auto BUTTON_FRAME_WIDTH = 150;
constexpr auto BUTTON_FRAME_HEIGHT = 50;

void populateDrawMgrCfg(DrawMgrConfig &cfg) {
  cfg.windowCfg.displayMode = DISPLAY_MODE;
  cfg.windowCfg.windowWidth = SCREEN_WIDTH;
  cfg.windowCfg.windowHeight = SCREEN_HEIGHT;
  cfg.windowCfg.windowName = WINDOW_NAME;
  cfg.maxFrames = MAX_FRAMES;
}

void populateImageContainerCfg(ImageContainerConfig &cfg) {
  ImageConfig currImgCfg;
  currImgCfg.location = "../resources/p/sprites/running_girl_small.png";
  currImgCfg.frames.reserve(RUNNING_GIRL_FRAMES);
  for (auto i = 0; i < RUNNING_GIRL_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * RUNNING_GIRL_FRAME_WIDTH, 0,
        RUNNING_GIRL_FRAME_WIDTH, RUNNING_GIRL_FRAME_HEIGHT);
  }
  cfg.imageConfigs.emplace(Textures::RUNNING_GIRL, currImgCfg);

  currImgCfg.location = "../resources/p/wheel.png";
  currImgCfg.frames.clear();
  currImgCfg.frames.emplace_back(0, 0, WHEEL_WIDTH_HEIGHT_DIMENSIONS,
      WHEEL_WIDTH_HEIGHT_DIMENSIONS);
  cfg.imageConfigs.emplace(Textures::WHEEL, currImgCfg);

  currImgCfg.location = "../resources/p/buttons/button_start.png";
  currImgCfg.frames.clear();
  for (auto i = 0; i < RUNNING_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * BUTTON_FRAME_WIDTH, 0,
        BUTTON_FRAME_WIDTH, BUTTON_FRAME_HEIGHT);
  }
  cfg.imageConfigs.emplace(Textures::WHEEL_START_BUTTON, currImgCfg);

  currImgCfg.location = "../resources/p/buttons/button_stop.png";
  currImgCfg.frames.clear();
  for (auto i = 0; i < RUNNING_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * BUTTON_FRAME_WIDTH, 0,
        BUTTON_FRAME_WIDTH, BUTTON_FRAME_HEIGHT);
  }
  cfg.imageConfigs.emplace(Textures::WHEEL_STOP_BUTTON, currImgCfg);
}

void populateTextContainerCfg(TextContainerConfig &cfg) {
  FontConfig currFontCfg;
  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 25;
  cfg.fontConfigs.emplace(Fonts::ANGELINE_VINTAGE_SMALL, currFontCfg);

  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 50;
  cfg.fontConfigs.emplace(Fonts::ANGELINE_VINTAGE_BIG, currFontCfg);
}

void populateGameConfig(GameConfig &cfg) {
  cfg.heroRsrcId = Textures::RUNNING_GIRL;
  cfg.wheelRsrcId = Textures::WHEEL;
  cfg.wheelStartBtnRsrcId = Textures::WHEEL_START_BUTTON;
  cfg.wheelStopBtnRsrcId = Textures::WHEEL_STOP_BUTTON;
  cfg.wheelRotAnimTimerId = Timers::WHEEL_ANIM_TIMER_ID;
}

}

EngineConfig EngineConfigLoader::loadConfig() {
  EngineConfig cfg;

  populateDrawMgrCfg(cfg.mgrHandlerCfg.drawMgrCfg);
  populateImageContainerCfg(cfg.mgrHandlerCfg.rsrcMgrCfg.imageContainerCfg);
  populateTextContainerCfg(cfg.mgrHandlerCfg.rsrcMgrCfg.textContainerCfg);
  populateGameConfig(cfg.gameCfg);

  return cfg;
}
