//Corresponding header
#include "game/game_entities/board/GameBoard.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "game/game_entities/utils/BoardUtils.h"

int32_t GameBoard::init(int32_t boardRsrcId, int32_t targetRsrcId,
                        int32_t moveTileRsrcId) {
  if (EXIT_SUCCESS != _moveSelector.init(moveTileRsrcId)) {
    std::cerr << "Error, _moveSelector.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  _boardImg.create(boardRsrcId);
  _targetImg.create(targetRsrcId);
  _targetImg.hide();

  return EXIT_SUCCESS;
}

void GameBoard::deinit() {
}

void GameBoard::draw() {
  _boardImg.draw();
  _targetImg.draw();
  _moveSelector.draw();
}

Image* GameBoard::getBoardImg() {
  return &_boardImg;
}

void GameBoard::onPieceGrabbed(const BoardPos &boardPos,
                               const std::vector<TileData> &moveTiles) {
  _targetImg.setPosition(BoardUtils::getAbsPos(boardPos));
  _targetImg.show();

  _activeMoveTiles = moveTiles;
  _moveSelector.markTiles(moveTiles);
}

void GameBoard::onPieceUngrabbed() {
  _targetImg.hide();
  _moveSelector.unmarkTiles();
  _activeMoveTiles.clear();
}

bool GameBoard::isMoveAllowed(const BoardPos &pos) const {
  for (const auto &moveTile : _activeMoveTiles) {
    if (moveTile.boardPos == pos) {
      if (TileType::MOVE == moveTile.tileType ||
          TileType::TAKE == moveTile.tileType) {
        return true;
      }
    }
  }

  return false;
}


