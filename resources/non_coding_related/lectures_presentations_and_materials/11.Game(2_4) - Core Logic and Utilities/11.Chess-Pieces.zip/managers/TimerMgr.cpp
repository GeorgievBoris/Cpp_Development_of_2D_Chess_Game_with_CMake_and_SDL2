//Corresponding header
#include "managers/TimerMgr.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "utils/time/TimerClient.h"

TimerMgr *gTimerMgr = nullptr;

int32_t TimerMgr::init() {
  return EXIT_SUCCESS;
}

void TimerMgr::deinit() {
}

void TimerMgr::process() {
  const int64_t msElapsed = _elapsedTime.getElapsed().toMilliseconds();

  for (auto it = _timerMap.begin(); it != _timerMap.end(); ++it) {
    it->second.remaining -= msElapsed;
    if (0 > it->second.remaining) {
      onTimerTimeout(it->first, it->second);
    }
  }

  removeTimersInternal();
}

void TimerMgr::startTimer(TimerClient *tcIstance, int64_t interval,
                          int32_t timerId, TimerType timerType) {
  //The check for isActiveTimerId is invoked from TimerClient class

  //at start the remaining interval is equal to whole interval
  const TimerData timerData(interval,   //original interval
      interval,   //remaining interval
      timerType,  //ONESHOT or PULSE
      tcIstance); //TimerClient instance

  _timerMap.emplace(timerId, timerData);
}

void TimerMgr::stopTimer(int32_t timerId) {
  if (isActiveTimerId(timerId)) {
    _removeTimerSet.insert(timerId);
  } else {
    std::cerr
        << "Warning, trying to remove a non-existing timer with ID: " << timerId
        << ". Be sure to check your timerId with .isActiveTimerId(timerId) "
        "before calling .stopTimer(timerId)"
        << std::endl;
  }
}

void TimerMgr::detachTimerClient(int32_t timerId) {
  if (isActiveTimerId(timerId)) {
    _removeTimerSet.insert(timerId);
  }
}

bool TimerMgr::isActiveTimerId(int32_t timerId) const {
  return (_removeTimerSet.end() == _removeTimerSet.find(timerId))
      && (_timerMap.end() != _timerMap.find(timerId));
}

void TimerMgr::onTimerTimeout(int32_t timerId, TimerData &timerData) {
  timerData.tcInstance->onTimeout(timerId);

  if (timerData.timerType == TimerType::ONESHOT) {
    //If timer was on TimerType::ONESHOT it should close on it's own
    _removeTimerSet.insert(timerId);
    return;
  }

  //at this point remaining will be zero or negative value
  //we need to restart the remaining time while taking into account
  //that the timer probably postponed the original entered user interval
  //Example: timerData.interval = 5000ms;
  //process() is called every 2000ms.
  //after first process()  -> remaining interval is +3000ms;
  //after second process() -> remaining interval is +1000ms;
  //after third process()  -> remaining interval is -1000ms;
  //at this point execute function callback and if TimerTime is set to PULSE
  //restart timer's remaining interval to original interval (5000ms)
  //minus the postponed period (-1000ms) ->
  //new remaining interval value is 5000ms - 1000ms = 4000ms
  timerData.remaining += timerData.interval;
}

void TimerMgr::onInitEnd() {
//reset the timer so it can clear the "stored" time since the creation
//of the TimerMgr instance and this function call
  _elapsedTime.getElapsed();
}

void TimerMgr::removeTimersInternal() {
  for (const int32_t timerId : _removeTimerSet) {
    auto mapIt = _timerMap.find(timerId);
    if (mapIt != _timerMap.end()) {
      _timerMap.erase(mapIt);
    }
  }

  //clear the removeTimerSet
  _removeTimerSet.clear();
}

