#ifndef COMMON_COMMONDEFINES_H_
#define COMMON_COMMONDEFINES_H_

namespace Textures {
enum Images {
  WHEEL,
  RUNNING_GIRL,
  TEST
};
} //namespace Textures

namespace Fonts {
enum FontId {
  ANGELINE_VINTAGE_SMALL,
  ANGELINE_VINTAGE_BIG
};
} //namespace Fonts

#endif /* COMMON_COMMONDEFINES_H_ */
