//Corresponding header
#include "TimerClient.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/TimerMgr.h"

namespace {
constexpr auto MIN_TIMER_INTERNAL = 20;
}

void TimerClient::startTimer(int64_t interval, int32_t timerId,
                             TimerType timerType) {
  //if timer already exists -> do not start it
  if (gTimerMgr->isActiveTimerId(timerId)) {
    std::cerr << "Warning, timer with Id: " << timerId << " already exist. "
              "Will not start new timer"
              << std::endl;
    return;
  }

  if (interval < MIN_TIMER_INTERNAL) {
    std::cerr << "Warning, timer with timerId: " << timerId
              << " requested startTimer() with "
              "interval %ld, while minimum interval is "
              << MIN_TIMER_INTERNAL << ". Timer will not "
              "be started!"
              << std::endl;
    return;
  }

  gTimerMgr->startTimer(this,       //TimerClient instance
      interval,   //interval
      timerId,    //remaining interval
      timerType); //timer type
}

void TimerClient::stopTimer(int32_t timerId) {
  gTimerMgr->stopTimer(timerId);
}

bool TimerClient::isActiveTimerId(int32_t timerId) const {
  return gTimerMgr->isActiveTimerId(timerId);
}

