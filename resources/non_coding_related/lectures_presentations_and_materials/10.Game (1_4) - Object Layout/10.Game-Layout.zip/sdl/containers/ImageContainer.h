#ifndef SDL_CONTAINERS_IMAGECONTAINER_H_
#define SDL_CONTAINERS_IMAGECONTAINER_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <unordered_map>
#include <vector>

//Other libraries headers

//Own components headers
#include "utils/drawing/Rectangle.h"

//Forward declarations
struct SDL_Texture;
struct ImageContainerConfig;

using Frames = std::vector<Rectangle>;

class ImageContainer {
public:
  SDL_Texture* getImageTexture(int32_t rsrcId) const;

  const Frames& getImageFrames(int32_t rsrcId) const;

protected:
  int32_t init(const ImageContainerConfig &cfg);

  void deinit();

private:
  int32_t loadSingleTexture(const char *filePath, int32_t textureId);

  //the textures we'll be drawing
  std::unordered_map<int32_t, SDL_Texture*> _textures;

  std::unordered_map<int32_t, Frames> _textureFrames;
};

#endif /* SDL_CONTAINERS_IMAGECONTAINER_H_ */
