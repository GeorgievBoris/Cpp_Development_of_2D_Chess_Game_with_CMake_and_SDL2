#ifndef SDL_MONITORWINDOW_H_
#define SDL_MONITORWINDOW_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Rectangle.h"

//Forward declarations
struct SDL_Window;
struct MonitorWindowConfig;

class MonitorWindow {
public:
  MonitorWindow() = default;

  //forbid the copy and move constructors
  MonitorWindow(const MonitorWindow &other) = delete;
  MonitorWindow(MonitorWindow &&other) = delete;

  //forbid the copy and move assignment operators
  MonitorWindow& operator=(const MonitorWindow &other) = delete;
  MonitorWindow& operator=(MonitorWindow &&other) = delete;

  ~MonitorWindow();

  int32_t init(const MonitorWindowConfig &cfg);

  void deinit();

  SDL_Window *getWindow() const;

private:
  //The actual window
  SDL_Window *_window = nullptr;
  Rectangle _windowRect = Rectangle::UNDEFINED;
};

#endif /* SDL_MONITORWINDOW_H_ */
