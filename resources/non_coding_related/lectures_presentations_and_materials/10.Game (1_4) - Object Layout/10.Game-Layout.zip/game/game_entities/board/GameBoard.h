#ifndef GAME_GAME_ENTITIES_GAMEBOARD_H_
#define GAME_GAME_ENTITIES_GAMEBOARD_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/proxies/GameBoardInterface.h"
#include "utils/drawing/Image.h"

//Forward declarations

class GameBoard : public GameBoardInterface {
public:
  int32_t init(int32_t boardRsrcId, int32_t targetRsrcId);

  void deinit();

  void draw();

private:
  void onPieceGrabbed(const BoardPos &boardPos) final;
  void onPieceUngrabbed() final;

  Image _boardImg;
  Image _targetImg;
};

#endif /* GAME_GAME_ENTITIES_GAMEBOARD_H_ */
