#ifndef GAME_GAME_ENTITIES_UTILS_BOARDPOS_H_
#define GAME_GAME_ENTITIES_UTILS_BOARDPOS_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers

//Forward declarations
#include "utils/drawing/Point.h"

struct BoardPos {
  BoardPos(const Point &boardPos);
  BoardPos(int32_t row, int32_t col);

  int32_t row;
  int32_t col;
};

#endif /* GAME_GAME_ENTITIES_UTILS_BOARDPOS_H_ */
