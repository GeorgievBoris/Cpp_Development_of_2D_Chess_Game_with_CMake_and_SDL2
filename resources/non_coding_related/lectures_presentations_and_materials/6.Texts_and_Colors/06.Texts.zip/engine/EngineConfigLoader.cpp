//Corresponding header
#include "engine/EngineConfigLoader.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "common/CommonDefines.h"

//constants
namespace {
//Screen dimension constants
constexpr auto DISPLAY_MODE = 4; //SDL_WINDOW_SHOWN from <SDL_video.h>
constexpr auto SCREEN_WIDTH = 800;
constexpr auto SCREEN_HEIGHT = 600;
constexpr auto WINDOW_NAME = "C++_App_Dev";
}

EngineConfig EngineConfigLoader::loadConfig() {
  EngineConfig cfg;

  cfg.windowCfg.displayMode = DISPLAY_MODE;
  cfg.windowCfg.windowWidth = SCREEN_WIDTH;
  cfg.windowCfg.windowHeight = SCREEN_HEIGHT;
  cfg.windowCfg.windowName = WINDOW_NAME;

  ImageConfig currImgCfg;
  currImgCfg.location = "../resources/p/press_keys.png";
  currImgCfg.width = 640;
  currImgCfg.height = 480;
  cfg.imageContainerCfg.imageConfigs.emplace(Textures::PRESS_KEYS, currImgCfg);

  FontConfig currFontCfg;
  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 25;
  cfg.textContainerCfg.fontConfigs.emplace(Fonts::ANGELINE_VINTAGE_SMALL,
      currFontCfg);

  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 50;
  cfg.textContainerCfg.fontConfigs.emplace(Fonts::ANGELINE_VINTAGE_BIG,
      currFontCfg);

  return cfg;
}
