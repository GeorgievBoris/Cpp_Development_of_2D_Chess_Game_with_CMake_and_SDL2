#ifndef GAME_GAME_ENTITIES_PIECEHANDLER_H_
#define GAME_GAME_ENTITIES_PIECEHANDLER_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <array>
#include <memory>

//Other libraries headers

//Own components headers
#include "game/defines/ChessDefines.h"
#include "game/game_entities/pieces/PieceHandlerPopulator.h"

//Forward declarations
class InputEvent;
class GameBoardInterface;

class PieceHandler {
public:
  int32_t init(GameBoardInterface *gameBoardInterface,
               int32_t whitePiecesRsrcId, int32_t blackPiecesRsrcId,
               int32_t notReadyFontRsrcId);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  void handlePieceGrabbedEvent(const InputEvent &e);
  void handleNoPieceGrabbedEvent(const InputEvent &e);

  void doMovePiece(const BoardPos &boardPos);

  std::array<ChessPiece::PlayerPieces, Defines::PLAYERS_COUNT> _pieces;

  GameBoardInterface *_gameBoardInterface = nullptr;

  int32_t _selectedPieceId = 0;
  int32_t _selectedPiecePlayerId = 0;
  bool _isPieceGrabbed = false;
};

#endif /* GAME_GAME_ENTITIES_PIECEHANDLER_H_ */
