#ifndef GAME_GAME_ENTITIES_PIECES_PIECEHANDLERPOPULATOR_H_
#define GAME_GAME_ENTITIES_PIECES_PIECEHANDLERPOPULATOR_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <memory>

//Other libraries headers

//Own components headers
#include "game/game_entities/pieces/ChessPiece.h"

//Forward declarations
class GameBoardInterface;
class GameInterface;

class PieceHandlerPopulator {
public:
  PieceHandlerPopulator() = delete;

  static int32_t populateWhitePieces(GameInterface *gameInterface,
                                     ChessPiece::PlayerPieces &whites,
                                     int32_t rsrcId, int32_t fontId);
  static int32_t populateBlackPieces(GameInterface *gameInterface,
                                     ChessPiece::PlayerPieces &blacks,
                                     int32_t rsrcId, int32_t fontId);
};

#endif /* GAME_GAME_ENTITIES_PIECES_PIECEHANDLERPOPULATOR_H_ */
