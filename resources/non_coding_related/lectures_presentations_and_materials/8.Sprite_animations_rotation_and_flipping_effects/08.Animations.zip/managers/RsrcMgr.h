#ifndef MANAGERS_RSRCMGR_H_
#define MANAGERS_RSRCMGR_H_

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "managers/MgrBase.h"

#include "sdl/containers/ImageContainer.h"
#include "sdl/containers/TextContainer.h"

//Forward declarations
struct RsrcMgrConfig;

class RsrcMgr: public MgrBase,
               public ImageContainer,
               public TextContainer {
public:
  RsrcMgr() = default;

  //forbid the copy and move constructors
  RsrcMgr(const RsrcMgr &other) = delete;
  RsrcMgr(RsrcMgr &&other) = delete;

  //forbid the copy and move assignment operators
  RsrcMgr& operator=(const RsrcMgr &other) = delete;
  RsrcMgr& operator=(RsrcMgr &&other) = delete;

  int32_t init(const RsrcMgrConfig &cfg);

  void deinit() final;

  void process() final;
};

extern RsrcMgr *gRsrcMgr;

#endif /* MANAGERS_RSRCMGR_H_ */
