//Corresponding header
#include "game/game_entities/Wheel.h"

//C system headers

//C++ system headers
#include <cstdlib>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"

int32_t Wheel::init(int32_t WheelRsrcId) {
  _wheel.create(WheelRsrcId);

  return EXIT_SUCCESS;
}

void Wheel::deinit() {

}

void Wheel::draw() {
  _wheel.draw();
}

void Wheel::handleEvent(const InputEvent &e) {
  if (TouchEvent::KEYBOARD_PRESS == e.type) {
    switch (e.key) {
    case Keyboard::KEY_K:
      _wheel.setRotation(_wheel.getRotation() - 15);
      break;
    case Keyboard::KEY_L:
      _wheel.setRotation(_wheel.getRotation() + 15);
      break;
    case Keyboard::KEY_H:
      _wheel.setRotationCenter(Point::ZERO);
      break;
    case Keyboard::KEY_J:
      _wheel.setRotationCenter(
          Point( (_wheel.getWidth() / 2) + 1, (_wheel.getHeight() / 2) + 1));
      break;
    default:
      break;
    }
  }
}
