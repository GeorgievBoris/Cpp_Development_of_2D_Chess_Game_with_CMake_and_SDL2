//Corresponding header
#include "game/game_entities/pieces/PieceHandler.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "game/game_entities/utils/BoardUtils.h"
#include "game/proxies/GameBoardInterface.h"

namespace {
constexpr auto STARTING_PIECES_COUNT = 16;
constexpr auto PAWNS_COUNT = 8;

constexpr auto WHITE_PLAYER_START_PAWN_ROW = 6;
constexpr auto BLACK_PLAYER_START_PAWN_ROW = 1;
}

int32_t PieceHandler::init(GameBoardInterface *gameBoardInterface,
                           int32_t whitePiecesRsrcId,
                           int32_t blackPiecesRsrcId) {
  if (!gameBoardInterface) {
    std::cerr << "Error, nullptr GameBoardInterface provided" << std::endl;
    return EXIT_FAILURE;
  }
  _gameBoardInterface = gameBoardInterface;

  if (EXIT_SUCCESS != populateWhitePieces(whitePiecesRsrcId)) {
    std::cerr << "Error, populateWhitePieces() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != populateBlackPieces(blackPiecesRsrcId)) {
    std::cerr << "Error, populateBlackPieces() failed" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void PieceHandler::deinit() {

}

void PieceHandler::draw() {
  for (auto &playerPieces : _pieces) {
    for (auto &piece : playerPieces) {
      piece.draw();
    }
  }
}

void PieceHandler::handleEvent(const InputEvent &e) {
  _isPieceGrabbed ? handlePieceGrabbedEvent(e) : handleNoPieceGrabbedEvent(e);
}

void PieceHandler::handlePieceGrabbedEvent(const InputEvent &e) {
  if (TouchEvent::TOUCH_RELEASE != e.type) {
    return;
  }
  _isPieceGrabbed = false;

  if (BoardUtils::isInsideBoard(e.pos)) {
    const BoardPos boardPos = BoardUtils::getBoardPos(e.pos);
    _pieces[_selectedPiecePlayerId][_selectedPieceId].setBoardPos(boardPos);
    _gameBoardInterface->onPieceUngrabbed();
  }
}

void PieceHandler::handleNoPieceGrabbedEvent(const InputEvent &e) {
  if (TouchEvent::TOUCH_RELEASE != e.type) {
    return;
  }

  for (int32_t playerId = 0; playerId < Defines::PLAYERS_COUNT; ++playerId) {
    int32_t pieceId = 0;
    for (auto &piece : _pieces[playerId]) {
      if (piece.containsEvent(e)) {
        _isPieceGrabbed = true;
        _selectedPiecePlayerId = playerId;
        _selectedPieceId = pieceId;
        _gameBoardInterface->onPieceGrabbed(piece.getBoardPos());
        return;
      }
      ++pieceId;
    }
  }
}

int32_t PieceHandler::populateWhitePieces(int32_t rscId) {
  constexpr auto playerId = Defines::WHITE_PLAYER;
  auto &whites = _pieces[playerId];
  whites.reserve(STARTING_PIECES_COUNT);

  for (auto i = 0; i < PAWNS_COUNT; ++i) {
    whites.emplace_back(rscId, BoardPos(WHITE_PLAYER_START_PAWN_ROW, i),
        PieceType::PAWN, playerId);
  }
  whites.emplace_back(rscId, BoardPos(7, 4), PieceType::KING, playerId);
  whites.emplace_back(rscId, BoardPos(7, 3), PieceType::QUEEN, playerId);
  whites.emplace_back(rscId, BoardPos(7, 0), PieceType::ROOK, playerId);
  whites.emplace_back(rscId, BoardPos(7, 7), PieceType::ROOK, playerId);
  whites.emplace_back(rscId, BoardPos(7, 2), PieceType::BISHOP, playerId);
  whites.emplace_back(rscId, BoardPos(7, 5), PieceType::BISHOP, playerId);
  whites.emplace_back(rscId, BoardPos(7, 1), PieceType::KNIGHT, playerId);
  whites.emplace_back(rscId, BoardPos(7, 6), PieceType::KNIGHT, playerId);

  return EXIT_SUCCESS;
}

int32_t PieceHandler::populateBlackPieces(int32_t rscId) {
  constexpr auto playerId = Defines::BLACK_PLAYER;
  auto &blacks = _pieces[playerId];
  blacks.reserve(STARTING_PIECES_COUNT);

  for (auto i = 0; i < PAWNS_COUNT; ++i) {
    blacks.emplace_back(rscId, BoardPos(BLACK_PLAYER_START_PAWN_ROW, i),
        PieceType::PAWN, playerId);
  }
  blacks.emplace_back(rscId, BoardPos(0, 4), PieceType::KING, playerId);
  blacks.emplace_back(rscId, BoardPos(0, 3), PieceType::QUEEN, playerId);
  blacks.emplace_back(rscId, BoardPos(0, 0), PieceType::ROOK, playerId);
  blacks.emplace_back(rscId, BoardPos(0, 7), PieceType::ROOK, playerId);
  blacks.emplace_back(rscId, BoardPos(0, 2), PieceType::BISHOP, playerId);
  blacks.emplace_back(rscId, BoardPos(0, 5), PieceType::BISHOP, playerId);
  blacks.emplace_back(rscId, BoardPos(0, 1), PieceType::KNIGHT, playerId);
  blacks.emplace_back(rscId, BoardPos(0, 6), PieceType::KNIGHT, playerId);

  return EXIT_SUCCESS;
}
