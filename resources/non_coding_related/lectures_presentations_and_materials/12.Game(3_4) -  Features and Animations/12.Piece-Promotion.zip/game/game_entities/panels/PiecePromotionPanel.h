#ifndef GAME_GAME_ENTITIES_PANELS_PIECEPROMOTIONPANEL_H_
#define GAME_GAME_ENTITIES_PANELS_PIECEPROMOTIONPANEL_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <array>

//Other libraries headers

//Own components headers
#include "game/game_entities/panels/config/PiecePromotionPanelConfig.h"
#include "game/game_entities/panels/buttons/PiecePromotionButton.h"

//Forward declarations
class InputEvent;
class GameInterface;

class PiecePromotionPanel {
public:
  int32_t init(const PiecePromotionPanelConfig &cfg);

  void handleEvent(const InputEvent &e);

  void draw();

  void activate(int32_t playerId);

  bool isActive() const;

private:
  void onBtnClicked(PieceType pieceType);

  enum InternalDefines {
      BUTTONS_COUNT = 4
  };

  std::array<PiecePromotionButton, BUTTONS_COUNT> _promotionBtns;
  GameInterface * _gameInterface = nullptr;
  bool _isActive = false;
};

#endif /* GAME_GAME_ENTITIES_PANELS_PIECEPROMOTIONPANEL_H_ */
