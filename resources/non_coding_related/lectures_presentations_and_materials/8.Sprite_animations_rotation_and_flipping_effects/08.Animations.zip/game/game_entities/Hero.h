#ifndef GAME_GAME_ENTITIES_HERO_H_
#define GAME_GAME_ENTITIES_HERO_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"

//Forward declarations
class InputEvent;

class Hero {
public:
  int32_t init(int32_t heroRsrcId);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  Image _hero;
};

#endif /* GAME_GAME_ENTITIES_HERO_H_ */
