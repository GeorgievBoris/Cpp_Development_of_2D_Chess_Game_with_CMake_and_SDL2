#ifndef GAME_GAME_ENTITIES_BOARD_GAMEBOARDANIMATOR_H_
#define GAME_GAME_ENTITIES_BOARD_GAMEBOARDANIMATOR_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"

//Forward declarations
class GameInterface;

class GameBoardAnimator {
public:
  int32_t init(GameInterface *gameInterface, Image *boardImg);

  void startAnim(int32_t playerId);

private:
  void onAnimEnd();

  GameInterface *_gameInterface = nullptr;
  Image *_boardImg = nullptr;
  int32_t _currRotation { 0 };
  WidgetFlip _targetFlipType = WidgetFlip::NONE;
};

#endif /* GAME_GAME_ENTITIES_BOARD_GAMEBOARDANIMATOR_H_ */
