//Corresponding header
#include "managers/MgrHandler.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/config/MgrHandlerConfig.h"
#include "managers/DrawMgr.h"
#include "managers/RsrcMgr.h"

int32_t MgrHandler::init(const MgrHandlerConfig &cfg) {
  //gDrawMgr should be initialized first, because it contains the renderer
  //Other managers may want to load graphical resources
  gDrawMgr = new DrawMgr;
  if (nullptr == gDrawMgr) {
    std::cerr << "Error, bad alloc for DrawMgr" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != gDrawMgr->init(cfg.drawMgrCfg)) {
    std::cerr << "gDrawMgr->init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  gRsrcMgr = new RsrcMgr;
  if (nullptr == gRsrcMgr) {
    std::cerr << "Error, bad alloc for RsrcMgr" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != gRsrcMgr->init(cfg.rsrcMgrCfg)) {
    std::cerr << "gRsrcMgr->init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  //put global managers into container so they can be easily iterated
  //and used polymorphically
  _managers[Managers::DRAW_MGR_IDX] = gDrawMgr;
  _managers[Managers::RSRC_MGR_IDX] = gRsrcMgr;

  return EXIT_SUCCESS;
}

void MgrHandler::deinit() {
  /** Following the logic that DrawMgr should be initialized first ->
   * it should be deinitialized last
   * / a.k.a. last one to shut the door :) /
   * */
  for (int32_t i = Managers::TOTAL_MGRS_COUNT - 1; i >= 0; --i) {
    if (_managers[i]) { //Sanity check
      _managers[i]->deinit();

      delete _managers[i];
      _managers[i] = nullptr;

      nullifyGlobalManager(i);
    }
  }
}

void MgrHandler::process() {
  for (int32_t i = 0; i < Managers::TOTAL_MGRS_COUNT; ++i) {
    _managers[i]->process();
  }
}

void MgrHandler::nullifyGlobalManager(const int32_t managerId) {
  /** Explicitly set the singleton pointer to nullptr, because someone might
   * still try to use them -> if so, the sanity checks should catch them
   * */
  switch (managerId) {
  case Managers::DRAW_MGR_IDX:
    gDrawMgr = nullptr;
    break;

  case Managers::RSRC_MGR_IDX:
    gRsrcMgr = nullptr;
    break;

  default:
    std::cerr << "Unknown managerId: " << managerId << " provided" << std::endl;
    break;
  }
}

