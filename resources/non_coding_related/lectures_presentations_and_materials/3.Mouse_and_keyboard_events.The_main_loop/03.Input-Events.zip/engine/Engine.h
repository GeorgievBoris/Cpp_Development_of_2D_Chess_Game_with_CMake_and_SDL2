#ifndef ENGINE_ENGINE_H_
#define ENGINE_ENGINE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "sdl/MonitorWindow.h"
#include "sdl/InputEvent.h"

//Forward declarations
struct SDL_Surface;

class Engine {
public:
  int32_t init();

  void deinit();

  void start();

private:
  enum Images {
    UP, DOWN, LEFT, RIGHT, ALL_KEYS, COUNT
  };

  void mainLoop();

  void drawFrame();

  bool processFrame();

  void handleEvent();

  void limitFPS(const int64_t elapsedMicroseconds);

  MonitorWindow _window;
  InputEvent _event;
  SDL_Surface *_screenSurface = nullptr;
  SDL_Surface *_currChosenImage = nullptr;
  SDL_Surface *_imageSurfaces[COUNT] {};
};

#endif /* ENGINE_ENGINE_H_ */
