//Corresponding header
#include "engine/EngineConfigLoader.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "common/CommonDefines.h"

//constants
namespace {
//Screen dimension constants
constexpr auto DISPLAY_MODE = 4; //SDL_WINDOW_SHOWN from <SDL_video.h>
constexpr auto SCREEN_WIDTH = 1024;
constexpr auto SCREEN_HEIGHT = 800;
constexpr auto WINDOW_NAME = "C++_App_Dev";

constexpr auto MAX_FRAMES = 60;

constexpr auto RUNNING_GIRL_FRAMES = 6;
constexpr auto RUNNING_GIRL_FRAME_WIDTH = 256;
constexpr auto RUNNING_GIRL_FRAME_HEIGHT = 220;

constexpr auto WHEEL_WIDTH_HEIGHT_DIMENSIONS = 695;
}

EngineConfig EngineConfigLoader::loadConfig() {
  EngineConfig cfg;

  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.displayMode = DISPLAY_MODE;
  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.windowWidth = SCREEN_WIDTH;
  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.windowHeight = SCREEN_HEIGHT;
  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.windowName = WINDOW_NAME;
  cfg.mgrHandlerCfg.drawMgrCfg.maxFrames = MAX_FRAMES;

  ImageConfig currImgCfg;
  currImgCfg.location = "../resources/p/sprites/running_girl_small.png";
  currImgCfg.frames.reserve(RUNNING_GIRL_FRAMES);
  for (auto i = 0; i < RUNNING_GIRL_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * RUNNING_GIRL_FRAME_WIDTH, 0,
        RUNNING_GIRL_FRAME_WIDTH, RUNNING_GIRL_FRAME_HEIGHT);
  }
  cfg.mgrHandlerCfg.rsrcMgrCfg.imageContainerCfg.imageConfigs.emplace(
      Textures::RUNNING_GIRL, currImgCfg);

  currImgCfg.location = "../resources/p/wheel.png";
  currImgCfg.frames.clear();
  currImgCfg.frames.emplace_back(0, 0, WHEEL_WIDTH_HEIGHT_DIMENSIONS,
      WHEEL_WIDTH_HEIGHT_DIMENSIONS);
  cfg.mgrHandlerCfg.rsrcMgrCfg.imageContainerCfg.imageConfigs.emplace(
      Textures::WHEEL, currImgCfg);

  cfg.gameCfg.heroRsrcId = Textures::RUNNING_GIRL;
  cfg.gameCfg.wheelRsrcId = Textures::WHEEL;

  FontConfig currFontCfg;
  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 25;
  cfg.mgrHandlerCfg.rsrcMgrCfg.textContainerCfg.fontConfigs.emplace(
      Fonts::ANGELINE_VINTAGE_SMALL, currFontCfg);

  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 50;
  cfg.mgrHandlerCfg.rsrcMgrCfg.textContainerCfg.fontConfigs.emplace(
      Fonts::ANGELINE_VINTAGE_BIG, currFontCfg);

  return cfg;
}
