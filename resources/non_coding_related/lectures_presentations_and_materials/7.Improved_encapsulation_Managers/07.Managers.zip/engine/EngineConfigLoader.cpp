//Corresponding header
#include "engine/EngineConfigLoader.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "common/CommonDefines.h"

//constants
namespace {
//Screen dimension constants
constexpr auto DISPLAY_MODE = 4; //SDL_WINDOW_SHOWN from <SDL_video.h>
constexpr auto SCREEN_WIDTH = 800;
constexpr auto SCREEN_HEIGHT = 600;
constexpr auto WINDOW_NAME = "C++_App_Dev";

constexpr auto MAX_FRAMES = 60;
}

EngineConfig EngineConfigLoader::loadConfig() {
  EngineConfig cfg;

  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.displayMode = DISPLAY_MODE;
  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.windowWidth = SCREEN_WIDTH;
  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.windowHeight = SCREEN_HEIGHT;
  cfg.mgrHandlerCfg.drawMgrCfg.windowCfg.windowName = WINDOW_NAME;
  cfg.mgrHandlerCfg.drawMgrCfg.maxFrames = MAX_FRAMES;

  ImageConfig currImgCfg;
  currImgCfg.location = "../resources/p/press_keys.png";
  currImgCfg.width = 640;
  currImgCfg.height = 480;
  cfg.mgrHandlerCfg.rsrcMgrCfg.imageContainerCfg.imageConfigs.emplace(
      Textures::PRESS_KEYS, currImgCfg);

  FontConfig currFontCfg;
  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 25;
  cfg.mgrHandlerCfg.rsrcMgrCfg.textContainerCfg.fontConfigs.emplace(
      Fonts::ANGELINE_VINTAGE_SMALL, currFontCfg);

  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 50;
  cfg.mgrHandlerCfg.rsrcMgrCfg.textContainerCfg.fontConfigs.emplace(
      Fonts::ANGELINE_VINTAGE_BIG, currFontCfg);

  return cfg;
}
