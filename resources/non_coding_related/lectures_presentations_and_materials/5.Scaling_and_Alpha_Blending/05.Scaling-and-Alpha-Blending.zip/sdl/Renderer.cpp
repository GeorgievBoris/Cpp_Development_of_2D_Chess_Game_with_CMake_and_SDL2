//Corresponding header
#include "sdl/Renderer.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include <SDL_render.h>
#include <SDL_hints.h>

//Own components headers
#include "sdl/Texture.h"

int32_t Renderer::init(SDL_Window *window) {
  /** Set texture filtering to linear
   *                      (used for image scaling /pixel interpolation/ )
   * */
  if (!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1")) {
    std::cerr << "Warning: Linear texture filtering not enabled! "
           "SDL_SetHint() failed. SDL Error: " << SDL_GetError() << std::endl;
    return EXIT_FAILURE;
  }

  constexpr auto unspecifiedRendererDriver = -1;

  //Create renderer for window
  _sdlRenderer = SDL_CreateRenderer(window, unspecifiedRendererDriver,
      SDL_RENDERER_ACCELERATED);

  if (nullptr == _sdlRenderer) {
    std::cerr << "Renderer could not be created! SDL Error: " << SDL_GetError()
              << std::endl;
    return EXIT_FAILURE;
  }

  //Initialize renderer color to black
  if (EXIT_SUCCESS != SDL_SetRenderDrawColor(_sdlRenderer, 0, 0, 0,
  SDL_ALPHA_OPAQUE)) {
    std::cerr << "Error in, SDL_SetRenderDrawColor(), SDL Error: "
              << SDL_GetError() << std::endl;
    return EXIT_FAILURE;
  }

  Texture::setRenderer(_sdlRenderer);
  return EXIT_SUCCESS;
}

void Renderer::deinit() {
  if (_sdlRenderer) { //sanity check
    SDL_DestroyRenderer(_sdlRenderer);
    _sdlRenderer = nullptr;
  }
}

void Renderer::clearScreen() {
  if (EXIT_SUCCESS != SDL_RenderClear(_sdlRenderer)) {
    std::cerr << "Error in, SDL_RenderClear(), SDL Error: " << SDL_GetError()
              << std::endl;
  }
}

void Renderer::finishFrame() {
  SDL_RenderPresent(_sdlRenderer);
}

void Renderer::drawImage(const DrawParams& drawParams, SDL_Texture *texture) {
  SDL_Rect destRect;
  destRect.x = drawParams.pos.x; destRect.y = drawParams.pos.y;
  destRect.w = drawParams.width; destRect.h = drawParams.height;
  int32_t errorCode = 0;

  if (FULL_OPACITY == drawParams.opacity) {
    errorCode = SDL_RenderCopy(_sdlRenderer, texture, nullptr, &destRect);
  } else {
    if (EXIT_SUCCESS != Texture::setAlpha(texture, drawParams.opacity)) {
      std::cerr << "Error, Texture::setAlpha() failed for widget with Id: "
                << drawParams.rsrcId << std::endl;
    }
    errorCode = SDL_RenderCopy(_sdlRenderer, texture, nullptr, &destRect);
    if (EXIT_SUCCESS != Texture::setAlpha(texture, FULL_OPACITY)) {
      std::cerr << "Error, Texture::setAlpha() failed for widget with Id: "
                << drawParams.rsrcId << std::endl;
    }
  }

  if (EXIT_SUCCESS != errorCode) {
    std::cerr << "Error in, SDL_RenderCopy(), SDL Error: " << SDL_GetError()
              << std::endl;
  }
}
