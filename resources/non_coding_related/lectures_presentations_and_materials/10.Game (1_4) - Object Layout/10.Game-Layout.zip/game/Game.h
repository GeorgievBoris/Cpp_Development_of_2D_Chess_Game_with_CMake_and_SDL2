#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"
#include "game/game_entities/board/GameBoard.h"
#include "game/game_entities/pieces/PieceHandler.h"

//Forward declarations
class InputEvent;

class Game {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  GameBoard _gameBoard;
  PieceHandler _pieceHandler;
};

#endif /* GAME_GAME_H_ */
