#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <array>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"
#include "game/game_entities/Hero.h"
#include "game/game_entities/Wheel.h"
#include "game/buttons/WheelButton.h"
#include "game/proxies/GameProxy.h"

//Forward declarations
class InputEvent;

class Game : public GameProxy {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  enum WheelButtons {
    START,
    STOP,
    WHEEL_BUTTON_COUNT
  };

  void onButtonPressed(int32_t buttonId) final;

  Hero _hero;
  Wheel _wheel;
  std::array<WheelButton, WHEEL_BUTTON_COUNT> _wheelBtn;
};

#endif /* GAME_GAME_H_ */
