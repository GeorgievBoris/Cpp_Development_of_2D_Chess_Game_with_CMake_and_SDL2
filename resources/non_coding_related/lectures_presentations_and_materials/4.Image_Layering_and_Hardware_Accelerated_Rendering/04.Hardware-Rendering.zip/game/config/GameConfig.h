#ifndef GAME_CONFIG_GAMECONFIG_H_
#define GAME_CONFIG_GAMECONFIG_H_

//C system headers

//C++ system headers
#include <string>
#include <unordered_map>

//Other libraries headers

//Own components headers

//Forward declarations

enum GameImages {
  UP, DOWN, LEFT, RIGHT, PRESS_KEYS, LAYER_2
};

struct GameConfig {
  std::unordered_map<GameImages, std::string> imgLoadPaths;
};

#endif /* GAME_CONFIG_GAMECONFIG_H_ */
