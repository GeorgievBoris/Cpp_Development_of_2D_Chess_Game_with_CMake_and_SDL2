//Corresponding header
#include "utils/input/ButtonBase.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include "sdl/InputEvent.h"

//Own components headers

void ButtonBase::create(const int32_t rsrcId, const Point &pos) {
  _buttonTexture.create(rsrcId, pos);

  _boundRect.x = pos.x;
  _boundRect.y = pos.y;
  _boundRect.w = _buttonTexture.getWidth();
  _boundRect.h = _buttonTexture.getHeight();
}

void ButtonBase::draw() {
  _buttonTexture.draw();
}

bool ButtonBase::isInputUnlocked() const {
  return _isInputUnlocked;
}

bool ButtonBase::containsEvent(const InputEvent &e) const{
  //you can not click what your don't see. Logical isn't it?
  if (!_buttonTexture.isVisible()) {
    return false;
  }

  return _boundRect.isPointInRect(e.pos);
}

void ButtonBase::lockInput() {
  _isInputUnlocked = false;
  _buttonTexture.setFrame(DISABLED);
}

void ButtonBase::unlockInput() {
  _isInputUnlocked = true;
  _buttonTexture.setFrame(UNCLICKED);
}

bool ButtonBase::isCreated() {
  return _buttonTexture.isCreated();
}

bool ButtonBase::isVisible() const {
  return _buttonTexture.isVisible();
}

void ButtonBase::setPosition(int32_t x, int32_t y) {
  _boundRect.x = x;
  _boundRect.y = y;
  _buttonTexture.setPosition(x, y);
}

void ButtonBase::setPosition(const Point &pos) {
  _boundRect.x = pos.x;
  _boundRect.y = pos.y;
  _buttonTexture.setPosition(pos);
}

void ButtonBase::setX(int32_t x) {
  _boundRect.x = x;
  _buttonTexture.setX(x);
}

void ButtonBase::setY(int32_t y) {
  _boundRect.y = y;
  _buttonTexture.setY(y);
}

void ButtonBase::setFrame(int32_t frameIndex) {
  _buttonTexture.setFrame(frameIndex);
}

void ButtonBase::setOpacity(int32_t opacity) {
  _buttonTexture.setOpacity(opacity);
}

void ButtonBase::moveDown(int32_t y) {
  _boundRect.y += y;
  _buttonTexture.moveDown(y);
}

void ButtonBase::moveUp(int32_t y) {
  _boundRect.y -= y;
  _buttonTexture.moveUp(y);
}

void ButtonBase::moveLeft(int32_t x) {
  _boundRect.x -= x;
  _buttonTexture.moveLeft(x);
}

void ButtonBase::moveRight(int32_t x) {
  _boundRect.x += x;
  _buttonTexture.moveRight(x);
}

Point ButtonBase::getPosition() const {
  return Point(_boundRect.x, _boundRect.y);
}

int32_t ButtonBase::getX() const {
  return _boundRect.x;
}

int32_t ButtonBase::getY() const {
  return _boundRect.y;
}

int32_t ButtonBase::getWidth() const {
  return _boundRect.w;
}

int32_t ButtonBase::getHeight() const {
  return _boundRect.h;
}

int32_t ButtonBase::getOpacity() const {
  return _buttonTexture.getOpacity();
}

void ButtonBase::hide() {
  _buttonTexture.hide();
}

void ButtonBase::show() {
  _buttonTexture.show();
}

void ButtonBase::activateAlphaModulation() {
  _buttonTexture.activateAlphaModulation();
}

void ButtonBase::deactivateAlphaModulation() {
  _buttonTexture.deactivateAlphaModulation();
}

void ButtonBase::destroy() {
  _boundRect = Rectangle::ZERO;
  _isInputUnlocked = true;
  _buttonTexture.destroy();
}


