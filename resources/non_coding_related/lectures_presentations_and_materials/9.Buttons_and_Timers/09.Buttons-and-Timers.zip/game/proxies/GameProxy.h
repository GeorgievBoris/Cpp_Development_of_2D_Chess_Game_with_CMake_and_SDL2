#ifndef GAME_PROXIES_GAMEPROXY_H_
#define GAME_PROXIES_GAMEPROXY_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers

//Forward declarations

class GameProxy {
public:
  GameProxy() = default;
  virtual ~GameProxy() = default;

  virtual void onButtonPressed(int32_t buttonId) = 0;
};

#endif /* GAME_PROXIES_GAMEPROXY_H_ */
