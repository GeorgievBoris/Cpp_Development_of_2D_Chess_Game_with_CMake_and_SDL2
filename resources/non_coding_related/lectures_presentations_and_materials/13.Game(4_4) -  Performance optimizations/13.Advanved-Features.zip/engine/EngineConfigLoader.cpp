//Corresponding header
#include "engine/EngineConfigLoader.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "common/CommonDefines.h"
#include "common/Timers.h"

//constants
namespace {
//Screen dimension constants
constexpr auto DISPLAY_MODE = 4; //SDL_WINDOW_SHOWN from <SDL_video.h>
constexpr auto SCREEN_WIDTH = 900;
constexpr auto SCREEN_HEIGHT = 900;
constexpr auto WINDOW_NAME = "Chess";

constexpr auto MAX_FRAMES = 60;

constexpr auto CHESS_PIECES_FRAMES = 6;
constexpr auto CHESS_PIECE_WIDTH_HEIGHT = 96;

constexpr auto CHESS_BOARD_WIDTH_HEIGHT = 900;
constexpr auto TARGET_WIDTH_HEIGHT = 98;

constexpr auto MOVE_TILES_FRAMES = 3;
constexpr auto MOVE_TILES_WIDTH_HEIGHT = 98;

constexpr auto PIECE_PROMOTE_BUTTON_BGR_FRAMES = 2;
constexpr auto PIECE_PROMOTE_BUTTON_BGR_WIDTH_HEIGHT = 104;

void populateDrawMgrCfg(DrawMgrConfig &cfg) {
  cfg.windowCfg.displayMode = DISPLAY_MODE;
  cfg.windowCfg.windowWidth = SCREEN_WIDTH;
  cfg.windowCfg.windowHeight = SCREEN_HEIGHT;
  cfg.windowCfg.windowName = WINDOW_NAME;
  cfg.maxFrames = MAX_FRAMES;
}

void populateImageContainerCfg(ImageContainerConfig &cfg) {
  ImageConfig currImgCfg;
  currImgCfg.frames.reserve(CHESS_PIECES_FRAMES);

  currImgCfg.location = "../resources/p/whitePieces.png";
  for (auto i = 0; i < CHESS_PIECES_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * CHESS_PIECE_WIDTH_HEIGHT, 0,
        CHESS_PIECE_WIDTH_HEIGHT, CHESS_PIECE_WIDTH_HEIGHT);
  }
  cfg.imageConfigs.emplace(Textures::WHITE_PIECES, currImgCfg);

  currImgCfg.location = "../resources/p/blackPieces.png";
  currImgCfg.frames.clear();
  for (auto i = 0; i < CHESS_PIECES_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * CHESS_PIECE_WIDTH_HEIGHT, 0,
        CHESS_PIECE_WIDTH_HEIGHT, CHESS_PIECE_WIDTH_HEIGHT);
  }
  cfg.imageConfigs.emplace(Textures::BLACK_PIECES, currImgCfg);

  currImgCfg.location = "../resources/p/chessBoard.jpg";
  currImgCfg.frames.clear();
  currImgCfg.frames.emplace_back(0, 0, CHESS_BOARD_WIDTH_HEIGHT,
      CHESS_BOARD_WIDTH_HEIGHT);
  cfg.imageConfigs.emplace(Textures::CHESS_BOARD, currImgCfg);

  currImgCfg.location = "../resources/p/target.png";
  currImgCfg.frames.clear();
  currImgCfg.frames.emplace_back(0, 0, TARGET_WIDTH_HEIGHT,
      TARGET_WIDTH_HEIGHT);
  cfg.imageConfigs.emplace(Textures::TARGET, currImgCfg);

  currImgCfg.location = "../resources/p/moveTiles.png";
  currImgCfg.frames.clear();
  for (auto i = 0; i < MOVE_TILES_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * MOVE_TILES_WIDTH_HEIGHT, 0,
        MOVE_TILES_WIDTH_HEIGHT, MOVE_TILES_WIDTH_HEIGHT);
  }
  cfg.imageConfigs.emplace(Textures::MOVE_TILES, currImgCfg);

  currImgCfg.location = "../resources/p/piecePromoteButtonBgr.png";
  currImgCfg.frames.clear();
  for (auto i = 0; i < PIECE_PROMOTE_BUTTON_BGR_FRAMES; ++i) {
    currImgCfg.frames.emplace_back(i * PIECE_PROMOTE_BUTTON_BGR_WIDTH_HEIGHT, 0,
        PIECE_PROMOTE_BUTTON_BGR_WIDTH_HEIGHT,
        PIECE_PROMOTE_BUTTON_BGR_WIDTH_HEIGHT);
  }
  cfg.imageConfigs.emplace(Textures::PIECE_PROMOTE_BTN_BGR, currImgCfg);
}

void populateTextContainerCfg(TextContainerConfig &cfg) {
  FontConfig currFontCfg;
  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 25;
  cfg.fontConfigs.emplace(Fonts::ANGELINE_VINTAGE_SMALL, currFontCfg);

  currFontCfg.location = "../resources/f/AngelineVintage.ttf";
  currFontCfg.fontSize = 50;
  cfg.fontConfigs.emplace(Fonts::ANGELINE_VINTAGE_BIG, currFontCfg);
}

void populateGameConfig(GameConfig &cfg) {
  cfg.chessBoardRsrcId = Textures::CHESS_BOARD;
  cfg.whitePiecesRsrcId = Textures::WHITE_PIECES;
  cfg.blackPiecesRsrcId = Textures::BLACK_PIECES;
  cfg.targetRsrcId = Textures::TARGET;
  cfg.moveTilesRsrcId = Textures::MOVE_TILES;
  cfg.notReadyFontRsrcId = Fonts::ANGELINE_VINTAGE_SMALL;
  cfg.piecePromoteButtonBgrRsrcId = Textures::PIECE_PROMOTE_BTN_BGR;
  cfg.boardWidth = CHESS_BOARD_WIDTH_HEIGHT;
  cfg.boardHeight = CHESS_BOARD_WIDTH_HEIGHT;
  cfg.piecePromotionButtonBgrWidth = PIECE_PROMOTE_BUTTON_BGR_WIDTH_HEIGHT;
  cfg.piecePromotionButtonBgrHeight = PIECE_PROMOTE_BUTTON_BGR_WIDTH_HEIGHT;
  cfg.piecePromotionButtonWidth = CHESS_PIECE_WIDTH_HEIGHT;
  cfg.piecePromotionButtonHeight = CHESS_PIECE_WIDTH_HEIGHT;
  cfg.boardAnimTimerId = Timers::BOARD_ANIM_TIMER_ID;
}

}

EngineConfig EngineConfigLoader::loadConfig() {
  EngineConfig cfg;

  populateDrawMgrCfg(cfg.mgrHandlerCfg.drawMgrCfg);
  populateImageContainerCfg(cfg.mgrHandlerCfg.rsrcMgrCfg.imageContainerCfg);
  populateTextContainerCfg(cfg.mgrHandlerCfg.rsrcMgrCfg.textContainerCfg);
  populateGameConfig(cfg.gameCfg);

  return cfg;
}
