//Corresponding header
#include "game/game_entities/board/MoveSelector.h"

//C system headers

//C++ system headers
#include <cstdlib>

//Other libraries headers

//Own components headers
#include "game/defines/ChessStructs.h"
#include "game/game_entities/utils/BoardUtils.h"

int32_t MoveSelector::init(int32_t tileRsrcId) {
  for (auto &img : _tileImgs) {
    img.create(tileRsrcId);
  }
  return EXIT_SUCCESS;
}

void MoveSelector::draw() {
  for (size_t i = 0; i < _activeTiles; ++i) {
    _tileImgs[i].draw();
  }
}

void MoveSelector::markTiles(const std::vector<TileData> &markedTiles) {
  _activeTiles = markedTiles.size();
  for (size_t i = 0; i < _activeTiles; ++i) {
    _tileImgs[i].setFrame(static_cast<int32_t>(markedTiles[i].tileType));
    _tileImgs[i].setPosition(BoardUtils::getAbsPos(markedTiles[i].boardPos));
  }
}

void MoveSelector::unmarkTiles() {
  _activeTiles = 0;
}
