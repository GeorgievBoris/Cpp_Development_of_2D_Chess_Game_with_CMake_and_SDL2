//Corresponding header
#include "game/Game.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"

int32_t Game::init(const GameConfig &cfg) {
  if (EXIT_SUCCESS != _hero.init(cfg.heroRsrcId)) {
    std::cerr << "Error, _hero.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _wheel.init(cfg.wheelRsrcId, cfg.wheelRotAnimTimerId)) {
    std::cerr << "Error, _wheel.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _wheelBtn[START].init(this, START)) {
    std::cerr << "Error, _wheelBtn[START].init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _wheelBtn[STOP].init(this, STOP)) {
    std::cerr << "Error, _wheelBtn[STOP].init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  _wheelBtn[START].create(cfg.wheelStartBtnRsrcId, Point(650, 100));
  _wheelBtn[STOP].create(cfg.wheelStopBtnRsrcId, Point(850, 100));

  _wheelBtn[STOP].lockInput();

  return EXIT_SUCCESS;
}

void Game::deinit() {
  _hero.deinit();
  _wheel.deinit();
}

void Game::draw() {
  _wheel.draw();
  _hero.draw();

  for (auto &btn : _wheelBtn) {
    btn.draw();
  }
}

void Game::handleEvent(const InputEvent &e) {
  _wheel.handleEvent(e);
  _hero.handleEvent(e);

  for (auto &btn : _wheelBtn) {
    if (btn.isInputUnlocked() && btn.containsEvent(e)) {
      btn.handleEvent(e);
      break;
    }
  }
}

void Game::onButtonPressed(int32_t buttonId) {
  if (START == buttonId) {
    _wheel.startRotation();
    _wheelBtn[START].lockInput();
    _wheelBtn[STOP].unlockInput();
  } else if (STOP == buttonId) {
    _wheel.stopRotation();
    _wheelBtn[STOP].lockInput();
    _wheelBtn[START].unlockInput();
  } else {
    std::cerr << "Received unknown buttonId: " << buttonId << std::endl;
  }
}

