#ifndef SDL_CONFIG_TEXTCONTAINERCONFIG_H_
#define SDL_CONFIG_TEXTCONTAINERCONFIG_H_

//C system headers

//C++ system headers
#include <string>
#include <unordered_map>

//Other libraries headers

//Own components headers

//Forward declarations

struct FontConfig {
  std::string location;
  int32_t fontSize = 0;
};

struct TextContainerConfig {
  std::unordered_map<int32_t, FontConfig> fontConfigs;
};

#endif /* SDL_CONFIG_TEXTCONTAINERCONFIG_H_ */
