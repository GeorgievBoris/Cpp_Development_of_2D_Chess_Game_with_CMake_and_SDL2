#ifndef MANAGERS_RSRCMGRCONFIG_H_
#define MANAGERS_RSRCMGRCONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "sdl/config/ImageContainerConfig.h"
#include "sdl/config/TextContainerConfig.h"

//Forward declarations

struct RsrcMgrConfig {
  ImageContainerConfig imageContainerCfg;
  TextContainerConfig textContainerCfg;
};

#endif /* MANAGERS_RSRCMGRCONFIG_H_ */
