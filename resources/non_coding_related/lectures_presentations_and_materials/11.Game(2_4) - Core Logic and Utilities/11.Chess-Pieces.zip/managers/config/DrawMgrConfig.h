#ifndef MANAGERS_DRAWMGRCONFIG_H_
#define MANAGERS_DRAWMGRCONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "sdl/config/MonitorWindowConfig.h"

//Forward declarations

struct DrawMgrConfig {
  MonitorWindowConfig windowCfg;
  uint32_t maxFrames { 0 };
};

#endif /* MANAGERS_DRAWMGRCONFIG_H_ */
