#ifndef GAME_CONFIG_GAMECONFIG_H_
#define GAME_CONFIG_GAMECONFIG_H_

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

//Forward declarations

struct GameConfig {
  int32_t chessBoardRsrcId = 0;
  int32_t whitePiecesRsrcId = 0;
  int32_t blackPiecesRsrcId = 0;
  int32_t targetRsrcId = 0;
  int32_t moveTilesRsrcId = 0;
  int32_t notReadyFontRsrcId = 0;
  int32_t piecePromoteButtonBgrRsrcId = 0;
  int32_t boardWidth = 0;
  int32_t boardHeight = 0;
  int32_t piecePromotionButtonBgrWidth = 0;
  int32_t piecePromotionButtonBgrHeight = 0;
  int32_t piecePromotionButtonWidth = 0;
  int32_t piecePromotionButtonHeight = 0;
};

#endif /* GAME_CONFIG_GAMECONFIG_H_ */
