#ifndef MANAGERS_MGRBASE_H_
#define MANAGERS_MGRBASE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers

//Forward declarations

class MgrBase {
public:
  MgrBase() = default;
  virtual ~MgrBase() = default;

  //forbid the copy and move constructors
  MgrBase(const MgrBase &other) = delete;
  MgrBase(MgrBase &&other) = delete;

  //forbid the copy and move assignment operators
  MgrBase& operator=(const MgrBase &other) = delete;
  MgrBase& operator=(MgrBase &&other) = delete;

  virtual void deinit() = 0;

  virtual void process() = 0;
};

#endif /* MANAGERS_MGRBASE_H_ */

