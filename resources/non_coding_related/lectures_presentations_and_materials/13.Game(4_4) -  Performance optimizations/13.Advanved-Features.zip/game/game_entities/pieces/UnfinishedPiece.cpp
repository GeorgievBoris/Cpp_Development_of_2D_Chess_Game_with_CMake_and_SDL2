//Corresponding header
#include "game/game_entities/pieces/UnfinishedPiece.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

UnfinishedPiece::UnfinishedPiece(int32_t pieceRsrcId, const BoardPos &boardPos,
                                 PieceType pieceType, int32_t playerId,
                                 int32_t notReadyFontRsrcId)
    : ChessPiece(pieceRsrcId, boardPos, pieceType, playerId) {
  _notReadyText.create("!", notReadyFontRsrcId, Colors::RED,
      _pieceImg.getPosition());
}

void UnfinishedPiece::draw(FBO &fbo) {
  ChessPiece::draw(fbo);
  fbo.addWidget(_notReadyText);
}

void UnfinishedPiece::setBoardPos(const BoardPos &boardPos) {
  ChessPiece::setBoardPos(boardPos);
  _notReadyText.setPosition(_pieceImg.getPosition());
}

std::vector<TileData> UnfinishedPiece::getMoveTiles(
    [[maybe_unused]]const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const {
  return std::vector<TileData> { };
}
