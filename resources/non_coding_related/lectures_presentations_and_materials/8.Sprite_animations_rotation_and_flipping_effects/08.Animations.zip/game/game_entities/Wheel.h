#ifndef GAME_GAME_ENTITIES_WHEEL_H_
#define GAME_GAME_ENTITIES_WHEEL_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"

//Forward declarations
class InputEvent;

class Wheel {
public:
  int32_t init(int32_t wheelRsrcId);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  Image _wheel;
};

#endif /* GAME_GAME_ENTITIES_WHEEL_H_ */
