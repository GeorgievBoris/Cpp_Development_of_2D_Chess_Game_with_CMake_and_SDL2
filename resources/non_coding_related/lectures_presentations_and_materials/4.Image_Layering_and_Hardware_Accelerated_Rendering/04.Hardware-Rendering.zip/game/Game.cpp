//Corresponding header
#include "game/Game.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/Texture.h"
#include "sdl/InputEvent.h"

int32_t Game::init(const GameConfig &cfg) {
  SDL_Surface *currLoadedSurface = nullptr;
  SDL_Texture *currLoadedTexture = nullptr;
  for (const auto& elem : cfg.imgLoadPaths) {
    if (EXIT_SUCCESS != Texture::loadSurfaceFromFile(
        elem.second.c_str(), currLoadedSurface)) {
      std::cerr << "Texture::loadSurfaceFromFile() failed" << std::endl;
      return EXIT_FAILURE;
    }

    if (EXIT_SUCCESS != Texture::loadTextureFromSurface(
        currLoadedSurface, currLoadedTexture)) {
      std::cerr << "Texture::loadTextureFromSurface() failed" << std::endl;
      return EXIT_FAILURE;
    }

    _gameImgs[elem.first] = currLoadedTexture;
    currLoadedSurface = nullptr;
    currLoadedTexture = nullptr;
  }

  return EXIT_SUCCESS;
}

void Game::deinit() {
  for (auto& elem : _gameImgs) {
    Texture::freeTexture(elem.second);
  }
}

void Game::draw(std::vector<SDL_Texture*> &outTextures) {
  outTextures.push_back(_currChosenKeyImg);

  //temporary disable LAYER_2 image before we introduce scaling
//  outTextures.push_back(_gameImgs[LAYER_2]);
}

void Game::handleEvent(const InputEvent &e) {
  if (TouchEvent::KEYBOARD_PRESS == e.type) {
    switch (e.key) {
    case Keyboard::KEY_UP:
      _currChosenKeyImg = _gameImgs[UP];
      break;
    case Keyboard::KEY_DOWN:
      _currChosenKeyImg = _gameImgs[DOWN];
      break;
    case Keyboard::KEY_LEFT:
      _currChosenKeyImg = _gameImgs[LEFT];
      break;
    case Keyboard::KEY_RIGHT:
      _currChosenKeyImg = _gameImgs[RIGHT];
      break;
    default:
      break;
    }
  } else {
    _currChosenKeyImg = _gameImgs[PRESS_KEYS];
  }
}
