//Corresponding header
#include "game/Game.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "utils/drawing/Color.h"
#include "common/CommonDefines.h"

int32_t Game::init(const GameConfig &cfg) {
  if (EXIT_SUCCESS != _hero.init(cfg.heroRsrcId)) {
    std::cerr << "Error, _hero.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _wheel.init(cfg.wheelRsrcId)) {
    std::cerr << "Error, _wheel.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  _mouseTargetText.create("empty", Fonts::ANGELINE_VINTAGE_BIG,
      Colors::MAGENTA);

  return EXIT_SUCCESS;
}

void Game::deinit() {
  _hero.deinit();
  _wheel.deinit();
}

void Game::draw() {
  _wheel.draw();
  _hero.draw();

  _mouseTargetText.draw();
}

void Game::handleEvent(const InputEvent &e) {
  _wheel.handleEvent(e);
  _hero.handleEvent(e);

  if (TouchEvent::TOUCH_PRESS == e.type) {
    std::string textContent = "X: ";
    textContent.append(std::to_string(e.pos.x)).append(", Y: ").append(
        std::to_string(e.pos.y));
    _mouseTargetText.setText(textContent.c_str());
    _mouseTargetText.setPosition(e.pos);
  }
}
