#ifndef GAME_GAME_ENTITIES_PIECEHANDLER_H_
#define GAME_GAME_ENTITIES_PIECEHANDLER_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <array>

//Other libraries headers

//Own components headers
#include "game/game_entities/pieces/ChessPiece.h"
#include "game/defines/ChessDefines.h"

//Forward declarations
class InputEvent;
class GameBoardInterface;

class PieceHandler {
public:
  int32_t init(GameBoardInterface *gameBoardInterface,
               int32_t whitePiecesRsrcId, int32_t blackPiecesRsrcId);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  void handlePieceGrabbedEvent(const InputEvent &e);
  void handleNoPieceGrabbedEvent(const InputEvent &e);

  int32_t populateWhitePieces(int32_t rscId);
  int32_t populateBlackPieces(int32_t rscId);

  using PlayerPieces = std::vector<ChessPiece>;

  std::array<PlayerPieces, Defines::PLAYERS_COUNT> _pieces;

  GameBoardInterface *_gameBoardInterface = nullptr;

  int32_t _selectedPieceId = 0;
  int32_t _selectedPiecePlayerId = 0;
  bool _isPieceGrabbed = false;
};

#endif /* GAME_GAME_ENTITIES_PIECEHANDLER_H_ */
