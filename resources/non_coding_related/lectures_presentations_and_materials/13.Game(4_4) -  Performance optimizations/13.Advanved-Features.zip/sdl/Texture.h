#ifndef SDL_TEXTURE_H_
#define SDL_TEXTURE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers

//Forward declarations
class Color;
struct SDL_Surface;
struct SDL_Texture;
struct SDL_Renderer;
typedef struct _TTF_Font TTF_Font;
enum class BlendMode : uint8_t;

class Texture {
public:
  Texture() = delete;

  static int32_t loadSurfaceFromFile(const char *path,
                                     SDL_Surface *&outSurface);
  static int32_t loadTextureFromSurface(SDL_Surface *&surface,
                                        SDL_Texture *&outTexture);
  static int32_t loadTextureFromText(const char *text, TTF_Font *font,
                                     const Color &color,
                                     SDL_Texture *&outTexture,
                                     int32_t &outTextWidth,
                                     int32_t &outTextHeight);

  static int32_t createEmptyTexture(int32_t width, int32_t height,
                                    SDL_Texture *&outTexture);

  static void freeSurface(SDL_Surface *&surface);
  static void freeTexture(SDL_Texture *&surface);

  static int32_t setAlpha(SDL_Texture *texture, int32_t alpha);

  static int32_t setBlendMode(SDL_Texture *texture, BlendMode blendMode);

  static int32_t clearCurrentRendererTarget(const Color &color);

  static int32_t setRendererTarget(SDL_Texture *target);

  static void setRenderer(SDL_Renderer *renderer);
};

#endif /* SDL_TEXTURE_H_ */
