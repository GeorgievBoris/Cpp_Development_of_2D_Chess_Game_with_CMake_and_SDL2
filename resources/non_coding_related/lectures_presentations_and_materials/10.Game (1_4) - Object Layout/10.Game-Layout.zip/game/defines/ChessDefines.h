#ifndef GAME_DEFINES_CHESSDEFINES_H_
#define GAME_DEFINES_CHESSDEFINES_H_

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

//Forward declarations

namespace Defines {
enum PlayerId {
  WHITE_PLAYER = 0, BLACK_PLAYER,

  PLAYERS_COUNT
};

} //namespace Defines

enum class PieceType : uint8_t {
  KING, QUEEN, BISHOP, KNIGHT, ROOK, PAWN
};

#endif /* GAME_DEFINES_CHESSDEFINES_H_ */
