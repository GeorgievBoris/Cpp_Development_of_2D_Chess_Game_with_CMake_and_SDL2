//Corresponding header
#include "game/Game.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "utils/drawing/Color.h"
#include "common/CommonDefines.h"

int32_t Game::init([[maybe_unused]]const GameConfig &cfg) {
  _gameImg.create(Textures::PRESS_KEYS);
  _gameImg.activateAlphaModulation();

  std::string textContent = "Hello, C++ dudes!";
  _helloText.create(textContent.c_str(), Fonts::ANGELINE_VINTAGE_BIG,
      Colors::RED);

  textContent = "Press N to SHOW";
  _showText.create(textContent.c_str(), Fonts::ANGELINE_VINTAGE_SMALL,
      Colors::GREEN, Point(100, 500));

  textContent = "Press M to HIDE";
  _hideText.create(textContent.c_str(), Fonts::ANGELINE_VINTAGE_SMALL,
      Colors::YELLOW, Point(400, 500));
  _hideText.hide();

  _mouseTargetText.create("empty", Fonts::ANGELINE_VINTAGE_SMALL,
      Colors::MAGENTA);

  return EXIT_SUCCESS;
}

void Game::deinit() {

}

void Game::draw() {
  _gameImg.draw();
  _helloText.draw();
  _showText.draw();
  _hideText.draw();
  _mouseTargetText.draw();
}

void Game::handleEvent(const InputEvent &e) {
  if (TouchEvent::KEYBOARD_PRESS == e.type) {
    switch (e.key) {
    case Keyboard::KEY_UP:
      _gameImg.moveUp(10);
      break;
    case Keyboard::KEY_DOWN:
      _gameImg.moveDown(10);
      break;
    case Keyboard::KEY_LEFT:
      _gameImg.moveLeft(10);
      break;
    case Keyboard::KEY_RIGHT:
      _gameImg.moveRight(10);
      break;
    case Keyboard::KEY_Q:
      _gameImg.setWidth(_gameImg.getWidth() + 10);
      break;
    case Keyboard::KEY_W:
      _gameImg.setWidth(_gameImg.getWidth() - 10);
      break;
    case Keyboard::KEY_E:
      _gameImg.setHeight(_gameImg.getHeight() + 10);
      break;
    case Keyboard::KEY_R:
      _gameImg.setHeight(_gameImg.getHeight() - 10);
      break;
    case Keyboard::KEY_A:
      _gameImg.setOpacity(_gameImg.getOpacity() + 20);
      break;
    case Keyboard::KEY_S:
      _gameImg.setOpacity(_gameImg.getOpacity() - 20);
      break;
    case Keyboard::KEY_N:
      _showText.hide();
      _hideText.show();
      break;
    case Keyboard::KEY_M:
      _showText.show();
      _hideText.hide();
      break;
    default:
      break;
    }
  } else if (TouchEvent::TOUCH_PRESS == e.type) {
    std::string textContent = "X: ";
    textContent.append(std::to_string(e.pos.x)).append(", Y: ").append(
        std::to_string(e.pos.y));
    _mouseTargetText.setText(textContent.c_str());
    _mouseTargetText.setPosition(e.pos);
  }
}
