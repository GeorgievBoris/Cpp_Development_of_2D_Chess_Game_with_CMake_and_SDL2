//Corresponding header
#include "game/Game.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "sdl/containers/ImageContainer.h"
#include "common/CommonDefines.h"

int32_t Game::init(const GameConfig &cfg) {
  _imageContainer = cfg.imageContainer;

  const Rectangle &imageFrame = _imageContainer->getImageFrame(
      Textures::PRESS_KEYS);
  _gameImg.rsrcId = Textures::PRESS_KEYS;
  _gameImg.pos.x = imageFrame.x;
  _gameImg.pos.y = imageFrame.y;
  _gameImg.width = imageFrame.w;
  _gameImg.height = imageFrame.h;

  return EXIT_SUCCESS;
}

void Game::deinit() {

}

void Game::draw(std::vector<DrawParams> &outDrawParams) {
  outDrawParams.push_back(_gameImg);
}

void Game::handleEvent(const InputEvent &e) {
  if (TouchEvent::KEYBOARD_PRESS == e.type) {
    switch (e.key) {
    case Keyboard::KEY_UP:
      _gameImg.pos.y -= 10;
      break;
    case Keyboard::KEY_DOWN:
      _gameImg.pos.y += 10;
      break;
    case Keyboard::KEY_LEFT:
      _gameImg.pos.x -= 10;
      break;
    case Keyboard::KEY_RIGHT:
      _gameImg.pos.x += 10;
      break;
    case Keyboard::KEY_Q:
      _gameImg.width += 10;
      break;
    case Keyboard::KEY_W:
      _gameImg.width -= 10;
      break;
    case Keyboard::KEY_E:
      _gameImg.height += 10;
      break;
    case Keyboard::KEY_R:
      _gameImg.height -= 10;
      break;
    case Keyboard::KEY_A:
      _gameImg.opacity += 20;
      break;
    case Keyboard::KEY_S:
      _gameImg.opacity -= 20;
      break;
    default:
      break;
    }
  } else {
    //empty for now
  }
}
