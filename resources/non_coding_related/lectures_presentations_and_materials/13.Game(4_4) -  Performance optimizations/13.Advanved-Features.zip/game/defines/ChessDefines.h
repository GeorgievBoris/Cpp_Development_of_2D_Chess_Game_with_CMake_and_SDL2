#ifndef GAME_DEFINES_CHESSDEFINES_H_
#define GAME_DEFINES_CHESSDEFINES_H_

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

//Forward declarations

namespace Defines {
enum PlayerId {
  WHITE_PLAYER, BLACK_PLAYER,

  PLAYERS_COUNT
};

enum Direction {
  UP_LEFT,
  UP,
  UP_RIGHT,
  RIGHT,
  DOWN_RIGHT,
  DOWN,
  DOWN_LEFT,
  LEFT,
  DIRECTION_COUNT
};

enum PawnDefines {
  WHITE_PLAYER_START_PAWN_ROW = 6,
  WHITE_PLAYER_END_PAWN_ROW = 0,

  BLACK_PLAYER_START_PAWN_ROW = 1,
  BLACK_PLAYER_END_PAWN_ROW = 7
};

} //namespace Defines

enum class TileType : uint8_t {
  MOVE, GUARD, TAKE
};

enum class PieceType : uint8_t {
  KING, QUEEN, BISHOP, KNIGHT, ROOK, PAWN, UNKNOWN
};

#endif /* GAME_DEFINES_CHESSDEFINES_H_ */
