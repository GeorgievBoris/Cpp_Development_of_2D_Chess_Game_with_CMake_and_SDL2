#ifndef SDL_CONTAINERS_TEXTCONTAINER_H_
#define SDL_CONTAINERS_TEXTCONTAINER_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <unordered_map>

//Other libraries headers

//Own components headers

//Forward declarations
class Color;
struct SDL_Texture;
typedef struct _TTF_Font TTF_Font;
struct TextContainerConfig;

class TextContainer {
public:
  int32_t init(const TextContainerConfig &cfg);

  void deinit();

  void createText(const char *text, const Color &color, int32_t fontId,
                  int32_t &outTextId, int32_t &outTextWidth,
                  int32_t &outTextHeight);

  void reloadText(const char *text, const Color &color, int32_t fontId,
                  int32_t textId, int32_t &outTextWidth,
                  int32_t &outTextHeight);

  void unloadText(int32_t textId);

  SDL_Texture* getTextTexture(int32_t textId) const;

private:
  void occupyFreeSlotIndex(int32_t &occupiedTextId);
  void freeSlotIndex(int32_t textId);

  //the textures we'll be drawing
  std::vector<SDL_Texture*> _textures;

  std::unordered_map<int32_t, TTF_Font*> _fonts;
};

#endif /* SDL_CONTAINERS_TEXTCONTAINER_H_ */
