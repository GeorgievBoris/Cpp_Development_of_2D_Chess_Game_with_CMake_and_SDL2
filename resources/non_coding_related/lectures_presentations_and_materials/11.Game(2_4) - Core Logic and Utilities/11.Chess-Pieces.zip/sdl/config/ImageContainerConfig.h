#ifndef SDL_CONFIG_IMAGECONTAINERCONFIG_H_
#define SDL_CONFIG_IMAGECONTAINERCONFIG_H_

//C system headers

//C++ system headers
#include <string>
#include <unordered_map>
#include <vector>

//Other libraries headers

//Own components headers
#include "utils/drawing/Rectangle.h"

//Forward declarations

struct ImageConfig {
  std::string location;
  std::vector<Rectangle> frames;
};

struct ImageContainerConfig {
  std::unordered_map<int32_t, ImageConfig> imageConfigs;
};

#endif /* SDL_CONFIG_IMAGECONTAINERCONFIG_H_ */
