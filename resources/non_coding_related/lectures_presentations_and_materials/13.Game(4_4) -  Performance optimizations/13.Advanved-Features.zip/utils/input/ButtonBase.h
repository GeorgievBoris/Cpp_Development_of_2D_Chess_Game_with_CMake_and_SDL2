#ifndef UTILS_INPUT_BUTTONBASE_H_
#define UTILS_INPUT_BUTTONBASE_H_

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"
#include "utils/drawing/Rectangle.h"

//Forward declarations
class InputEvent;

enum ButtonStates {
  UNCLICKED, CLICKED, DISABLED
};

class ButtonBase {
public:
  virtual ~ButtonBase() = default;

  virtual void handleEvent(const InputEvent &e) = 0;

  void create(int32_t rsrcId, const Point &pos = Point::ZERO);

  virtual void draw();

  void lockInput();
  void unlockInput();

  bool isInputUnlocked() const;

  bool containsEvent(const InputEvent &e) const;

  bool isCreated();
  bool isVisible() const;

  void setPosition(int32_t x, int32_t y);
  void setPosition(const Point &pos);
  void setX(int32_t x);
  void setY(int32_t y);
  void setFrame(int32_t frameIndex);
  void setOpacity(int32_t opacity);

  void moveDown(int32_t y);
  void moveUp(int32_t y);
  void moveLeft(int32_t x);
  void moveRight(int32_t x);

  Point getPosition() const;
  int32_t getX() const;
  int32_t getY() const;
  int32_t getWidth() const;
  int32_t getHeight() const;
  int32_t getOpacity() const;

  void hide();
  void show();

  void activateAlphaModulation();
  void deactivateAlphaModulation();

  void destroy();

private:
  Image _buttonTexture;

  Rectangle _boundRect = Rectangle::ZERO;

  bool _isInputUnlocked = true;
};

#endif /* UTILS_INPUT_BUTTONBASE_H_ */

