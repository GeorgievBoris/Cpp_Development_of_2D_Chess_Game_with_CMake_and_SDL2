//Corresponding header
#include "game/game_entities/panels/PiecePromotionPanel.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "game/proxies/GameInterface.h"

int32_t PiecePromotionPanel::init(const PiecePromotionPanelConfig &cfg) {
  _gameInterface = cfg.gameInterface;

  PiecePromotionButtonConfig btnCfg;
  btnCfg.onBtnClicked = [this](PieceType pieceType) {
    onBtnClicked(pieceType);
  };
  btnCfg.buttonBgrRsrcId = cfg.buttonBgrRsrcId;
  btnCfg.bgrWidth = cfg.buttonBgrWidth;
  btnCfg.bgrHeight = cfg.buttonBgrHeight;
  btnCfg.width = cfg.buttonWidth;
  btnCfg.height = cfg.buttonHeight;
  btnCfg.buttonWhitePieceRsrcId = cfg.whitePiecesRsrcId;
  btnCfg.buttonBlackPieceRsrcId = cfg.blackPiecesRsrcId;

  constexpr std::array<PieceType, BUTTONS_COUNT> btnPieceType {
      PieceType::QUEEN, PieceType::ROOK, PieceType::KNIGHT, PieceType::BISHOP };
  constexpr auto btnOffsetX = 50;
  const auto startXY = (cfg.gameBoardWidth
      - (BUTTONS_COUNT * (cfg.buttonWidth + btnOffsetX))) / 2;
  btnCfg.bgrPos.y = (cfg.gameBoatdHeight - cfg.buttonHeight) / 2;

  int32_t idx = 0;
  for (auto &btn : _promotionBtns) {
    btnCfg.pieceType = btnPieceType[idx];
    btnCfg.bgrPos.x = startXY + (idx * (cfg.buttonWidth + btnOffsetX));
    if (EXIT_SUCCESS != btn.init(btnCfg)) {
      std::cerr << "Error, btn.init() failed" << std::endl;
      return EXIT_FAILURE;
    }

    ++idx;
  }

  return EXIT_SUCCESS;
}

void PiecePromotionPanel::handleEvent(const InputEvent &e) {
  for (auto &btn : _promotionBtns) {
    if (btn.isInputUnlocked() && btn.containsEvent(e)) {
      btn.handleEvent(e);
      break;
    }
  }
}

void PiecePromotionPanel::draw() {
  for (auto &btn : _promotionBtns) {
    btn.draw();
  }
}

void PiecePromotionPanel::activate(int32_t playerId) {
  _isActive = true;

  for (auto &btn : _promotionBtns) {
    btn.activate(playerId);
  }
}

bool PiecePromotionPanel::isActive() const {
  return _isActive;
}

void PiecePromotionPanel::onBtnClicked(PieceType pieceType) {
  _isActive = false;
  _gameInterface->promotePiece(pieceType);
}

