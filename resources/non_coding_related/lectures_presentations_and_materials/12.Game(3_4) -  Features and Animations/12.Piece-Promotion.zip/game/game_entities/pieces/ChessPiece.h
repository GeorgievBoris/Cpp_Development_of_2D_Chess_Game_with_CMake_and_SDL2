#ifndef GAME_GAME_ENTITIES_PIECES_CHESSPIECE_H_
#define GAME_GAME_ENTITIES_PIECES_CHESSPIECE_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <array>
#include <memory>

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"
#include "game/game_entities/utils/BoardPos.h"
#include "game/defines/ChessStructs.h"

//Forward declarations
class InputEvent;

class ChessPiece {
public:
  using PlayerPieces = std::vector<std::unique_ptr<ChessPiece>>;

  ChessPiece(int32_t pieceRsrcId, const BoardPos &boardPos, PieceType pieceType,
             int32_t playerId);
  virtual ~ChessPiece() = default;

  virtual std::vector<TileData> getMoveTiles(
      const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const = 0;

  virtual void draw();

  bool containsEvent(const InputEvent &e) const;

  void setWidgetFlipType(WidgetFlip flipType);

  virtual void setBoardPos(const BoardPos &boardPos);
  BoardPos getBoardPos() const;

  PieceType getPieceType() const;

  int32_t getPlayerId() const;

protected:
  Image _pieceImg;

  BoardPos _boardPos;

  int32_t _playerId;

  PieceType _pieceType;
};

#endif /* GAME_GAME_ENTITIES_PIECES_CHESSPIECE_H_ */
