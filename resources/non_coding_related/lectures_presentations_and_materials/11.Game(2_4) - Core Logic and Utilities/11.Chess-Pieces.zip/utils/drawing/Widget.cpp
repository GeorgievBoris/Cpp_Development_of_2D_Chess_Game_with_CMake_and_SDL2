//Corresponding header
#include "utils/drawing/Widget.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/DrawMgr.h"

void Widget::draw() {
  if (_isVisible) {
    gDrawMgr->addDrawCmd(_drawParams);
  }
}

void Widget::setPosition(int32_t x, int32_t y) {
  _drawParams.pos.x = x;
  _drawParams.pos.y = y;
}

void Widget::setPosition(const Point &pos) {
  _drawParams.pos = pos;
}

void Widget::setX(int32_t x) {
  _drawParams.pos.x = x;
}

void Widget::setY(int32_t y) {
  _drawParams.pos.y = y;
}

void Widget::setWidth(int32_t width) {
  _drawParams.width = width;
}

void Widget::setHeight(int32_t height) {
  _drawParams.height = height;
}

void Widget::setWidgetFlip(WidgetFlip flipType) {
  _drawParams.widgetFlip = flipType;
}

void Widget::setRotation(double angle) {
  _drawParams.rotationAngle = angle;
}

void Widget::setRotationCenter(const Point &center) {
  _drawParams.rotationCenter = center;
}

void Widget::moveDown(int32_t y) {
  _drawParams.pos.y += y;
}

void Widget::moveUp(int32_t y) {
  _drawParams.pos.y -= y;
}

void Widget::moveLeft(int32_t x) {
  _drawParams.pos.x -= x;
}

void Widget::moveRight(int32_t x) {
  _drawParams.pos.x += x;
}

Rectangle Widget::getBoundaryRect() const {
  return Rectangle(_drawParams.pos, _drawParams.width, _drawParams.height);
}

Point Widget::getPosition() const {
  return _drawParams.pos;
}

int32_t Widget::getX() const {
  return _drawParams.pos.x;
}

int32_t Widget::getY() const {
  return _drawParams.pos.y;
}

int32_t Widget::getWidth() const {
  return _drawParams.width;
}

int32_t Widget::getHeight() const {
  return _drawParams.height;
}

double Widget::getRotation() const {
  return _drawParams.rotationAngle;
}

Point Widget::getRotationCenter() const {
  return _drawParams.rotationCenter;
}

bool Widget::isCreated() const {
  return _isCreated;
}

void Widget::hide() {
  _isVisible = false;
}

void Widget::show() {
  _isVisible = true;
}

bool Widget::isVisible() const {
  return _isVisible;
}

bool Widget::containsPoint(const Point &point) const {
  const Rectangle bounds { _drawParams.pos.x, _drawParams.pos.y,
      _drawParams.width, _drawParams.height };

  return bounds.isPointInRect(point);
}

void Widget::setOpacity(int32_t opacity) {
  if (!_isAlphaModulationEnabled) {
    std::cerr << "Error, alpha modulation was not enabled for Widget with Id: "
              << _drawParams.rsrcId << std::endl;
    return;
  }

  if (ZERO_OPACITY > opacity || FULL_OPACITY < opacity) {
    std::cerr << "Error, opacity can only be in the range [0-255] while "
              << opacity << " is provided "
              "for widget with Id: "
              << _drawParams.rsrcId << std::endl;
    return;
  }

  _drawParams.opacity = opacity;
  gDrawMgr->setWidgetOpacity(_drawParams, opacity);
}

int32_t Widget::getOpacity() const {
  return _drawParams.opacity;
}

WidgetFlip Widget::getFlipType() const {
  return _drawParams.widgetFlip;
}

void Widget::activateAlphaModulation() {
  if (!_isCreated) {
    std::cerr << "Error, alpha modulation can not be set, because Widget "
              "is not yet created"
              << std::endl;
    return;
  }

  if (_isAlphaModulationEnabled) {
    std::cerr << "Error, alpha modulation is already set for Widget with Id: "
              << _drawParams.rsrcId << std::endl;
    return;
  }

  _isAlphaModulationEnabled = true;
  gDrawMgr->setWidgetBlendMode(_drawParams, BlendMode::BLEND);
}

void Widget::deactivateAlphaModulation() {
  if (!_isAlphaModulationEnabled) {
    std::cerr << "Error, alpha modulation was not enabled for Widget with Id: "
              << _drawParams.rsrcId << std::endl;
    return;
  }

  _isAlphaModulationEnabled = false;
  gDrawMgr->setWidgetBlendMode(_drawParams, BlendMode::NONE);
}

void Widget::reset() {
  _drawParams.reset();
  _isCreated = false;
  _isVisible = true;
  _isAlphaModulationEnabled = false;
}

