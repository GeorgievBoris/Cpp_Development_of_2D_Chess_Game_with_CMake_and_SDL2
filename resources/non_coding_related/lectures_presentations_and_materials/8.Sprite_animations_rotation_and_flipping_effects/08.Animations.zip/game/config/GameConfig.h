#ifndef GAME_CONFIG_GAMECONFIG_H_
#define GAME_CONFIG_GAMECONFIG_H_

//C system headers

//C++ system headers
//Other libraries headers

//Own components headers

//Forward declarations

struct GameConfig {
  int32_t heroRsrcId = 0;
  int32_t wheelRsrcId = 0;
};

#endif /* GAME_CONFIG_GAMECONFIG_H_ */
