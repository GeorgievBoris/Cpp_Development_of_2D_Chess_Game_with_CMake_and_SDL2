#ifndef UTILS_DRAWING_DRAWPARAMS_H_
#define UTILS_DRAWING_DRAWPARAMS_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "Point.h"
#include "Rectangle.h"

enum class BlendMode : uint8_t {
  NONE  = 0, //value for SDL_BLENDMODE_NONE
  BLEND = 1, //value for SDL_BLENDMODE_BLEND
  ADD   = 2, //value for SDL_BLENDMODE_ADD
  MOD   = 4  //value for SDL_BLENDMODE_MODE
};

enum class WidgetType : uint8_t {
  IMAGE,
  TEXT,
  UNKNOWN
};

enum class WidgetFlip : uint8_t {
    NONE                    = 0,
    HORIZONTAL              = 1,
    VERTICAL                = 2,
    HORIZONTAL_AND_VERTICAL = 3
};

inline constexpr int32_t FULL_OPACITY = 255;
inline constexpr int32_t ZERO_OPACITY = 0;

struct DrawParams {
  DrawParams();

  void reset();

  Rectangle frameRect;

  Point rotationCenter;
  double rotationAngle;

  //Top left position of texture
  Point pos;

  //Draw dimensions of the texture
  int32_t width;
  int32_t height;

  int32_t opacity;

  //unique resourceId
  union {
    int32_t rsrcId;
    int32_t textId;
  };

  BlendMode blendMode;

  WidgetType widgetType;

  WidgetFlip widgetFlip = WidgetFlip::NONE;
};

#endif /* UTILS_DRAWING_DRAWPARAMS_H_ */

