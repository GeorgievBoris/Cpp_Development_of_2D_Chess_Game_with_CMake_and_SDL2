//Corresponding header
#include "engine/Engine.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/Texture.h"
#include "utils/time/Time.h"
#include "utils/common/Threading.h"
#include "game/config/GameConfig.h"

int32_t Engine::init(const EngineConfig &cfg) {
  if (EXIT_SUCCESS != _window.init(cfg.windowCfg)) {
    std::cerr << "window.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _renderer.init(_window.getWindow())) {
    std::cerr << "_renderer.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _event.init()) {
    std::cerr << "_event.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _imageContainer.init(cfg.imageContainerCfg)) {
    std::cerr << "_imageContainer.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  GameConfig gameConfig;
  gameConfig.imageContainer = &_imageContainer;
  if (EXIT_SUCCESS != _game.init(gameConfig)) {
    std::cerr << "_game.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void Engine::deinit() {
  _game.deinit();
  _event.deinit();
  _imageContainer.deinit();
  _renderer.deinit();
  _window.deinit();
}

void Engine::start() {
  mainLoop();
}

void Engine::mainLoop() {
  Time time;
  while (true) {
    time.getElapsed(); //begin measure the new frame elapsed time

    if (processFrame()) {
      //user has requested exit -> break the main loop
      return;
    }

    limitFPS(time.getElapsed().toMicroseconds());
  }
}

void Engine::drawFrame() {
  _renderer.clearScreen();

  std::vector<DrawParams> drawParams;
  _game.draw(drawParams);

  SDL_Texture *currTexture = nullptr;
  for (const DrawParams &drawParam : drawParams) {
    currTexture = _imageContainer.getImageTexture(drawParam.rsrcId);
    _renderer.drawImage(drawParam, currTexture);
  }

  _renderer.finishFrame();
}

bool Engine::processFrame() {
  while (_event.pollEvent()) {
    if (_event.checkForExitRequest()) {
      return true;
    }

    handleEvent();
  }

  drawFrame();
  return false;
}

void Engine::handleEvent() {
  _game.handleEvent(_event);
}

void Engine::limitFPS(const int64_t elapsedMicroseconds) {
  constexpr auto maxFrames = 60;
  constexpr auto microsecondsInASeconds = 1000000;
  constexpr auto maxMicrosecondsPerFrame = microsecondsInASeconds / maxFrames;

  const int64_t microSecondsFpsDelay =
      maxMicrosecondsPerFrame - elapsedMicroseconds;
  if (0 < microSecondsFpsDelay) {
    Threading::sleepFor(microSecondsFpsDelay);
  }
}

