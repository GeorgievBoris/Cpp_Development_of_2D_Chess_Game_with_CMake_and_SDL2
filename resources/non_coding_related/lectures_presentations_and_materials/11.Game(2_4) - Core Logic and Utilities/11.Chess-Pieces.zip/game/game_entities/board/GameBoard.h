#ifndef GAME_GAME_ENTITIES_GAMEBOARD_H_
#define GAME_GAME_ENTITIES_GAMEBOARD_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/proxies/GameBoardInterface.h"
#include "game/game_entities/board/MoveSelector.h"
#include "utils/drawing/Image.h"

//Forward declarations

class GameBoard: public GameBoardInterface {
public:
  int32_t init(int32_t boardRsrcId, int32_t targetRsrcId,
               int32_t moveTileRsrcId);

  void deinit();

  void draw();

private:
  void onPieceGrabbed(const BoardPos &boardPos,
                      const std::vector<TileData> &moveTiles) final;
  void onPieceUngrabbed() final;
  bool isMoveAllowed(const BoardPos &pos) const final;

  MoveSelector _moveSelector;
  Image _boardImg;
  Image _targetImg;

  std::vector<TileData> _activeMoveTiles;
};

#endif /* GAME_GAME_ENTITIES_GAMEBOARD_H_ */
