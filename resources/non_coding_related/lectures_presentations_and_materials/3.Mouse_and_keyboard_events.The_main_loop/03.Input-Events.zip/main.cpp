//C system headers

//C++ system headers
#include <cstdint>
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/SDLLoader.h"
#include "engine/Engine.h"

static int32_t runApplication() {
  Engine engine;

  if (EXIT_SUCCESS != engine.init()) {
    std::cerr << "engine.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  engine.start();

  engine.deinit();
  return EXIT_SUCCESS;
}

int32_t main([[maybe_unused]] int argc, [[maybe_unused]] char *args[]) {
  if (EXIT_SUCCESS != SDLLoader::init()) {
    std::cerr << "Error in SDLLoader::init()" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != runApplication()) {
    std::cerr << "Error in runApplication()" << std::endl;
    return EXIT_FAILURE;
  }

  //close SDL libraries
  SDLLoader::deinit();

  return EXIT_SUCCESS;
}
