//Corresponding header
#include "engine/EngineConfigLoader.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

//constants
namespace {
//Screen dimension constants
constexpr auto DISPLAY_MODE = 4; //SDL_WINDOW_SHOWN from <SDL_video.h>
constexpr auto SCREEN_WIDTH = 640;
constexpr auto SCREEN_HEIGHT = 480;
constexpr auto WINDOW_NAME = "C++_App_Dev";
}

EngineConfig EngineConfigLoader::loadConfig() {
  EngineConfig cfg;

  cfg.windowCfg.displayMode = DISPLAY_MODE;
  cfg.windowCfg.windowWidth = SCREEN_WIDTH;
  cfg.windowCfg.windowHeight = SCREEN_HEIGHT;
  cfg.windowCfg.windowName = WINDOW_NAME;

  cfg.gameCfg.imgLoadPaths[UP] = "../resources/up.png";
  cfg.gameCfg.imgLoadPaths[DOWN] = "../resources/down.png";
  cfg.gameCfg.imgLoadPaths[LEFT] = "../resources/left.png";
  cfg.gameCfg.imgLoadPaths[RIGHT] = "../resources/right.png";
  cfg.gameCfg.imgLoadPaths[PRESS_KEYS] = "../resources/press_keys.png";
  cfg.gameCfg.imgLoadPaths[LAYER_2] = "../resources/layer_2.png";

  return cfg;
}
