#ifndef GAME_GAME_ENTITIES_WHEEL_H_
#define GAME_GAME_ENTITIES_WHEEL_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"
#include "utils/time/TimerClient.h"

//Forward declarations
class InputEvent;

class Wheel : public TimerClient {
public:
  int32_t init(int32_t wheelRsrcId, int32_t rotTimerId);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

  void startRotation();
  void stopRotation();

private:
  void onTimeout(int32_t timerId) final;

  void processRotAnim();

  Image _wheel;
  int32_t _rotTimerId = 0;
  double _currRotAngle = 0.0;
  bool _isRotStarted = false;
};

#endif /* GAME_GAME_ENTITIES_WHEEL_H_ */
