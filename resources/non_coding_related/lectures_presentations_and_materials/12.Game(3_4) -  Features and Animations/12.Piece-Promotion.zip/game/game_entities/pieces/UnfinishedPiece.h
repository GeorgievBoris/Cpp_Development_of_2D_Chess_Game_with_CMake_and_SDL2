#ifndef GAME_GAME_ENTITIES_PIECES_UNFINISHEDPIECE_H_
#define GAME_GAME_ENTITIES_PIECES_UNFINISHEDPIECE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Text.h"
#include "game/game_entities/pieces/ChessPiece.h"

//Forward declarations
class InputEvent;

class UnfinishedPiece: public ChessPiece {
public:
  UnfinishedPiece(int32_t pieceRsrcId, const BoardPos &boardPos,
                  PieceType pieceType, int32_t playerId,
                  int32_t notReadyFontRsrcId);

  void draw() final;

  void setBoardPos(const BoardPos &boardPos) final;

  std::vector<TileData> getMoveTiles(
      const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const final;

private:
  Text _notReadyText;
};

#endif /* GAME_GAME_ENTITIES_PIECES_UNFINISHEDPIECE_H_ */
