#ifndef MANAGERS_TIMERMGR_H_
#define MANAGERS_TIMERMGR_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <set>
#include <map>

//Other libraries headers

//Own components headers
#include "managers/MgrBase.h"

#include "utils/time/Time.h"
#include "utils/time/TimerClientStructs.h"

//Forward declarations
class TimerClient;

class TimerMgr: public MgrBase {
public:
  TimerMgr() = default;

  TimerMgr(const TimerMgr &other) = delete;
  TimerMgr(TimerMgr &&other) = delete;

  TimerMgr& operator=(const TimerMgr &other) = delete;
  TimerMgr& operator=(TimerMgr &&other) = delete;

  int32_t init();

  void deinit() final;

  void process() final;

  void startTimer(TimerClient *tcIstance, int64_t interval, int32_t timerId,
                  TimerType timerType);

  void stopTimer(int32_t timerId);

  void detachTimerClient(int32_t timerId);

  bool isActiveTimerId(int32_t timerId) const;

  void onInitEnd();

private:
  void onTimerTimeout(int32_t timerId, TimerData &timerData);

  void removeTimersInternal();

  Time _elapsedTime;

  std::map<int32_t, TimerData> _timerMap;

  std::set<int32_t> _removeTimerSet;
};

extern TimerMgr *gTimerMgr;

#endif /* MANAGERS_TIMERMGR_H_ */

