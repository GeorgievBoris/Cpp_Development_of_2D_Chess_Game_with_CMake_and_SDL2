//Corresponding header
#include "game/game_entities/pieces/Rook.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "game/game_entities/utils/BoardUtils.h"

Rook::Rook(int32_t pieceRsrcId, const BoardPos &boardPos, PieceType pieceType,
           int32_t playerId)
    : ChessPiece(pieceRsrcId, boardPos, pieceType, playerId) {

}

std::vector<TileData> Rook::getMoveTiles(
    const std::array<PlayerPieces, Defines::PLAYERS_COUNT> &activePieces) const {
  const std::vector<MoveDirection> boardMoves = getBoardMoves();
  std::vector<TileData> moveTiles;
  moveTiles.reserve(boardMoves.size());

  const int32_t opponentId = BoardUtils::getOpponentId(_playerId);
  for (const auto &moveDir : boardMoves) {
    if (moveDir.empty()) {
      continue;
    }

    for (const auto &pos : moveDir) {
      const auto tileType = BoardUtils::getTileType(pos,
          activePieces[_playerId], activePieces[opponentId]);
      moveTiles.emplace_back(pos, tileType);

      if (tileType != TileType::MOVE) {
        break;
      }
    }
  }

  return moveTiles;
}

std::vector<MoveDirection> Rook::getBoardMoves() const {
  constexpr auto allowedDirs = 4;
  constexpr std::array<Defines::Direction, allowedDirs> rookDirs { Defines::UP,
      Defines::RIGHT, Defines::DOWN, Defines::LEFT };

  constexpr auto maxRootMoves = 14;
  std::vector<MoveDirection> boardMoves(allowedDirs);

  BoardPos futurePos;
  for (int32_t dirIdx = 0; dirIdx < allowedDirs; ++dirIdx) {
    boardMoves[dirIdx].reserve(maxRootMoves);
    futurePos = _boardPos;
    futurePos = BoardUtils::getAdjacentPos(rookDirs[dirIdx], futurePos);
    while (BoardUtils::isInsideBoard(futurePos)) {
      boardMoves[dirIdx].emplace_back(futurePos);
      futurePos = BoardUtils::getAdjacentPos(rookDirs[dirIdx], futurePos);
    }
  }

  return boardMoves;
}

