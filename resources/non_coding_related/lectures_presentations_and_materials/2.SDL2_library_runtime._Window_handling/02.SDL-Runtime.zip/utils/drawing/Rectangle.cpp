//Corresponding header
#include "Rectangle.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

Rectangle::Rectangle(int32_t inputX, int32_t inputY, int32_t inputW,
                     int32_t inputH)
    : x(inputX), y(inputY), w(inputW), h(inputH) {

}

Rectangle::Rectangle(const Point &pos, int32_t inputW, int32_t inputH)
    : x(pos.x), y(pos.y), w(inputW), h(inputH) {

}

bool Rectangle::operator==(const Rectangle &other) const {
  return x == other.x && y == other.y && w == other.w && h == other.h;
}

bool Rectangle::operator!=(const Rectangle &other) const {
  return ! (*this == other);
}

bool Rectangle::isPointInRect(const Point &point) const {
  return (point.x >= x) && (point.x < (x + w)) && (point.y >= y)
         && (point.y < (y + h));
}

bool Rectangle::isPointInRect(const Point &point, const Rectangle &rect) {
  return (point.x >= rect.x) && (point.x < (rect.x + rect.w))
         && (point.y >= rect.y) && (point.y < (rect.y + rect.h));
}

const Rectangle Rectangle::ZERO(0, 0, 0, 0);
const Rectangle Rectangle::UNDEFINED(100000, 100000, 100000, 100000);
