#ifndef MANAGERS_DRAWMGR_H_
#define MANAGERS_DRAWMGR_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "managers/MgrBase.h"
#include "sdl/Renderer.h"
#include "sdl/MonitorWindow.h"

//Forward declarations
struct DrawMgrConfig;

class DrawMgr: public MgrBase {
public:
  DrawMgr() = default;

  //forbid the copy and move constructors
  DrawMgr(const DrawMgr &other) = delete;
  DrawMgr(DrawMgr &&other) = delete;

  //forbid the copy and move assignment operators
  DrawMgr& operator=(const DrawMgr &other) = delete;
  DrawMgr& operator=(DrawMgr &&other) = delete;

  int32_t init(const DrawMgrConfig &cfg);

  void deinit() final;

  void process() final;

  void clearScreen();

  void finishFrame();

  void addDrawCmd(const DrawParams &drawParams);

  void setWidgetBlendMode(const DrawParams &drawParams, BlendMode blendMode);
  void setWidgetOpacity(const DrawParams &drawParams, int32_t opacity);

  void setMaxFrameRate(uint32_t maxFrames);
  uint32_t getMaxFrameRate() const;

  int32_t getFrameWidgetsCount() const;

  int32_t lockRenderer();
  int32_t unlockRenderer();

  void resetRendererTarget();
  void clearCurrentRendererTarget(const Color &color);

  void changeRendererTarget(int32_t fboId);

  void updateCurrRendererTarget(const DrawParams drawParams[], size_t size);

private:
  Renderer _renderer;

  MonitorWindow _window;

  //Hold maximum frame rate cap
  uint32_t _maxFrames { 0 };
};

extern DrawMgr *gDrawMgr;

#endif /* MANAGERS_DRAWMGR_H_ */

