#ifndef UTILS_DRAWING_RECTANGLE_H_
#define UTILS_DRAWING_RECTANGLE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "Point.h"

//Forward declarations

struct Rectangle {
  Rectangle() = default;
  Rectangle(int32_t inputX, int32_t inputY, int32_t inputW, int32_t inputH);
  Rectangle(const Point &pos, int32_t inputW, int32_t inputH);

  bool operator==(const Rectangle &other) const;
  bool operator!=(const Rectangle &other) const;

  bool isPointInRect(const Point &point) const;

  static bool isPointInRect(const Point &point, const Rectangle &rect);

  int32_t x { 0 };
  int32_t y { 0 };
  int32_t w { 0 };
  int32_t h { 0 };

  static const Rectangle ZERO;
  static const Rectangle UNDEFINED;
};

#endif /* UTILS_DRAWING_RECTANGLE_H_ */
