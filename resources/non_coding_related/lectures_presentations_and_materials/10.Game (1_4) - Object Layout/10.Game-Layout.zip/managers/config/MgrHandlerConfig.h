#ifndef MANAGERS_MGRHANDLERCONFIG_H_
#define MANAGERS_MGRHANDLERCONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "managers/config/DrawMgrConfig.h"
#include "managers/config/RsrcMgrConfig.h"

//Forward declarations

struct MgrHandlerConfig {
  DrawMgrConfig drawMgrCfg;
  RsrcMgrConfig rsrcMgrCfg;
};

#endif /* MANAGERS_MGRHANDLERCONFIG_H_ */
