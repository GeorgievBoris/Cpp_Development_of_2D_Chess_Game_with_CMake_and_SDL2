#ifndef ENGINE_ENGINECONFIG_H_
#define ENGINE_ENGINECONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "sdl/config/MonitorWindowConfig.h"
#include "game/config/GameConfig.h"

//Forward declarations

struct EngineConfig {
  MonitorWindowConfig windowCfg;
  GameConfig gameCfg;
};

#endif /* ENGINE_ENGINECONFIG_H_ */
