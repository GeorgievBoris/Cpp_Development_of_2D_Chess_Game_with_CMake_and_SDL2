//Corresponding header
#include "game/Game.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers

int32_t Game::init(const GameConfig &cfg) {
  if (EXIT_SUCCESS != _gameBoard.init(cfg.chessBoardRsrcId, cfg.targetRsrcId,
          cfg.moveTilesRsrcId)) {
    std::cerr << "_gameBoard.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _gameBoardAnimator.init(this, _gameBoard.getBoardImg())) {
    std::cerr << "_gameBoardAnimator.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _pieceHandler.init(&_gameBoard, this,
          cfg.whitePiecesRsrcId, cfg.blackPiecesRsrcId,
          cfg.notReadyFontRsrcId)) {
    std::cerr << "_pieceHandler.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  PiecePromotionPanelConfig panelCfg;
  panelCfg.gameInterface = this;
  panelCfg.buttonBgrRsrcId = cfg.piecePromoteButtonBgrRsrcId;
  panelCfg.whitePiecesRsrcId = cfg.whitePiecesRsrcId;
  panelCfg.blackPiecesRsrcId = cfg.blackPiecesRsrcId;
  panelCfg.gameBoardWidth = cfg.boardWidth;
  panelCfg.gameBoatdHeight = cfg.boardHeight;
  panelCfg.buttonBgrWidth = cfg.piecePromotionButtonBgrWidth;
  panelCfg.buttonBgrHeight = cfg.piecePromotionButtonBgrHeight;
  panelCfg.buttonWidth = cfg.piecePromotionButtonWidth;
  panelCfg.buttonHeight = cfg.piecePromotionButtonHeight;

  if (EXIT_SUCCESS != _piecePromotionPanel.init(panelCfg)) {
    std::cerr << "_piecePromotionPanel.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _inputInverter.init(cfg.boardWidth, cfg.boardHeight)) {
    std::cerr << "_inputInverter.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void Game::deinit() {
  _gameBoard.deinit();
  _pieceHandler.deinit();
}

void Game::draw() {
  _gameBoard.draw();
  _pieceHandler.draw();

  if (_piecePromotionPanel.isActive()) {
    _piecePromotionPanel.draw();
  }
}

void Game::handleEvent(InputEvent &e) {
  if (_piecePromotionPanel.isActive()) {
    _piecePromotionPanel.handleEvent(e);
    return;
  }

  _inputInverter.invertEvent(e);

  _pieceHandler.handleEvent(e);
}

void Game::finishTurn() {
  _gameBoardAnimator.startAnim(_gameLogic.getActivePlayerId());


  _gameLogic.finishTurn();
  _pieceHandler.setActivePlayerId(_gameLogic.getActivePlayerId());
}

void Game::activatePawnPromotion() {
  _piecePromotionPanel.activate(_gameLogic.getActivePlayerId());
}

void Game::promotePiece(PieceType pieceType) {
  _pieceHandler.promotePiece(pieceType);
}

void Game::setWidgetFlipType(WidgetFlip flipType) {
  _inputInverter.setBoardFlipType(flipType);
//  _pieceHandler.setWidgetFlipType(flipType);
}

