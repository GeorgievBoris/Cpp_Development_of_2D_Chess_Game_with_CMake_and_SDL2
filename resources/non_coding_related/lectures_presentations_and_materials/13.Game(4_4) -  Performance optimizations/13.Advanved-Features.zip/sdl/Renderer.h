#ifndef SDL_RENDERER_H_
#define SDL_RENDERER_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <cstddef>

//Other libraries headers

//Own components headers
#include "utils/drawing/DrawParams.h"
#include "utils/drawing/Color.h"

//Forward declarations
struct SDL_Renderer;
struct SDL_Texture;
struct SDL_Window;

class Renderer {
public:
  Renderer() = default;

  Renderer(const Renderer& other) = delete;
  Renderer& operator=(const Renderer& other) = delete;

  Renderer(Renderer&& other) = delete;
  Renderer& operator=(Renderer&& other) = delete;

  int32_t init(SDL_Window *window);

  void deinit();

  void clearScreen();

  void finishFrame();

  void drawWidget(const DrawParams& drawParams);

  void setWidgetBlendMode(const DrawParams &drawParams, BlendMode blendMode);
  void setWidgetOpacity(const DrawParams &drawParams, int32_t opacity);

  int32_t getFrameWidgetsCount() const;

  int32_t lockRenderer();
  int32_t unlockRenderer();

  void resetRendererTarget();
  void clearCurrentRendererTarget(const Color &color);

  void changeRendererTarget(int32_t fboId);

  void updateCurrRendererTarget(const DrawParams drawParams[], size_t size);

private:
  void drawImage(const DrawParams& drawParams, SDL_Texture *texture);
  void drawTextOrFbo(const DrawParams& drawParams, SDL_Texture *texture);

  SDL_Texture* getTargetTexture(const DrawParams &widgetInfo);

  void drawWidgetInternal(const DrawParams &drawParams);

  SDL_Renderer *_sdlRenderer = nullptr;

  Color _clearColor = Colors::BLACK;

  int32_t _widgetsCount { 0 };

  bool _isRendererLocked = true;
};

#endif /* SDL_RENDERER_H_ */
