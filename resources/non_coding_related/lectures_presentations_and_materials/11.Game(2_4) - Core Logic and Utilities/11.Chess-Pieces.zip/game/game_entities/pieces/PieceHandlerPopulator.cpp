//Corresponding header
#include "game/game_entities/pieces/PieceHandlerPopulator.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "game/game_entities/pieces/UnfinishedPiece.h"
#include "game/game_entities/pieces/Rook.h"
#include "game/game_entities/pieces/Pawn.h"

namespace {
constexpr auto STARTING_PIECES_COUNT = 16;
constexpr auto PAWNS_COUNT = 8;
}

int32_t PieceHandlerPopulator::populateWhitePieces(
    ChessPiece::PlayerPieces &whites, int32_t rsrcId, int32_t fontId) {
  constexpr auto playerId = Defines::WHITE_PLAYER;
  whites.reserve(STARTING_PIECES_COUNT);

  for (auto i = 0; i < PAWNS_COUNT; ++i) {
    whites.emplace_back(
        std::make_unique<Pawn>(rsrcId,
            BoardPos(Defines::WHITE_PLAYER_START_PAWN_ROW, i), PieceType::PAWN,
            playerId));
  }
  whites.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(7, 4), PieceType::KING,
          playerId, fontId));
  whites.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(7, 3),
          PieceType::QUEEN, playerId, fontId));
  whites.emplace_back(
      std::make_unique<Rook>(rsrcId, BoardPos(7, 0), PieceType::ROOK,
          playerId));
  whites.emplace_back(
      std::make_unique<Rook>(rsrcId, BoardPos(7, 7), PieceType::ROOK,
          playerId));
  whites.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(7, 2),
          PieceType::BISHOP, playerId, fontId));
  whites.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(7, 5),
          PieceType::BISHOP, playerId, fontId));
  whites.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(7, 1),
          PieceType::KNIGHT, playerId, fontId));
  whites.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(7, 6),
          PieceType::KNIGHT, playerId, fontId));

  return EXIT_SUCCESS;
}

int32_t PieceHandlerPopulator::populateBlackPieces(
    ChessPiece::PlayerPieces &blacks, int32_t rsrcId, int32_t fontId) {
  constexpr auto playerId = Defines::BLACK_PLAYER;
  blacks.reserve(STARTING_PIECES_COUNT);

  for (auto i = 0; i < PAWNS_COUNT; ++i) {
    blacks.emplace_back(
        std::make_unique<Pawn>(rsrcId,
            BoardPos(Defines::BLACK_PLAYER_START_PAWN_ROW, i), PieceType::PAWN,
            playerId));
  }
  blacks.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(0, 4), PieceType::KING,
          playerId, fontId));
  blacks.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(0, 3),
          PieceType::QUEEN, playerId, fontId));
  blacks.emplace_back(
      std::make_unique<Rook>(rsrcId, BoardPos(0, 0), PieceType::ROOK,
          playerId));
  blacks.emplace_back(
      std::make_unique<Rook>(rsrcId, BoardPos(0, 7), PieceType::ROOK,
          playerId));
  blacks.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(0, 2),
          PieceType::BISHOP, playerId, fontId));
  blacks.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(0, 5),
          PieceType::BISHOP, playerId, fontId));
  blacks.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(0, 1),
          PieceType::KNIGHT, playerId, fontId));
  blacks.emplace_back(
      std::make_unique<UnfinishedPiece>(rsrcId, BoardPos(0, 6),
          PieceType::KNIGHT, playerId, fontId));

  return EXIT_SUCCESS;
}

