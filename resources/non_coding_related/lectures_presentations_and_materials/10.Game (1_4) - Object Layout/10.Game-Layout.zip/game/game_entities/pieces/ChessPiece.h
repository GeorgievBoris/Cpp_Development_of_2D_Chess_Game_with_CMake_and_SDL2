#ifndef GAME_GAME_ENTITIES_PIECES_CHESSPIECE_H_
#define GAME_GAME_ENTITIES_PIECES_CHESSPIECE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"
#include "game/defines/ChessDefines.h"
#include "game/game_entities/utils/BoardPos.h"

//Forward declarations
class InputEvent;

class ChessPiece {
public:
  ChessPiece(int32_t pieceRsrcId, const BoardPos &boardPos,
             PieceType pieceType, int32_t playerId);

  void draw();

  bool containsEvent(const InputEvent &e) const;

  void setBoardPos(const BoardPos &boardPos);
  BoardPos getBoardPos() const;

  PieceType getPieceType() const;

  int32_t getPlayerId() const;

private:
  Image _pieceImg;

  BoardPos _boardPos;

  int32_t _playerId;

  PieceType _pieceType;
};

#endif /* GAME_GAME_ENTITIES_PIECES_CHESSPIECE_H_ */
