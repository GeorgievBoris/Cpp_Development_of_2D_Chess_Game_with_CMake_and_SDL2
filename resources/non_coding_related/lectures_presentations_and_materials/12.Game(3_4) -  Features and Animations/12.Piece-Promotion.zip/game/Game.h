#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"
#include "game/game_entities/board/GameBoard.h"
#include "game/game_entities/board/GameBoardAnimator.h"
#include "game/game_entities/pieces/PieceHandler.h"
#include "game/game_entities/panels/PiecePromotionPanel.h"
#include "game/game_logic/GameLogic.h"
#include "game/game_logic/InputInverter.h"
#include "game/proxies/GameInterface.h"

//Forward declarations
class InputEvent;

class Game : public GameInterface {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw();

  void handleEvent(InputEvent &e);

private:
  void finishTurn() final;

  void activatePawnPromotion() final;

  void promotePiece(PieceType pieceType) final;

  void setWidgetFlipType(WidgetFlip flipType) final;

  GameBoard _gameBoard;
  GameBoardAnimator _gameBoardAnimator;
  PieceHandler _pieceHandler;
  PiecePromotionPanel _piecePromotionPanel;
  GameLogic _gameLogic;
  InputInverter _inputInverter;
};

#endif /* GAME_GAME_H_ */
