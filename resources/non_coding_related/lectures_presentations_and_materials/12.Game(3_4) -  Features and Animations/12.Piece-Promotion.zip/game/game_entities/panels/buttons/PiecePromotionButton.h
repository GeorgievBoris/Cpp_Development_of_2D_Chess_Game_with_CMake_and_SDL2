#ifndef GAME_GAME_ENTITIES_PANELS_BUTTONS_PIECEPROMOTIONBUTTON_H_
#define GAME_GAME_ENTITIES_PANELS_BUTTONS_PIECEPROMOTIONBUTTON_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/input/ButtonBase.h"
#include "utils/drawing/Image.h"
#include "game/game_entities/panels/buttons/config/PiecePromotionButtonConfig.h"

//Forward declarations
class InputEvent;

class PiecePromotionButton : public ButtonBase {
public:
  int32_t init(const PiecePromotionButtonConfig &cfg);

  void draw() final;

  void handleEvent(const InputEvent &e) final;

  void activate(int32_t activePlayerId);

private:
  Image _bgrImg;
  PiecePromotionButtonConfig _cfg;
};

#endif /* GAME_GAME_ENTITIES_PANELS_BUTTONS_PIECEPROMOTIONBUTTON_H_ */
