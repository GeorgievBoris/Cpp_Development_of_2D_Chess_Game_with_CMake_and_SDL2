//Corresponding header
#include "game/buttons/WheelButton.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "game/proxies/GameProxy.h"

int32_t WheelButton::init(GameProxy * gameProxy, int32_t buttonId) {
  if (nullptr == gameProxy) {
    std::cerr << "nullptr GameProxy provided for for WheelButton Id: "
        << buttonId << std::endl;
    return EXIT_FAILURE;
  }

  _gameProxy = gameProxy;
  _buttonId = buttonId;

  return EXIT_SUCCESS;
}

void WheelButton::handleEvent(const InputEvent &e) {
  if (TouchEvent::TOUCH_PRESS == e.type) {
    setFrame(CLICKED);
  } else if (TouchEvent::TOUCH_RELEASE == e.type) {
    setFrame(UNCLICKED);
    _gameProxy->onButtonPressed(_buttonId);
  }
}
