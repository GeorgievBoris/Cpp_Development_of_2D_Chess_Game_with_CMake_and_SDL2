#ifndef ENGINE_ENGINECONFIG_H_
#define ENGINE_ENGINECONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "managers/config/MgrHandlerConfig.h"
#include "game/config/GameConfig.h"

//Forward declarations

struct EngineConfig {
  MgrHandlerConfig mgrHandlerCfg;
  GameConfig gameCfg;
};

#endif /* ENGINE_ENGINECONFIG_H_ */
