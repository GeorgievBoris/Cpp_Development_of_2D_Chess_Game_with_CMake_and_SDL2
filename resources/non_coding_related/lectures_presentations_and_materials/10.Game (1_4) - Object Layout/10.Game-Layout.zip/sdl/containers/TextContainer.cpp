//Corresponding header
#include "sdl/containers/TextContainer.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include <SDL_ttf.h>

//Own components headers
#include "common/CommonDefines.h"
#include "sdl/config/TextContainerConfig.h"
#include "sdl/Texture.h"

int32_t TextContainer::init(const TextContainerConfig &cfg) {
  for (const auto &elem : cfg.fontConfigs) {
    TTF_Font *currFont = nullptr;
    const FontConfig &currFontCfg = elem.second;
    currFont = TTF_OpenFont(currFontCfg.location.c_str(), currFontCfg.fontSize);
    if (currFont == nullptr) {
      std::cerr << "Error, TTF_OpenFont() failed for font: "
                << currFontCfg.location << ". SDL_Error: " << SDL_GetError()
                << std::endl;
      return EXIT_FAILURE;
    }
    _fonts[elem.first] = currFont;
  }

  return EXIT_SUCCESS;
}

void TextContainer::deinit() {
  for (const auto &elem : _fonts) {
    TTF_CloseFont(elem.second);
  }

  for (SDL_Texture *texture : _textures) {
    Texture::freeTexture(texture);
  }
}

void TextContainer::createText(const char *text, const Color &color,
                               int32_t fontId, int32_t &outTextId,
                               int32_t &outTextWidth, int32_t &outTextHeight) {
  const auto fontIt = _fonts.find(fontId);
  if (fontIt == _fonts.end()) {
    std::cerr << "Warning, fontId: " << fontId
              << " not found. Will not create text with content: " << text
              << std::endl;
    return;
  }
  occupyFreeSlotIndex(outTextId);

  //create hardware accelerated texture
  if (EXIT_SUCCESS
      != Texture::loadTextureFromText(text, fontIt->second, color,
          _textures[outTextId], outTextWidth, outTextHeight)) {
    std::cerr << "Unable to load text: " << text << " with Id: " << outTextId
              << std::endl;
    freeSlotIndex(outTextId);
  }
}

void TextContainer::reloadText(const char *text, const Color &color,
                               int32_t fontId, int32_t textId,
                               int32_t &outTextWidth, int32_t &outTextHeight) {
  const auto fontIt = _fonts.find(fontId);
  if (fontIt == _fonts.end()) {
    std::cerr << "Warning, fontId: " << fontId
              << " not found. Will not reload text with content: " << text
              << std::endl;
    return;
  }

  //create hardware accelerated texture
  if (EXIT_SUCCESS
      != Texture::loadTextureFromText(text, fontIt->second, color,
          _textures[textId], outTextWidth, outTextHeight)) {
    std::cerr << "Unable to reload text: " << text << " with Id: " << textId
              << std::endl;
    freeSlotIndex(textId);
  }
}

void TextContainer::unloadText(int32_t textId) {
  if (textId >= static_cast<int32_t>(_textures.size())) {
    std::cerr << "Warning, unloading a non-existing text index for textId: " <<
        textId << std::endl;
    return;
  }
  freeSlotIndex(textId);
}

SDL_Texture* TextContainer::getTextTexture(int32_t textId) const {
  return _textures[textId];
}

void TextContainer::occupyFreeSlotIndex(int32_t &occupiedTextId) {
  bool foundIdx = false;

  const int32_t size = static_cast<int32_t>(_textures.size());
  for (int32_t idx = 0; idx < size; ++idx) {
    if (nullptr == _textures[idx]) {
      occupiedTextId = idx;
      foundIdx = true;
      break;
    }
  }

  //create additional space
  if (!foundIdx) {
    _textures.push_back(nullptr);
    occupiedTextId = size;
  }
}

void TextContainer::freeSlotIndex(int32_t textId) {
  Texture::freeTexture(_textures[textId]);
}

