//Corresponding header
#include "engine/Engine.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/Texture.h"
#include "managers/DrawMgr.h"
#include "utils/time/Time.h"
#include "utils/common/Threading.h"

int32_t Engine::init(const EngineConfig &cfg) {
  if (EXIT_SUCCESS != _mgrHandler.init(cfg.mgrHandlerCfg)) {
    std::cerr << "_mgrHandler.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _event.init()) {
    std::cerr << "_event.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  GameConfig gameConfig;
  if (EXIT_SUCCESS != _game.init(gameConfig)) {
    std::cerr << "_game.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void Engine::deinit() {
  _game.deinit();
  _event.deinit();
  _mgrHandler.deinit();
}

void Engine::start() {
  mainLoop();
}

void Engine::mainLoop() {
  Time time;
  while (true) {
    time.getElapsed(); //begin measure the new frame elapsed time

    if (processFrame()) {
      //user has requested exit -> break the main loop
      return;
    }

    limitFPS(time.getElapsed().toMicroseconds());
  }
}

void Engine::drawFrame() {
  gDrawMgr->clearScreen();
  _game.draw();
  gDrawMgr->finishFrame();
}

bool Engine::processFrame() {
  _mgrHandler.process();

  while (_event.pollEvent()) {
    if (_event.checkForExitRequest()) {
      return true;
    }

    handleEvent();
  }

  drawFrame();
  return false;
}

void Engine::handleEvent() {
  _game.handleEvent(_event);
}

void Engine::limitFPS(const int64_t elapsedMicroseconds) {
  constexpr auto microsecondsInASeconds = 1000000;
  const auto maxMicrosecondsPerFrame = microsecondsInASeconds
      / gDrawMgr->getMaxFrameRate();

  const int64_t microSecondsFpsDelay = maxMicrosecondsPerFrame
      - elapsedMicroseconds;
  if (0 < microSecondsFpsDelay) {
    Threading::sleepFor(microSecondsFpsDelay);
  }
}

