#ifndef UTILS_COMMON_THREADING_H_
#define UTILS_COMMON_THREADING_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers

//Forward declarations

class Threading {
public:
  Threading() = delete;

  static void sleepFor(int64_t microseconds);
};

#endif /* UTILS_COMMON_THREADING_H_ */
