//Corresponding header
#include "utils/drawing/Text.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/RsrcMgr.h"

Text::~Text() {
  //attempt to destroy text only if it's was first created and not destroyed
  if (true == _isCreated && false == _isDestroyed) {
    Text::destroy();
  }
}

void Text::create(const char *text, int32_t fontId, const Color &color,
                  const Point &pos) {
  if (_isCreated) {
    std::cerr << "Error, Text with textId: " << _drawParams.textId
              << " is already created" << std::endl;
    return;
  }
  _textContent = text;
  _color = color;
  _fontId = fontId;
  _drawParams.widgetType = WidgetType::TEXT;

  gRsrcMgr->createText(text, _color, _fontId, _drawParams.textId,
      _drawParams.width, _drawParams.height);

  _isCreated = true;
  _isDestroyed = false;
  _drawParams.pos = pos;
  _drawParams.frameRect.w = _drawParams.width;
  _drawParams.frameRect.h = _drawParams.height;
}

void Text::setText(const char *text) {
  if (_textContent == text) {
    return;
  }
  _textContent = text;

  gRsrcMgr->reloadText(text, _color, _fontId, _drawParams.textId,
      _drawParams.width, _drawParams.height);
  _drawParams.frameRect.w = _drawParams.width;
  _drawParams.frameRect.h = _drawParams.height;
}

void Text::destroy() {
  if (_isDestroyed) {
    std::cerr
        << "Warning, trying to destroy already destroyed text with textId: "
        << _drawParams.textId << std::endl;
    return;
  }

  if (!_isCreated) {
    std::cerr << "Warning, trying to destroy a not-created text with fontId: "
              << _drawParams.rsrcId << std::endl;
    return;
  }

  //sanity check, because manager could already been destroyed
  if (nullptr != gRsrcMgr) {
    //unload text from graphical text vector
    gRsrcMgr->unloadText(_drawParams.textId);
  }

  _isDestroyed = true;
  _textContent.clear();
  Widget::reset();
}

void Text::setColor(const Color &color) {
  if (_isDestroyed) {
    std::cerr
        << "Warning, trying to destroy already destroyed text with textId: "
        << _drawParams.textId << std::endl;
    return;
  }

  if (_color == color) {
    return;
  }

  _color = color;

  gRsrcMgr->reloadText(_textContent.c_str(), _color, _fontId,
      _drawParams.textId, _drawParams.width, _drawParams.height);
  _drawParams.frameRect.w = _drawParams.width;
  _drawParams.frameRect.h = _drawParams.height;
}

std::string Text::getTextContent() const {
  return _textContent;
}

