#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <unordered_map>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"

//Forward declarations
struct SDL_Texture;
class InputEvent;

class Game {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw(std::vector<SDL_Texture*> &outTextures);

  void handleEvent(const InputEvent &e);

private:
  SDL_Texture * _currChosenKeyImg = nullptr;
  std::unordered_map<GameImages, SDL_Texture *> _gameImgs;
};

#endif /* GAME_GAME_H_ */
