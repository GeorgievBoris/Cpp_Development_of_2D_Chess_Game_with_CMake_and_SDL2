//Corresponding header
#include "game/game_entities/board/GameBoardAnimator.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "game/proxies/GameInterface.h"
#include "game/defines/ChessDefines.h"

namespace {
constexpr auto ROT_STEP = 2;
constexpr auto FULL_ROT = 360;
}

int32_t GameBoardAnimator::init(GameInterface *gameInterface, FBO *boardFbo,
                                int32_t timerId) {
  if (gameInterface == nullptr) {
    std::cerr << "Error, nullptr GameInterface provided" << std::endl;
    return EXIT_FAILURE;
  }
  _gameInterface = gameInterface;
  _timerId = timerId;

  if (boardFbo == nullptr) {
    std::cerr << "Error, nullptr boardFbo provided" << std::endl;
    return EXIT_FAILURE;
  }
  _boardFbo = boardFbo;

  return EXIT_SUCCESS;
}

bool GameBoardAnimator::isActive() const {
  return isActiveTimerId(_timerId);
}

void GameBoardAnimator::startAnim(int32_t playerId) {
  if (Defines::WHITE_PLAYER == playerId) {
    _targetRotation = FULL_ROT / 2;
    _targetFlipType = WidgetFlip::HORIZONTAL_AND_VERTICAL;
  } else {
    _targetRotation = FULL_ROT;
    _targetFlipType = WidgetFlip::NONE;
  }

  constexpr auto timerInterval = 20;
  startTimer(timerInterval, _timerId, TimerType::PULSE);
}

void GameBoardAnimator::processAnim() {
  _currRotation += ROT_STEP;
  _boardFbo->setRotation(_currRotation);

  if (_currRotation == _targetRotation) {
    if (FULL_ROT == _currRotation) {
      _currRotation = 0;
    }

    stopTimer(_timerId);
    onAnimEnd();
    return;
  }
}

void GameBoardAnimator::onTimeout(int32_t timerId) {
  if (timerId != _timerId) {
    std::cerr << "Received unknown timerId: " << timerId << std::endl;
    return;
  }

  processAnim();
}

void GameBoardAnimator::onAnimEnd() {
  _gameInterface->setWidgetFlipType(_targetFlipType);
  _gameInterface->onEndTurnAnimFinished();
}

