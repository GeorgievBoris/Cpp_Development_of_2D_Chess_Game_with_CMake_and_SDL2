//Corresponding header
#include "game/Game.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "sdl/containers/ImageContainer.h"
#include "sdl/containers/TextContainer.h"
#include "utils/drawing/Color.h"
#include "common/CommonDefines.h"

int32_t Game::init(const GameConfig &cfg) {
  _imageContainer = cfg.imageContainer;
  _textContainer = cfg.textContainer;

  const Rectangle &imageFrame = _imageContainer->getImageFrame(
      Textures::PRESS_KEYS);
  _gameImg.rsrcId = Textures::PRESS_KEYS;
  _gameImg.pos.x = imageFrame.x;
  _gameImg.pos.y = imageFrame.y;
  _gameImg.width = imageFrame.w;
  _gameImg.height = imageFrame.h;
  _gameImg.widgetType = WidgetType::IMAGE;

  std::string textContent = "Hello, C++ dudes!";
  _helloText.widgetType = WidgetType::TEXT;
  _textContainer->createText(textContent.c_str(), Colors::RED,
      Fonts::ANGELINE_VINTAGE_BIG, _helloText.textId, _helloText.width,
      _helloText.height);

  textContent = "Press N to SHOW";
  _showText.widgetType = WidgetType::TEXT;
  _textContainer->createText(textContent.c_str(), Colors::GREEN,
      Fonts::ANGELINE_VINTAGE_SMALL, _showText.textId, _showText.width,
      _showText.height);
  _showText.pos.x = 100;
  _showText.pos.y = 500;

  textContent = "Press M to HIDE";
  _hideText.widgetType = WidgetType::TEXT;
  _textContainer->createText(textContent.c_str(), Colors::YELLOW,
      Fonts::ANGELINE_VINTAGE_SMALL, _hideText.textId, _hideText.width,
      _hideText.height);
  _hideText.pos.x = 400;
  _hideText.pos.y = 500;

  return EXIT_SUCCESS;
}

void Game::deinit() {

}

void Game::draw(std::vector<DrawParams> &outDrawParams) {
  outDrawParams.push_back(_gameImg);
  outDrawParams.push_back(_helloText);

  if (_isTextHidden) {
    outDrawParams.push_back(_showText);
  } else {
    outDrawParams.push_back(_hideText);
  }
}

void Game::handleEvent(const InputEvent &e) {
  if (TouchEvent::KEYBOARD_PRESS == e.type) {
    switch (e.key) {
    case Keyboard::KEY_UP:
      _gameImg.pos.y -= 10;
      break;
    case Keyboard::KEY_DOWN:
      _gameImg.pos.y += 10;
      break;
    case Keyboard::KEY_LEFT:
      _gameImg.pos.x -= 10;
      break;
    case Keyboard::KEY_RIGHT:
      _gameImg.pos.x += 10;
      break;
    case Keyboard::KEY_Q:
      _gameImg.width += 10;
      break;
    case Keyboard::KEY_W:
      _gameImg.width -= 10;
      break;
    case Keyboard::KEY_E:
      _gameImg.height += 10;
      break;
    case Keyboard::KEY_R:
      _gameImg.height -= 10;
      break;
    case Keyboard::KEY_A:
      _gameImg.opacity += 20;
      break;
    case Keyboard::KEY_S:
      _gameImg.opacity -= 20;
      break;
    case Keyboard::KEY_N:
      _isTextHidden = false;
      break;
    case Keyboard::KEY_M:
      _isTextHidden = true;
      break;
    default:
      break;
    }
  } else {
    //empty for now
  }
}
