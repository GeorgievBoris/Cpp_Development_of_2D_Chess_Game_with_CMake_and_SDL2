//Corresponding header
#include "game/game_logic/GameLogic.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "game/defines/ChessDefines.h"

GameLogic::GameLogic()
    : _activePlayerId(Defines::WHITE_PLAYER) {

}

int32_t GameLogic::getActivePlayerId() const {
  return _activePlayerId;
}

void GameLogic::finishTurn() {
  _activePlayerId =
      (Defines::WHITE_PLAYER == _activePlayerId) ?
          Defines::BLACK_PLAYER : Defines::WHITE_PLAYER;
}

