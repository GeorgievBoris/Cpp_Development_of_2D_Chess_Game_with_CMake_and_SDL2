#ifndef GAME_GAME_ENTITIES_BOARD_GAMEBOARDANIMATOR_H_
#define GAME_GAME_ENTITIES_BOARD_GAMEBOARDANIMATOR_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/FBO.h"
#include "utils/time/TimerClient.h"

//Forward declarations
class GameInterface;

class GameBoardAnimator : public TimerClient {
public:
  int32_t init(GameInterface *gameInterface, FBO *boardFbo, int32_t timerId);

  void startAnim(int32_t playerId);

  bool isActive() const;

private:
  void onTimeout(int32_t timerId) final;

  void processAnim();

  void onAnimEnd();

  GameInterface *_gameInterface = nullptr;
  FBO *_boardFbo = nullptr;
  int32_t _timerId { 0 };
  int32_t _currRotation { 0 };
  int32_t _targetRotation { 0 };
  WidgetFlip _targetFlipType = WidgetFlip::NONE;
};

#endif /* GAME_GAME_ENTITIES_BOARD_GAMEBOARDANIMATOR_H_ */
