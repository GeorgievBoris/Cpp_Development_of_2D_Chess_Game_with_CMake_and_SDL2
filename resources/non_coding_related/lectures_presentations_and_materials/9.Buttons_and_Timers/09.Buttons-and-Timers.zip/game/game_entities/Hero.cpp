//Corresponding header
#include "game/game_entities/Hero.h"

//C system headers

//C++ system headers
#include <cstdlib>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"

int32_t Hero::init(int32_t heroRsrcId) {
  _hero.create(heroRsrcId);

  return EXIT_SUCCESS;
}

void Hero::deinit() {

}

void Hero::draw() {
  _hero.draw();
}

void Hero::handleEvent(const InputEvent &e) {
  if (TouchEvent::KEYBOARD_PRESS == e.type) {
    switch (e.key) {
    case Keyboard::KEY_UP:
      _hero.moveUp(10);
      break;
    case Keyboard::KEY_DOWN:
      _hero.moveDown(10);
      break;
    case Keyboard::KEY_LEFT:
      _hero.moveLeft(10);
      break;
    case Keyboard::KEY_RIGHT:
      _hero.moveRight(10);
      break;
    case Keyboard::KEY_U:
      _hero.setWidgetFlip(WidgetFlip::NONE);
      break;
    case Keyboard::KEY_I:
      _hero.setWidgetFlip(WidgetFlip::HORIZONTAL);
      break;
    case Keyboard::KEY_O:
      _hero.setWidgetFlip(WidgetFlip::VERTICAL);
      break;
    case Keyboard::KEY_P:
      _hero.setWidgetFlip(WidgetFlip::HORIZONTAL_AND_VERTICAL);
      break;
    case Keyboard::KEY_NUMPAD_PLUS:
      _hero.setNextFrame();
      break;
    case Keyboard::KEY_NUMPAD_MINUS:
      _hero.setPrevFrame();
      break;
    default:
      break;
    }
  }
}
