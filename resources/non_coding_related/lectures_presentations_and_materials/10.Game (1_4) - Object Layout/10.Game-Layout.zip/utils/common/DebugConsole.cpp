//Corresponding header
#include "DebugConsole.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "common/CommonDefines.h"

namespace {
constexpr auto UPDATE_SKIPS = 20;
}

int32_t DebugConsole::init(uint32_t maxFrames) {
  _maxFrames = maxFrames;

  _fpsText.create("0", Fonts::ANGELINE_VINTAGE_SMALL, Colors::YELLOW,
      Point(20, 20));

  return EXIT_SUCCESS;
}

void DebugConsole::handleEvent(const InputEvent &e) {
  if (TouchEvent::KEYBOARD_RELEASE == e.type) {
    if (Keyboard::KEY_TILDA == e.key) {
      _isActive = !_isActive;
    }
  }
}

//update fps text once in a while to get a stable(not constantly changing) image
void DebugConsole::update(int64_t elapsedMicroseconds) {
  --_updateCounter;
  if (0 < _updateCounter) {
    return;
  }
  _updateCounter = UPDATE_SKIPS;

  constexpr auto microsecondsInASecond = 1000000;
  uint32_t currFrames = static_cast<uint32_t>(microsecondsInASecond
      / elapsedMicroseconds);
  if (currFrames > _maxFrames) {
    currFrames = _maxFrames;
  }

  std::string textContent = "FPS: ";
  textContent.append(std::to_string(currFrames));
  _fpsText.setText(textContent.c_str());
}

void DebugConsole::draw() {
  _fpsText.draw();
}

bool DebugConsole::isActive() const {
  return _isActive;
}

