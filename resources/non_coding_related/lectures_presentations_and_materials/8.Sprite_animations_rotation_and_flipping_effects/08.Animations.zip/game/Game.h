#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"
#include "game/game_entities/Hero.h"
#include "game/game_entities/Wheel.h"
#include "utils/drawing/Text.h"

//Forward declarations
class InputEvent;

class Game {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  Hero _hero;
  Wheel _wheel;
  Text _mouseTargetText;
};

#endif /* GAME_GAME_H_ */
