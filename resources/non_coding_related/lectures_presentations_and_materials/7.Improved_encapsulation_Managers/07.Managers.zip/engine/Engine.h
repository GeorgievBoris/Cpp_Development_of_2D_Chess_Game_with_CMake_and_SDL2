#ifndef ENGINE_ENGINE_H_
#define ENGINE_ENGINE_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "engine/config/EngineConfig.h"
#include "managers/MgrHandler.h"
#include "game/Game.h"

//Forward declarations

class Engine {
public:
  int32_t init(const EngineConfig &cfg);

  void deinit();

  void start();

private:
  void mainLoop();

  void drawFrame();

  bool processFrame();

  void handleEvent();

  void limitFPS(const int64_t elapsedMicroseconds);

  MgrHandler _mgrHandler;
  InputEvent _event;
  Game _game;
};

#endif /* ENGINE_ENGINE_H_ */
