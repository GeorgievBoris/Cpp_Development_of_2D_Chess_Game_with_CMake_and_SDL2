#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"
#include "utils/drawing/Image.h"
#include "utils/drawing/Text.h"

//Forward declarations
class InputEvent;

class Game {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw();

  void handleEvent(const InputEvent &e);

private:
  Image _gameImg;
  Text _helloText;
  Text _showText;
  Text _hideText;
  Text _mouseTargetText;
};

#endif /* GAME_GAME_H_ */
