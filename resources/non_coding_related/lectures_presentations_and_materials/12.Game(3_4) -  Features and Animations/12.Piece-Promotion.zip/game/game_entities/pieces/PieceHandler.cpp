//Corresponding header
#include "game/game_entities/pieces/PieceHandler.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "game/game_entities/utils/BoardUtils.h"
#include "game/proxies/GameBoardInterface.h"
#include "game/proxies/GameInterface.h"

int32_t PieceHandler::init(GameBoardInterface *gameBoardInterface,
                           GameInterface *gameInterface,
                           int32_t whitePiecesRsrcId, int32_t blackPiecesRsrcId,
                           int32_t notReadyFontRsrcId) {
  if (!gameBoardInterface) {
    std::cerr << "Error, nullptr GameBoardInterface provided" << std::endl;
    return EXIT_FAILURE;
  }
  _gameBoardInterface = gameBoardInterface;

  if (!gameInterface) {
    std::cerr << "Error, nullptr GameInterface provided" << std::endl;
    return EXIT_FAILURE;
  }
  _gameInterface = gameInterface;

  if (EXIT_SUCCESS != PieceHandlerPopulator::populateWhitePieces(gameInterface,
          _pieces[Defines::WHITE_PLAYER], whitePiecesRsrcId,
          notReadyFontRsrcId)) {
    std::cerr << "Error, populateWhitePieces() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != PieceHandlerPopulator::populateBlackPieces(gameInterface,
          _pieces[Defines::BLACK_PLAYER], blackPiecesRsrcId,
          notReadyFontRsrcId)) {
    std::cerr << "Error, populateBlackPieces() failed" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void PieceHandler::deinit() {

}

void PieceHandler::draw() {
  for (auto &playerPieces : _pieces) {
    for (auto &piece : playerPieces) {
      piece->draw();
    }
  }
}

void PieceHandler::handleEvent(const InputEvent &e) {
  _isPieceGrabbed ? handlePieceGrabbedEvent(e) : handleNoPieceGrabbedEvent(e);
}

void PieceHandler::setActivePlayerId(int32_t activePlayerId) {
  _activePlayerId = activePlayerId;
}

void PieceHandler::handlePieceGrabbedEvent(const InputEvent &e) {
  if (TouchEvent::TOUCH_RELEASE != e.type) {
    return;
  }
  _isPieceGrabbed = false;

  if (!BoardUtils::isInsideBoard(e.pos)) {
    return;
  }

  const BoardPos boardPos = BoardUtils::getBoardPos(e.pos);
  if (!_gameBoardInterface->isMoveAllowed(boardPos)) {
    _gameBoardInterface->onPieceUngrabbed();
    return;
  }

  doMovePiece(boardPos);
}

void PieceHandler::handleNoPieceGrabbedEvent(const InputEvent &e) {
  if (TouchEvent::TOUCH_RELEASE != e.type) {
    return;
  }

  int32_t pieceId = 0;
  for (auto &piece : _pieces[_activePlayerId]) {
    if (piece->containsEvent(e)) {
      _isPieceGrabbed = true;
      _selectedPieceId = pieceId;
      _gameBoardInterface->onPieceGrabbed(piece->getBoardPos(),
          piece->getMoveTiles(_pieces));
      return;
    }
    ++pieceId;
  }
}

void PieceHandler::doMovePiece(const BoardPos &boardPos) {
  _pieces[_activePlayerId][_selectedPieceId]->setBoardPos(boardPos);
  _gameBoardInterface->onPieceUngrabbed();

  const int32_t enemyPlayerId = BoardUtils::getOpponentId(_activePlayerId);
  int32_t relativePieceId = -1;
  if (BoardUtils::doCollideWithPiece(boardPos, _pieces[enemyPlayerId],
      &relativePieceId)) {
    //erase the piece
    _pieces[enemyPlayerId].erase(
        _pieces[enemyPlayerId].begin() + relativePieceId);
  }

  _gameInterface->finishTurn();
}

void PieceHandler::promotePiece([[maybe_unused]]PieceType pieceType) {

}

void PieceHandler::setWidgetFlipType(WidgetFlip flipType) {
  for (auto &playerPieces : _pieces) {
    for (auto &piece : playerPieces) {
      piece->setWidgetFlipType(flipType);
    }
  }
}

