#ifndef UTILS_DRAWING_POINT_H_
#define UTILS_DRAWING_POINT_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers

//Forward declarations

struct Point {
  Point() = default;
  Point(int32_t inputX, int32_t inputY);

  Point(const Point& other) = default;

  bool operator ==(const Point &other) const;
  bool operator !=(const Point &other) const;

  int32_t x { 0 };
  int32_t y { 0 };

  static const Point ZERO;
  static const Point UNDEFINED;
};

#endif /* UTILS_DRAWING_POINT_H_ */
