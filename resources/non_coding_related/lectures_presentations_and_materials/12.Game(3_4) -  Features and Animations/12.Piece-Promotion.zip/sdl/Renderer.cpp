//Corresponding header
#include "sdl/Renderer.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include <SDL_render.h>
#include <SDL_hints.h>

//Own components headers
#include "sdl/Texture.h"
#include "managers/RsrcMgr.h"

int32_t Renderer::init(SDL_Window *window) {
  /** Set texture filtering to linear
   *                      (used for image scaling /pixel interpolation/ )
   * */
  if (!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "1")) {
    std::cerr << "Warning: Linear texture filtering not enabled! "
              "SDL_SetHint() failed. SDL Error: "
              << SDL_GetError() << std::endl;
    return EXIT_FAILURE;
  }

  constexpr auto unspecifiedRendererDriver = -1;

  //Create renderer for window
  _sdlRenderer = SDL_CreateRenderer(window, unspecifiedRendererDriver,
      SDL_RENDERER_ACCELERATED);

  if (nullptr == _sdlRenderer) {
    std::cerr << "Renderer could not be created! SDL Error: " << SDL_GetError()
              << std::endl;
    return EXIT_FAILURE;
  }

  //Initialize renderer color to black
  if (EXIT_SUCCESS != SDL_SetRenderDrawColor(_sdlRenderer, 0, 0, 0,
  SDL_ALPHA_OPAQUE)) {
    std::cerr << "Error in, SDL_SetRenderDrawColor(), SDL Error: "
              << SDL_GetError() << std::endl;
    return EXIT_FAILURE;
  }

  Texture::setRenderer(_sdlRenderer);
  return EXIT_SUCCESS;
}

void Renderer::deinit() {
  if (_sdlRenderer) { //sanity check
    SDL_DestroyRenderer(_sdlRenderer);
    _sdlRenderer = nullptr;
  }
}

void Renderer::clearScreen() {
  if (EXIT_SUCCESS != SDL_RenderClear(_sdlRenderer)) {
    std::cerr << "Error in, SDL_RenderClear(), SDL Error: " << SDL_GetError()
              << std::endl;
  }
}

void Renderer::finishFrame() {
  SDL_RenderPresent(_sdlRenderer);
}

void Renderer::drawWidget(const DrawParams &drawParams) {
  SDL_Texture *texture = getTargetTexture(drawParams);

  if (WidgetType::IMAGE == drawParams.widgetType) {
    drawImage(drawParams, texture);
  } else if (WidgetType::TEXT == drawParams.widgetType) {
    drawText(drawParams, texture);
  } else {
    std::cerr << "Warning, received unknown widgetType "
              << static_cast<int32_t>(drawParams.widgetType) << std::endl;
  }
}

void Renderer::setWidgetBlendMode(const DrawParams &drawParams,
                                  BlendMode blendMode) {
  SDL_Texture *texture = getTargetTexture(drawParams);
  if (EXIT_SUCCESS != Texture::setBlendMode(texture, blendMode)) {
    std::cerr << "Error in Texture::setBlendMode() for rsrcId: "
              << drawParams.rsrcId << std::endl;
  }
}

void Renderer::setWidgetOpacity(const DrawParams &drawParams, int32_t opacity) {
  if (WidgetType::IMAGE == drawParams.widgetType) {
    return;
  }

  SDL_Texture *texture = getTargetTexture(drawParams);
  if (EXIT_SUCCESS != Texture::setAlpha(texture, opacity)) {
    std::cerr << "Error in Texture::setAlpha() for rsrcId: "
              << drawParams.rsrcId << ". Unsupported opacity: " << opacity
              << ". Opacity works in the boundaries [0-255]" << std::endl;
  }
}

void Renderer::drawImage(const DrawParams &drawParams, SDL_Texture *texture) {
  SDL_Rect destRect;
  destRect.x = drawParams.pos.x;
  destRect.y = drawParams.pos.y;
  destRect.w = drawParams.width;
  destRect.h = drawParams.height;
  int32_t errorCode = 0;

  if (FULL_OPACITY == drawParams.opacity) {
    errorCode = SDL_RenderCopyEx(_sdlRenderer, texture,
        reinterpret_cast<const SDL_Rect*>(&drawParams.frameRect), &destRect,
        drawParams.rotationAngle,
        reinterpret_cast<const SDL_Point*>(&drawParams.rotationCenter),
        static_cast<SDL_RendererFlip>(drawParams.widgetFlip));
  } else {
    if (EXIT_SUCCESS != Texture::setAlpha(texture, drawParams.opacity)) {
      std::cerr << "Error, Texture::setAlpha() failed for widget with Id: "
                << drawParams.rsrcId << std::endl;
    }
    errorCode = SDL_RenderCopyEx(_sdlRenderer, texture,
        reinterpret_cast<const SDL_Rect*>(&drawParams.frameRect), &destRect,
        drawParams.rotationAngle,
        reinterpret_cast<const SDL_Point*>(&drawParams.rotationCenter),
        static_cast<SDL_RendererFlip>(drawParams.widgetFlip));
    if (EXIT_SUCCESS != Texture::setAlpha(texture, FULL_OPACITY)) {
      std::cerr << "Error, Texture::setAlpha() failed for widget with Id: "
                << drawParams.rsrcId << std::endl;
    }
  }

  if (EXIT_SUCCESS != errorCode) {
    std::cerr << "Error in, SDL_RenderCopy(), SDL Error: " << SDL_GetError()
              << std::endl;
  }
}

void Renderer::drawText(const DrawParams &drawParams, SDL_Texture *texture) {
  SDL_Rect destRect;
  destRect.x = drawParams.pos.x;
  destRect.y = drawParams.pos.y;
  destRect.w = drawParams.width;
  destRect.h = drawParams.height;

  if (EXIT_SUCCESS != SDL_RenderCopyEx(_sdlRenderer, texture,
          reinterpret_cast<const SDL_Rect*>(&drawParams.frameRect), &destRect,
          drawParams.rotationAngle,
          reinterpret_cast<const SDL_Point*>(&drawParams.rotationCenter),
          static_cast<SDL_RendererFlip>(drawParams.widgetFlip))) {
    std::cerr << "Error in, SDL_RenderCopy(), SDL Error: " << SDL_GetError()
              << std::endl;
  }
}

SDL_Texture* Renderer::getTargetTexture(const DrawParams &widgetInfo) {
  SDL_Texture *texture = nullptr;
  if (WidgetType::IMAGE == widgetInfo.widgetType) {
    texture = gRsrcMgr->getImageTexture(widgetInfo.rsrcId);
  } else if (WidgetType::TEXT == widgetInfo.widgetType) {
    texture = gRsrcMgr->getTextTexture(widgetInfo.textId);
  } else {
    std::cerr << "Warning, received unknown widgetType: "
              << static_cast<int32_t>(widgetInfo.widgetType) << " for rsrcId: "
              << widgetInfo.rsrcId << std::endl;
  }
  return texture;
}

