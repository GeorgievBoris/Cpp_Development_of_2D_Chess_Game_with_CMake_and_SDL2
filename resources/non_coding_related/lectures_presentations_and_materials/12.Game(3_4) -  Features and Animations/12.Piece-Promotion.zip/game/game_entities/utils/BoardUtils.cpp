//Corresponding header
#include "game/game_entities/utils/BoardUtils.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "game/game_entities/pieces/ChessPiece.h"
#include "utils/drawing/Rectangle.h"

namespace {
constexpr auto BOARD_SIZE = 8;

constexpr auto FIRST_TILE_X_POS = 58;
constexpr auto FIRST_TILE_Y_POS = 60;

constexpr auto TILE_SIZE = 98;
}

BoardPos BoardUtils::getBoardPos(const Point &absPos) {
  return Point( (absPos.y - FIRST_TILE_X_POS) / TILE_SIZE,
      (absPos.x - FIRST_TILE_Y_POS) / TILE_SIZE);
}

Point BoardUtils::getAbsPos(const BoardPos &boardPos) {
  return Point(FIRST_TILE_X_POS + boardPos.col * TILE_SIZE,
      FIRST_TILE_Y_POS + boardPos.row * TILE_SIZE);
}

bool BoardUtils::isInsideBoard(const BoardPos &boardPos) {
  if (0 > boardPos.row || BOARD_SIZE <= boardPos.row) {
    return false;
  }

  if (0 > boardPos.col || BOARD_SIZE <= boardPos.col) {
    return false;
  }

  return true;
}

bool BoardUtils::isInsideBoard(const Point &absPos) {
  const Rectangle boundary(FIRST_TILE_X_POS, FIRST_TILE_Y_POS,
      BOARD_SIZE * TILE_SIZE, BOARD_SIZE * TILE_SIZE);

  return boundary.isPointInRect(absPos);
}

int32_t BoardUtils::getOpponentId(int32_t activePlayerId) {
  if (Defines::WHITE_PLAYER == activePlayerId) {
    return Defines::BLACK_PLAYER;
  }

  return Defines::WHITE_PLAYER;
}

BoardPos BoardUtils::getAdjacentPos(Defines::Direction dir,
                                    const BoardPos &currPos) {
  BoardPos futurePos = currPos;

  switch (dir) {
  case Defines::Direction::UP_LEFT:
    --futurePos.row;
    --futurePos.col;
    break;

  case Defines::Direction::UP:
    --futurePos.row;
    break;

  case Defines::Direction::UP_RIGHT:
    --futurePos.row;
    ++futurePos.col;
    break;

  case Defines::Direction::RIGHT:
    ++futurePos.col;
    break;

  case Defines::Direction::DOWN_RIGHT:
    ++futurePos.row;
    ++futurePos.col;
    break;

  case Defines::Direction::DOWN:
    ++futurePos.row;
    break;

  case Defines::Direction::DOWN_LEFT:
    ++futurePos.row;
    --futurePos.col;
    break;

  case Defines::Direction::LEFT:
    --futurePos.col;
    break;

  default:
    std::cerr << "Error, received unknown dir: " << dir << std::endl;
    break;
  }

  return futurePos;
}

bool BoardUtils::doCollideWithPiece(const BoardPos &selectedPos,
                                    const ChessPiece::PlayerPieces &pieces,
                                    int32_t *outCollisionRelativeId) {
  int32_t pieceRelativeId = 0;
  for (const auto &piece : pieces) {
    if (selectedPos == piece->getBoardPos()) {
      if (outCollisionRelativeId) {
        *outCollisionRelativeId = pieceRelativeId;
      }
      return true;
    }
    ++pieceRelativeId;
  }

  return false;
}

TileType BoardUtils::getTileType(const BoardPos &boardPos,
                                 const ChessPiece::PlayerPieces &playerPieces,
                                 const ChessPiece::PlayerPieces &enemyPieces) {
  if (BoardUtils::doCollideWithPiece(boardPos, enemyPieces)) {
    return TileType::TAKE;
  }

  if (BoardUtils::doCollideWithPiece(boardPos, playerPieces)) {
    return TileType::GUARD;
  }

  return TileType::MOVE;
}

