#ifndef GAME_GAME_ENTITIES_BOARD_MOVESELECTOR_H_
#define GAME_GAME_ENTITIES_BOARD_MOVESELECTOR_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>
#include <array>

//Other libraries headers

//Own components headers
#include "utils/drawing/Image.h"

//Forward declarations
struct TileData;

class MoveSelector {
public:
  int32_t init(int32_t tileRsrcId);

  void draw();

  void markTiles(const std::vector<TileData> &markedTiles);

  void unmarkTiles();

private:
  enum InternalDefines {
    MAX_ACTIVE_TILES = 28
  };

  std::array<Image, MAX_ACTIVE_TILES> _tileImgs;
  size_t _activeTiles { 0 };
};

#endif /* GAME_GAME_ENTITIES_BOARD_MOVESELECTOR_H_ */
