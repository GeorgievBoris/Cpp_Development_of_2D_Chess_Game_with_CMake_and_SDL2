#ifndef COMMON_TIMERS_H_
#define COMMON_TIMERS_H_

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

//Forward declarations

namespace Timers {
  enum Ids {

  };
}

#endif /* COMMON_TIMERS_H_ */
