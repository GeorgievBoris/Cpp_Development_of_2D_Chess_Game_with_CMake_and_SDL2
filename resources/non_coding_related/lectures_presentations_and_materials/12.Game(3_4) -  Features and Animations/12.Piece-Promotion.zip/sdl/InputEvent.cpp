//Corresponding header
#include "sdl/InputEvent.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers
#include <SDL_events.h>

//Own components headers
#include "utils/drawing/Rectangle.h"

int32_t InputEvent::init() {
  _sdlEvent = new SDL_Event;
  if (nullptr == _sdlEvent) {
    std::cerr << "Error, bad alloc for SDL_Event" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void InputEvent::deinit() {
  if (nullptr != _sdlEvent) { //sanity check
    delete _sdlEvent;
    _sdlEvent = nullptr;
  }
}

bool InputEvent::pollEvent() {
  //Poll for currently pending events
  if (0 == SDL_PollEvent(_sdlEvent)) {
    return false; //event queue is empty
  }

  /* capture mouse position on the screen */
  SDL_GetMouseState(&pos.x, &pos.y);
  setEventTypeInternal();

  return true; //InputEvent found on the event queue
}

void InputEvent::setEventTypeInternal() {
  switch (_sdlEvent->type) {
  case EventType::KEYBOARD_PRESS:
    type = TouchEvent::KEYBOARD_PRESS;
    key = _sdlEvent->key.keysym.sym;;
    mouseButton = Mouse::UNKNOWN;
    break;

  case EventType::KEYBOARD_RELEASE:
    type = TouchEvent::KEYBOARD_RELEASE;
    key = _sdlEvent->key.keysym.sym;
    mouseButton = Mouse::UNKNOWN;
    break;

    //NOTE: the fall-through is intentional
  case EventType::MOUSE_PRESS:
  case EventType::FINGER_PRESS:
    type = TouchEvent::TOUCH_PRESS;
    key = Keyboard::KEY_UNKNOWN;
    mouseButton = _sdlEvent->button.button;
    break;

  case EventType::MOUSE_RELEASE:
  case EventType::FINGER_RELEASE:
    type = TouchEvent::TOUCH_RELEASE;
    key = Keyboard::KEY_UNKNOWN;
    mouseButton = _sdlEvent->button.button;
    break;

    //X is pressed on the window (or CTRL-C signal is sent)
  case EventType::QUIT:
    type = TouchEvent::UNKNOWN;
    key = Keyboard::KEY_UNKNOWN;
    mouseButton = Mouse::UNKNOWN;
    break;

  default:
    type = TouchEvent::UNKNOWN;
    key = Keyboard::KEY_UNKNOWN;
    mouseButton = Mouse::UNKNOWN;
    break;
  }
}

bool InputEvent::checkForExitRequest() const {
  return EventType::QUIT == _sdlEvent->type || Keyboard::KEY_ESCAPE == key;
}

