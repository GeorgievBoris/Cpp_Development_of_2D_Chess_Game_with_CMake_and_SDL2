#ifndef ENGINE_ENGINECONFIG_H_
#define ENGINE_ENGINECONFIG_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "sdl/config/MonitorWindowConfig.h"
#include "sdl/config/ImageContainerConfig.h"

//Forward declarations

struct EngineConfig {
  MonitorWindowConfig windowCfg;
  ImageContainerConfig imageContainerCfg;
};

#endif /* ENGINE_ENGINECONFIG_H_ */
