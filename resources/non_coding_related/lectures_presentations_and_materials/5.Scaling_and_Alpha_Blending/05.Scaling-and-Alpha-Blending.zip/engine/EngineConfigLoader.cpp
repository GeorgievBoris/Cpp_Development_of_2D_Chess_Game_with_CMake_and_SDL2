//Corresponding header
#include "engine/EngineConfigLoader.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "common/CommonDefines.h"

//constants
namespace {
//Screen dimension constants
constexpr auto DISPLAY_MODE = 4; //SDL_WINDOW_SHOWN from <SDL_video.h>
constexpr auto SCREEN_WIDTH = 640;
constexpr auto SCREEN_HEIGHT = 480;
constexpr auto WINDOW_NAME = "C++_App_Dev";
}

EngineConfig EngineConfigLoader::loadConfig() {
  EngineConfig cfg;

  cfg.windowCfg.displayMode = DISPLAY_MODE;
  cfg.windowCfg.windowWidth = SCREEN_WIDTH;
  cfg.windowCfg.windowHeight = SCREEN_HEIGHT;
  cfg.windowCfg.windowName = WINDOW_NAME;

  ImageConfig currImgCfg;
  currImgCfg.location = "../resources/press_keys.png";
  currImgCfg.width = 640;
  currImgCfg.height = 480;
  cfg.imageContainerCfg.imageConfigs.insert(
      std::make_pair(Textures::PRESS_KEYS, currImgCfg));

  return cfg;
}
