//Corresponding header
#include "engine/Engine.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers
#include <SDL_timer.h>
#include <SDL_video.h>

//Own components headers
#include "sdl/Texture.h"
#include "utils/time/Time.h"
#include "utils/common/Threading.h"

int32_t Engine::init() {
  //Screen dimension constants
  constexpr int SCREEN_WIDTH = 640;
  constexpr int SCREEN_HEIGHT = 480;

  MonitorWindowCfg windowCfg;
  windowCfg.displayMode = SDL_WINDOW_SHOWN;
  windowCfg.windowWidth = SCREEN_WIDTH;
  windowCfg.windowHeight = SCREEN_HEIGHT;
  windowCfg.windowName = "SDL_Runtime";

  if (EXIT_SUCCESS != _window.init(windowCfg)) {
    std::cerr << "window.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  const std::string imagePaths[COUNT] {
    "../resources/up.png",
    "../resources/down.png",
    "../resources/left.png",
    "../resources/right.png",
    "../resources/press_keys.png"
  };

  for (int32_t i = 0; i < COUNT; ++i) {
    if (EXIT_SUCCESS != Texture::loadSurfaceFromFile(imagePaths[i].c_str(),
            _imageSurfaces[i])) {
      std::cerr << "Texture::loadSurfaceFromFile() failed" << std::endl;
      return EXIT_FAILURE;
    }
  }

  _currChosenImage = _imageSurfaces[ALL_KEYS];

  if (EXIT_SUCCESS != _event.init()) {
    std::cerr << "_event.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  //Get window surface
  _screenSurface = SDL_GetWindowSurface(_window.getWindow());

  return EXIT_SUCCESS;
}

void Engine::deinit() {
  Texture::freeSurface(_screenSurface);
  for (int32_t i = 0; i < COUNT; ++i) {
    Texture::freeSurface(_imageSurfaces[i]);
  }
  _event.deinit();
  _window.deinit();
}

void Engine::start() {
  mainLoop();
}

void Engine::mainLoop() {
  Time time;
  while (true) {
    time.getElapsed(); //begin measure the new frame elapsed time

    if (processFrame()) {
      //user has requested exit -> break the main loop
      return;
    }

    limitFPS(time.getElapsed().toMicroseconds());
  }
}

void Engine::drawFrame() {
  //Apply(update) the image
  SDL_BlitSurface(_currChosenImage, nullptr, _screenSurface, nullptr);

  //Update the window surface
  SDL_UpdateWindowSurface(_window.getWindow());
}

void Engine::handleEvent() {
  //do something with the event

  if (TouchEvent::KEYBOARD_PRESS == _event.type) {
    switch (_event.key) {
    case Keyboard::KEY_UP:
      _currChosenImage = _imageSurfaces[UP];
      break;
    case Keyboard::KEY_DOWN:
      _currChosenImage = _imageSurfaces[DOWN];
      break;
    case Keyboard::KEY_LEFT:
      _currChosenImage = _imageSurfaces[LEFT];
      break;
    case Keyboard::KEY_RIGHT:
      _currChosenImage = _imageSurfaces[RIGHT];
      break;
    default:
      break;
    }
  }
  else {
    _currChosenImage = _imageSurfaces[ALL_KEYS];
  }
}

bool Engine::processFrame() {
  while (_event.pollEvent()) {
    if (_event.checkForExitRequest()) {
      return true;
    }

    handleEvent();
  }

  drawFrame();
  return false;
}

void Engine::limitFPS(const int64_t elapsedMicroseconds) {
  constexpr auto maxFrames = 60;
  constexpr auto microsecondsInASeconds = 1000000;
  constexpr auto maxMicrosecondsPerFrame = microsecondsInASeconds / maxFrames;

  const int64_t microSecondsFpsDelay =
      maxMicrosecondsPerFrame - elapsedMicroseconds;
  if (0 < microSecondsFpsDelay) {
    Threading::sleepFor(microSecondsFpsDelay);
  }
}

