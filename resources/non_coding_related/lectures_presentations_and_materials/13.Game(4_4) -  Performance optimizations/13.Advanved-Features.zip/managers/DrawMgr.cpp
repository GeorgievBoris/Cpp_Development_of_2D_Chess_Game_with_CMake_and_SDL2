//Corresponding header
#include "managers/DrawMgr.h"

//C system headers

//C++ system headers
#include <iostream>

//Other libraries headers

//Own components headers
#include "managers/config/DrawMgrConfig.h"

DrawMgr *gDrawMgr = nullptr;

int32_t DrawMgr::init(const DrawMgrConfig &cfg) {
  if (EXIT_SUCCESS != _window.init(cfg.windowCfg)) {
    std::cerr << "window.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _renderer.init(_window.getWindow())) {
    std::cerr << "_renderer.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  _maxFrames = cfg.maxFrames;

  return EXIT_SUCCESS;
}

void DrawMgr::deinit() {
  _renderer.deinit();
  _window.deinit();
}

void DrawMgr::process() {

}

void DrawMgr::clearScreen() {
  _renderer.clearScreen();
}

void DrawMgr::finishFrame() {
  _renderer.finishFrame();
}

void DrawMgr::addDrawCmd(const DrawParams &drawParams) {
  _renderer.drawWidget(drawParams);
}

void DrawMgr::setWidgetBlendMode(const DrawParams &drawParams,
                                 BlendMode blendMode) {
  _renderer.setWidgetBlendMode(drawParams, blendMode);
}

void DrawMgr::setWidgetOpacity(const DrawParams &drawParams, int32_t opacity) {
  _renderer.setWidgetOpacity(drawParams, opacity);
}

void DrawMgr::setMaxFrameRate(uint32_t maxFrames) {
  _maxFrames = maxFrames;
}

uint32_t DrawMgr::getMaxFrameRate() const {
  return _maxFrames;
}

int32_t DrawMgr::getFrameWidgetsCount() const {
  return _renderer.getFrameWidgetsCount();
}

int32_t DrawMgr::lockRenderer() {
  return _renderer.lockRenderer();
}

int32_t DrawMgr::unlockRenderer() {
  return _renderer.unlockRenderer();
}

void DrawMgr::resetRendererTarget() {
  _renderer.resetRendererTarget();
}

void DrawMgr::clearCurrentRendererTarget(const Color &color) {
  _renderer.clearCurrentRendererTarget(color);
}

void DrawMgr::changeRendererTarget(int32_t fboId) {
  _renderer.changeRendererTarget(fboId);
}

void DrawMgr::updateCurrRendererTarget(const DrawParams drawParams[],
                                       size_t size) {
  _renderer.updateCurrRendererTarget(drawParams, size);
}

