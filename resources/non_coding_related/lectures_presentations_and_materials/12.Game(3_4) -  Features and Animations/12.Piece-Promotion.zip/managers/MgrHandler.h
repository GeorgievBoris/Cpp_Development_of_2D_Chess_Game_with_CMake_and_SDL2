#ifndef MANAGERS_MANAGERHANDLER_H_
#define MANAGERS_MANAGERHANDLER_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers

//Forward declarations
class MgrBase;
struct MgrHandlerConfig;

namespace Managers {
enum Indexes {
  DRAW_MGR_IDX, RSRC_MGR_IDX, TIMER_MGR_IDX,

  TOTAL_MGRS_COUNT
};
}

class MgrHandler {
public:
  int32_t init(const MgrHandlerConfig &cfg);

  void deinit();

  void process();

private:
  void nullifyGlobalManager(const int32_t managerId);

  MgrBase *_managers[Managers::TOTAL_MGRS_COUNT];
};

#endif /* MANAGERS_MANAGERHANDLER_H_ */

