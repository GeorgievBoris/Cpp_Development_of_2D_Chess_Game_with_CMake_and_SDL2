//Corresponding header
#include "engine/Engine.h"

//C system headers

//C++ system headers
#include <iostream>
#include <string>

//Other libraries headers

//Own components headers
#include "sdl/Texture.h"
#include "engine/config/EngineConfig.h"
#include "utils/time/Time.h"
#include "utils/common/Threading.h"

int32_t Engine::init(const EngineConfig &cfg) {
  if (EXIT_SUCCESS != _window.init(cfg.windowCfg)) {
    std::cerr << "window.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _renderer.init(_window.getWindow())) {
    std::cerr << "_renderer.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _event.init()) {
    std::cerr << "_event.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  if (EXIT_SUCCESS != _game.init(cfg.gameCfg)) {
    std::cerr << "_game.init() failed" << std::endl;
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

void Engine::deinit() {
  _game.deinit();
  _event.deinit();
  _renderer.deinit();
  _window.deinit();
}

void Engine::start() {
  mainLoop();
}

void Engine::mainLoop() {
  Time time;
  while (true) {
    time.getElapsed(); //begin measure the new frame elapsed time

    if (processFrame()) {
      //user has requested exit -> break the main loop
      return;
    }

    limitFPS(time.getElapsed().toMicroseconds());
  }
}

void Engine::drawFrame() {
  _renderer.clearScreen();

  std::vector<SDL_Texture *> textures;
  _game.draw(textures);

  for (SDL_Texture * texture : textures) {
    _renderer.renderTexture(texture);
  }

  _renderer.finishFrame();
}

bool Engine::processFrame() {
  while (_event.pollEvent()) {
    if (_event.checkForExitRequest()) {
      return true;
    }

    handleEvent();
  }

  drawFrame();
  return false;
}

void Engine::handleEvent() {
  _game.handleEvent(_event);
}

void Engine::limitFPS(const int64_t elapsedMicroseconds) {
  constexpr auto maxFrames = 60;
  constexpr auto microsecondsInASeconds = 1000000;
  constexpr auto maxMicrosecondsPerFrame = microsecondsInASeconds / maxFrames;

  const int64_t microSecondsFpsDelay =
      maxMicrosecondsPerFrame - elapsedMicroseconds;
  if (0 < microSecondsFpsDelay) {
    Threading::sleepFor(microSecondsFpsDelay);
  }
}

