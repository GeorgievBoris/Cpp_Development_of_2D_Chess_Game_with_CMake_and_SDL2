#ifndef GAME_GAME_H_
#define GAME_GAME_H_

//C system headers

//C++ system headers
#include <cstdint>
#include <vector>

//Other libraries headers

//Own components headers
#include "game/config/GameConfig.h"
#include "utils/drawing/DrawParams.h"

//Forward declarations
class InputEvent;
class ImageContainer;
class TextContainer;

class Game {
public:
  int32_t init(const GameConfig &cfg);

  void deinit();

  void draw(std::vector<DrawParams> &outDrawParams);

  void handleEvent(const InputEvent &e);

private:
  DrawParams _gameImg;
  DrawParams _helloText;
  DrawParams _showText;
  DrawParams _hideText;

  //TODO remove me
  const ImageContainer *_imageContainer = nullptr;
  TextContainer *_textContainer = nullptr;

  //having fun
  bool _isTextHidden = false;
};

#endif /* GAME_GAME_H_ */
