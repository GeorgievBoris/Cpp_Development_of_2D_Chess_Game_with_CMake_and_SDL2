#ifndef COMMON_COMMONDEFINES_H_
#define COMMON_COMMONDEFINES_H_

namespace Textures {
enum Images {
  PRESS_KEYS
};
} //namespace Textures

#endif /* COMMON_COMMONDEFINES_H_ */
