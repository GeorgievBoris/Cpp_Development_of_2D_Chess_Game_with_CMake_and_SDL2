#ifndef UTILS_DRAWING_WIDGET_H_
#define UTILS_DRAWING_WIDGET_H_

//C system headers

//C++ system headers
#include <cstdint>

//Other libraries headers

//Own components headers
#include "utils/drawing/DrawParams.h"

//Forward Declarations

/* Common class for graphical Textures.
 * All graphical textures must inherit from Widget */
class Widget {
public:
  void draw();

  void setPosition(int32_t x, int32_t y);
  void setPosition(const Point &pos);
  void setX(int32_t x);
  void setY(int32_t y);
  void setWidth(int32_t width);
  void setHeight(int32_t height);
  void setWidgetFlip(WidgetFlip flipType);
  void setRotation(double angle);
  void setRotationCenter(const Point &center);

  void moveDown(int32_t y);
  void moveUp(int32_t y);
  void moveLeft(int32_t x);
  void moveRight(int32_t x);

  Rectangle getBoundaryRect() const;
  Point getPosition() const;
  int32_t getX() const;
  int32_t getY() const;
  int32_t getWidth() const;
  int32_t getHeight() const;

  double getRotation() const;
  Point getRotationCenter() const;

  bool isCreated() const;
  bool isVisible() const;

  void hide();
  void show();

  bool containsPoint(const Point &point) const;

  void setOpacity(int32_t opacity);

  int32_t getOpacity() const;

  WidgetFlip getFlipType() const;

  void activateAlphaModulation();

  void deactivateAlphaModulation();

  void reset();

protected:
  DrawParams _drawParams;

  bool _isCreated = false;
  bool _isVisible = true;
  bool _isAlphaModulationEnabled = false;
};

#endif /* UTILS_DRAWING_WIDGET_H_ */

