//Corresponding header
#include "game/game_entities/utils/BoardPos.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

BoardPos::BoardPos(const Point &boardPos)
    : row(boardPos.x), col(boardPos.y) {

}

BoardPos::BoardPos(int32_t inputRow, int32_t inputCol) {
  row = inputRow;
  col = inputCol;
}
