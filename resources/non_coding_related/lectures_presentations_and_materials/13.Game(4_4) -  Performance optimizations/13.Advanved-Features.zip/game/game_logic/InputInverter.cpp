//Corresponding header
#include "game/game_logic/InputInverter.h"

//C system headers

//C++ system headers
#include <cstdlib>

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"

int32_t InputInverter::init(int32_t boardWidth, int32_t boardHeight) {
  _boardWidth = boardWidth;
  _boardHeight = boardHeight;

  return EXIT_SUCCESS;
}

void InputInverter::setBoardFlipType(WidgetFlip flipType) {
  _flipType = flipType;
}

void InputInverter::invertEvent(InputEvent &inputEvent) {
  switch (_flipType) {
  case WidgetFlip::HORIZONTAL:
    inputEvent.pos.x = _boardWidth - inputEvent.pos.x;
    break;

  case WidgetFlip::VERTICAL:
    inputEvent.pos.y = _boardHeight - inputEvent.pos.y;
    break;

  case WidgetFlip::HORIZONTAL_AND_VERTICAL:
    inputEvent.pos.x = _boardWidth - inputEvent.pos.x;
    inputEvent.pos.y = _boardHeight - inputEvent.pos.y;
    break;

  case WidgetFlip::NONE:
    break;
  default:
    break;
  }
}
