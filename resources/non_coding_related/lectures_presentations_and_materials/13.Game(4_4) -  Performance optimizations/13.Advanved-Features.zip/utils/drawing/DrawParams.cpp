//Corresponding header
#include "utils/drawing/DrawParams.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers

DrawParams::DrawParams() {
  reset();
}

void DrawParams::reset() {
  frameRect = Rectangle::ZERO;
  rotationCenter = Point::ZERO;
  rotationAngle = 0.0;
  pos = Point::ZERO;
  width = 0;
  height = 0;
  opacity = FULL_OPACITY;
  rsrcId = -1;
  blendMode = BlendMode::NONE;
  widgetType = WidgetType::UNKNOWN;
  widgetFlip = WidgetFlip::NONE;
}


