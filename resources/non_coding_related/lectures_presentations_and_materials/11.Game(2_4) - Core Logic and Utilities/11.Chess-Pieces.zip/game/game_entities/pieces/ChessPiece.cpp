//Corresponding header
#include "game/game_entities/pieces/ChessPiece.h"

//C system headers

//C++ system headers

//Other libraries headers

//Own components headers
#include "sdl/InputEvent.h"
#include "game/game_entities/utils/BoardUtils.h"

ChessPiece::ChessPiece(int32_t pieceRsrcId, const BoardPos &boardPos,
                       PieceType pieceType, int32_t playerId)
    : _boardPos(boardPos), _playerId(playerId), _pieceType(pieceType) {
  _pieceImg.create(pieceRsrcId, BoardUtils::getAbsPos(boardPos));
  _pieceImg.setFrame(static_cast<int32_t>(_pieceType));
}

void ChessPiece::draw() {
  _pieceImg.draw();
}

bool ChessPiece::containsEvent(const InputEvent &e) const {
  return _pieceImg.getBoundaryRect().isPointInRect(e.pos);
}

void ChessPiece::setBoardPos(const BoardPos &boardPos) {
  _boardPos = boardPos;
  _pieceImg.setPosition(BoardUtils::getAbsPos(_boardPos));
}

BoardPos ChessPiece::getBoardPos() const {
  return _boardPos;
}

PieceType ChessPiece::getPieceType() const {
  return _pieceType;
}

int32_t ChessPiece::getPlayerId() const {
  return _playerId;
}

